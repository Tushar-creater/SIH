import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Sidebar = ({ isCollapsed = false, onToggle }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const location = useLocation();

  const navigationItems = [
    { 
      name: 'Dashboard', 
      path: '/homepage', 
      icon: 'LayoutDashboard',
      description: 'Overview & insights'
    },
    { 
      name: 'AI Assistant', 
      path: '/ai-assistant-interface', 
      icon: 'Bot',
      description: 'Smart farming advice'
    },
    { 
      name: 'Market Intelligence', 
      path: '/market-intelligence-center', 
      icon: 'TrendingUp',
      description: 'Prices & trends'
    },
    { 
      name: 'Government Schemes', 
      path: '/government-schemes-navigator', 
      icon: 'FileText',
      description: 'Benefits & subsidies'
    },
    { 
      name: 'Officer Connect', 
      path: '/officer-connect-portal', 
      icon: 'Users',
      description: 'Expert consultation'
    },
    { 
      name: 'Weather Hub', 
      path: '/weather-intelligence-hub', 
      icon: 'Cloud',
      description: 'Weather forecasts'
    }
  ];

  const quickActions = [
    { name: 'Voice Query', icon: 'Mic', action: 'voice' },
    { name: 'Crop Scanner', icon: 'Camera', action: 'scan' },
    { name: 'Emergency Help', icon: 'AlertTriangle', action: 'emergency' }
  ];

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const isActivePath = (path) => {
    return location?.pathname === path;
  };

  const handleQuickAction = (action) => {
    switch (action) {
      case 'voice': console.log('Voice query activated');
        break;
      case 'scan': console.log('Crop scanner activated');
        break;
      case 'emergency': console.log('Emergency help activated');
        break;
      default:
        break;
    }
  };

  const sidebarWidth = isCollapsed && !isHovered ? 'w-16' : 'w-64';
  const showLabels = !isCollapsed || isHovered;

  return (
    <>
      {/* Sidebar */}
      <aside 
        className={`fixed left-0 top-16 bottom-0 bg-white border-r border-border transition-all duration-300 ease-out z-40 ${sidebarWidth} ${
          isMobile ? 'transform -translate-x-full lg:translate-x-0' : ''
        }`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="flex flex-col h-full">
          {/* Toggle Button */}
          {!isMobile && (
            <div className="flex justify-end p-2 border-b border-border">
              <Button
                variant="ghost"
                size="icon"
                onClick={onToggle}
                className="hover:bg-muted"
              >
                <Icon 
                  name={isCollapsed ? "ChevronRight" : "ChevronLeft"} 
                  size={16} 
                />
              </Button>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            <div className="space-y-1">
              {navigationItems?.map((item) => (
                <Link
                  key={item?.path}
                  to={item?.path}
                  className={`group flex items-center space-x-3 px-3 py-3 rounded-lg text-sm font-inter font-medium transition-all duration-200 ${
                    isActivePath(item?.path)
                      ? 'bg-primary text-primary-foreground shadow-growth'
                      : 'text-foreground hover:bg-muted hover:text-primary'
                  }`}
                  title={!showLabels ? item?.name : ''}
                >
                  <div className="flex-shrink-0">
                    <Icon 
                      name={item?.icon} 
                      size={20} 
                      className={isActivePath(item?.path) ? 'text-primary-foreground' : ''}
                    />
                  </div>
                  
                  {showLabels && (
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{item?.name}</div>
                      <div className={`text-xs truncate ${
                        isActivePath(item?.path) 
                          ? 'text-primary-foreground/80' 
                          : 'text-muted-foreground'
                      }`}>
                        {item?.description}
                      </div>
                    </div>
                  )}
                  
                  {isActivePath(item?.path) && (
                    <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                  )}
                </Link>
              ))}
            </div>
          </nav>

          {/* Quick Actions */}
          <div className="p-4 border-t border-border">
            {showLabels && (
              <h3 className="text-xs font-poppins font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Quick Actions
              </h3>
            )}
            
            <div className="space-y-2">
              {quickActions?.map((action) => (
                <button
                  key={action?.action}
                  onClick={() => handleQuickAction(action?.action)}
                  className={`group flex items-center space-x-3 w-full px-3 py-2 rounded-lg text-sm font-inter font-medium text-foreground hover:bg-muted hover:text-primary transition-all duration-200 ${
                    action?.action === 'emergency' ? 'hover:bg-error/10 hover:text-error' : ''
                  }`}
                  title={!showLabels ? action?.name : ''}
                >
                  <div className="flex-shrink-0">
                    <Icon 
                      name={action?.icon} 
                      size={18}
                      className={action?.action === 'emergency' ? 'group-hover:text-error' : ''}
                    />
                  </div>
                  
                  {showLabels && (
                    <span className="flex-1 text-left truncate">{action?.name}</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* User Status */}
          <div className="p-4 border-t border-border">
            <div className={`flex items-center space-x-3 px-3 py-2 rounded-lg bg-muted/50 ${
              !showLabels ? 'justify-center' : ''
            }`}>
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center">
                <Icon name="User" size={16} color="white" />
              </div>
              
              {showLabels && (
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-foreground truncate">
                    Farmer Dashboard
                  </div>
                  <div className="text-xs text-muted-foreground truncate">
                    Active Session
                  </div>
                </div>
              )}
              
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </aside>
      {/* Mobile Overlay */}
      {isMobile && !isCollapsed && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={onToggle}
        />
      )}
    </>
  );
};

export default Sidebar;