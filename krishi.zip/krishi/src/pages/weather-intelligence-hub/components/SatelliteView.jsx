import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';


const SatelliteView = ({ location = { lat: 20.5937, lng: 78.9629 } }) => {
  const [selectedLayer, setSelectedLayer] = useState('weather');
  const [isLoading, setIsLoading] = useState(false);

  const layers = [
    {
      id: 'weather',
      name: 'Weather Overlay',
      icon: 'Cloud',
      description: 'Current weather patterns and cloud coverage'
    },
    {
      id: 'rainfall',
      name: 'Rainfall Data',
      icon: 'CloudRain',
      description: 'Precipitation levels and intensity'
    },
    {
      id: 'temperature',
      name: 'Temperature Map',
      icon: 'Thermometer',
      description: 'Surface temperature distribution'
    },
    {
      id: 'vegetation',
      name: 'Crop Health',
      icon: 'Leaf',
      description: 'Vegetation index and crop health monitoring'
    }
  ];

  const handleLayerChange = (layerId) => {
    setIsLoading(true);
    setSelectedLayer(layerId);
    // Simulate loading time
    setTimeout(() => setIsLoading(false), 1000);
  };

  const getSatelliteImageUrl = () => {
    // Using Google Maps Static API for satellite imagery
    const { lat, lng } = location;
    return `https://maps.googleapis.com/maps/api/staticmap?center=${lat},${lng}&zoom=12&size=600x400&maptype=satellite&key=demo`;
  };

  return (
    <div className="bg-white rounded-lg border border-border overflow-hidden">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon name="Satellite" size={24} className="text-primary" />
            <div>
              <h3 className="text-lg font-semibold text-foreground">Satellite View</h3>
              <p className="text-sm text-muted-foreground">Regional weather patterns and crop monitoring</p>
            </div>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            iconName="RotateCcw"
            iconPosition="left"
            onClick={() => handleLayerChange(selectedLayer)}
            disabled={isLoading}
          >
            Refresh
          </Button>
        </div>
      </div>
      {/* Layer Selection */}
      <div className="p-4 bg-muted/30">
        <div className="flex items-center space-x-2 overflow-x-auto">
          {layers?.map((layer) => (
            <Button
              key={layer?.id}
              variant={selectedLayer === layer?.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => handleLayerChange(layer?.id)}
              iconName={layer?.icon}
              iconPosition="left"
              className="whitespace-nowrap"
            >
              {layer?.name}
            </Button>
          ))}
        </div>
      </div>
      {/* Satellite Map */}
      <div className="relative">
        <div className="aspect-video bg-muted/50 relative overflow-hidden">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center bg-white/80">
              <div className="flex items-center space-x-3">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                <span className="text-sm text-muted-foreground">Loading satellite data...</span>
              </div>
            </div>
          ) : (
            <>
              {/* Google Maps Iframe for satellite view */}
              <iframe
                width="100%"
                height="100%"
                loading="lazy"
                title="Satellite Weather View"
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://www.google.com/maps?q=${location?.lat},${location?.lng}&z=12&t=k&output=embed`}
                className="border-0"
              />
              
              {/* Weather Overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-transparent to-green-500/20 pointer-events-none">
                {selectedLayer === 'rainfall' && (
                  <div className="absolute inset-0 bg-blue-600/30"></div>
                )}
                {selectedLayer === 'temperature' && (
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400/30 via-yellow-400/30 to-red-400/30"></div>
                )}
                {selectedLayer === 'vegetation' && (
                  <div className="absolute inset-0 bg-green-500/30"></div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Layer Info */}
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-white/90 backdrop-blur-sm rounded-lg p-3 border border-border/50">
            <div className="flex items-center space-x-2">
              <Icon 
                name={layers?.find(l => l?.id === selectedLayer)?.icon || 'Map'} 
                size={16} 
                className="text-primary" 
              />
              <div>
                <h4 className="text-sm font-medium text-foreground">
                  {layers?.find(l => l?.id === selectedLayer)?.name}
                </h4>
                <p className="text-xs text-muted-foreground">
                  {layers?.find(l => l?.id === selectedLayer)?.description}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="absolute top-4 right-4">
          <div className="bg-white/90 backdrop-blur-sm rounded-lg p-3 border border-border/50">
            <h5 className="text-xs font-semibold text-foreground mb-2">Legend</h5>
            <div className="space-y-1">
              {selectedLayer === 'weather' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <span className="text-xs text-muted-foreground">Cloud Cover</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="text-xs text-muted-foreground">Clear Skies</span>
                  </div>
                </>
              )}
              {selectedLayer === 'rainfall' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-blue-300"></div>
                    <span className="text-xs text-muted-foreground">Light Rain</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-blue-600"></div>
                    <span className="text-xs text-muted-foreground">Heavy Rain</span>
                  </div>
                </>
              )}
              {selectedLayer === 'temperature' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-blue-400"></div>
                    <span className="text-xs text-muted-foreground">Cool (&lt;20°C)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                    <span className="text-xs text-muted-foreground">Moderate (20-30°C)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-400"></div>
                    <span className="text-xs text-muted-foreground">Hot (&gt;30°C)</span>
                  </div>
                </>
              )}
              {selectedLayer === 'vegetation' && (
                <>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-green-300"></div>
                    <span className="text-xs text-muted-foreground">Healthy Crops</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <span className="text-xs text-muted-foreground">Stressed Vegetation</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <span className="text-xs text-muted-foreground">Poor Health</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Controls */}
      <div className="p-4 bg-muted/30 border-t border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Icon name="MapPin" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Lat: {location?.lat?.toFixed(4)}, Lng: {location?.lng?.toFixed(4)}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Updated: {new Date()?.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            iconName="Maximize2"
            iconPosition="left"
          >
            Full Screen
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SatelliteView;