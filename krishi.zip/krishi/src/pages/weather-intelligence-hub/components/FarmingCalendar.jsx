import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FarmingCalendar = ({ activities, currentWeather }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('week'); // week, month

  const getWeekDates = (date) => {
    const week = [];
    const startDate = new Date(date);
    const day = startDate?.getDay();
    const diff = startDate?.getDate() - day;
    startDate?.setDate(diff);

    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(startDate);
      currentDate?.setDate(startDate?.getDate() + i);
      week?.push(currentDate);
    }
    return week;
  };

  const getActivityForDate = (date) => {
    const dateStr = date?.toISOString()?.split('T')?.[0];
    return activities?.find(activity => activity?.date === dateStr);
  };

  const getWeatherSuitability = (activity, weather) => {
    if (!activity || !weather) return 'neutral';
    
    // Simple logic for weather suitability
    if (activity?.type === 'irrigation' && weather?.rainfall > 10) return 'poor';
    if (activity?.type === 'spraying' && weather?.windSpeed > 15) return 'poor';
    if (activity?.type === 'harvesting' && weather?.rainfall > 5) return 'poor';
    if (activity?.type === 'planting' && weather?.temp < 15 || weather?.temp > 35) return 'moderate';
    
    return 'good';
  };

  const getSuitabilityColor = (suitability) => {
    switch (suitability) {
      case 'good': return 'text-success bg-success/10';
      case 'moderate': return 'text-warning bg-warning/10';
      case 'poor': return 'text-error bg-error/10';
      default: return 'text-muted-foreground bg-muted/50';
    }
  };

  const weekDates = getWeekDates(selectedDate);

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="Calendar" size={24} className="text-primary" />
          <h3 className="text-xl font-semibold text-foreground">Farming Calendar</h3>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant={viewMode === 'week' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('week')}
          >
            Week
          </Button>
          <Button
            variant={viewMode === 'month' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('month')}
          >
            Month
          </Button>
        </div>
      </div>
      {/* Week Navigation */}
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            const newDate = new Date(selectedDate);
            newDate?.setDate(selectedDate?.getDate() - 7);
            setSelectedDate(newDate);
          }}
          iconName="ChevronLeft"
          iconPosition="left"
        >
          Previous Week
        </Button>
        
        <h4 className="text-lg font-medium text-foreground">
          {weekDates?.[0]?.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
        </h4>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            const newDate = new Date(selectedDate);
            newDate?.setDate(selectedDate?.getDate() + 7);
            setSelectedDate(newDate);
          }}
          iconName="ChevronRight"
          iconPosition="right"
        >
          Next Week
        </Button>
      </div>
      {/* Week View */}
      <div className="grid grid-cols-7 gap-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']?.map((day, index) => (
          <div key={day} className="text-center">
            <div className="text-sm font-medium text-muted-foreground mb-2">{day}</div>
            
            <div className="space-y-2">
              {weekDates?.map((date, dateIndex) => {
                if (dateIndex % 7 !== index) return null;
                
                const activity = getActivityForDate(date);
                const suitability = getWeatherSuitability(activity, currentWeather);
                const isToday = date?.toDateString() === new Date()?.toDateString();
                
                return (
                  <div
                    key={date?.toISOString()}
                    className={`p-3 rounded-lg border transition-all duration-200 hover:shadow-sm ${
                      isToday ? 'border-primary bg-primary/5' : 'border-border bg-white'
                    }`}
                  >
                    <div className={`text-sm font-medium mb-2 ${
                      isToday ? 'text-primary' : 'text-foreground'
                    }`}>
                      {date?.getDate()}
                    </div>
                    {activity && (
                      <div className="space-y-2">
                        <div className={`px-2 py-1 rounded text-xs font-medium ${getSuitabilityColor(suitability)}`}>
                          {activity?.title}
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <Icon name={activity?.icon} size={12} className="text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">{activity?.time}</span>
                        </div>
                        
                        {suitability !== 'good' && (
                          <div className="flex items-center space-x-1">
                            <Icon 
                              name={suitability === 'poor' ? 'AlertTriangle' : 'AlertCircle'} 
                              size={10} 
                              className={suitability === 'poor' ? 'text-error' : 'text-warning'} 
                            />
                            <span className={`text-xs ${
                              suitability === 'poor' ? 'text-error' : 'text-warning'
                            }`}>
                              Weather Alert
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                    {!activity && (
                      <div className="text-xs text-muted-foreground">No activities</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      {/* Weather Impact Legend */}
      <div className="mt-6 pt-4 border-t border-border">
        <h5 className="text-sm font-medium text-foreground mb-3">Weather Impact Legend:</h5>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-success"></div>
            <span className="text-xs text-muted-foreground">Ideal Conditions</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-warning"></div>
            <span className="text-xs text-muted-foreground">Moderate Conditions</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-error"></div>
            <span className="text-xs text-muted-foreground">Poor Conditions</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FarmingCalendar;