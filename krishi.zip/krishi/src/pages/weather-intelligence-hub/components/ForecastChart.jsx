import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import Icon from '../../../components/AppIcon';

const ForecastChart = ({ data, type = "temperature", title, height = 300 }) => {
  const getChartConfig = () => {
    switch (type) {
      case 'temperature':
        return {
          dataKey: 'temp',
          color: '#FF6B35',
          unit: '°C',
          icon: 'Thermometer'
        };
      case 'humidity':
        return {
          dataKey: 'humidity',
          color: '#4FC3F7',
          unit: '%',
          icon: 'Droplets'
        };
      case 'rainfall':
        return {
          dataKey: 'rainfall',
          color: '#2196F3',
          unit: 'mm',
          icon: 'CloudRain'
        };
      case 'wind':
        return {
          dataKey: 'windSpeed',
          color: '#66BB6A',
          unit: 'km/h',
          icon: 'Wind'
        };
      default:
        return {
          dataKey: 'value',
          color: '#2E7D32',
          unit: '',
          icon: 'BarChart3'
        };
    }
  };

  const config = getChartConfig();

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-border">
          <p className="text-sm font-medium text-foreground">{label}</p>
          <p className="text-sm text-primary">
            {`${payload?.[0]?.value}${config?.unit}`}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg border border-border p-4">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name={config?.icon} size={20} className="text-primary" />
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
      </div>
      <div style={{ width: '100%', height }}>
        <ResponsiveContainer>
          {type === 'rainfall' ? (
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E0E0E0" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12, fill: '#616161' }}
                axisLine={{ stroke: '#E0E0E0' }}
              />
              <YAxis 
                tick={{ fontSize: 12, fill: '#616161' }}
                axisLine={{ stroke: '#E0E0E0' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey={config?.dataKey}
                stroke={config?.color}
                fill={`${config?.color}20`}
                strokeWidth={2}
              />
            </AreaChart>
          ) : (
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E0E0E0" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12, fill: '#616161' }}
                axisLine={{ stroke: '#E0E0E0' }}
              />
              <YAxis 
                tick={{ fontSize: 12, fill: '#616161' }}
                axisLine={{ stroke: '#E0E0E0' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey={config?.dataKey}
                stroke={config?.color}
                strokeWidth={3}
                dot={{ fill: config?.color, strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: config?.color, strokeWidth: 2 }}
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ForecastChart;