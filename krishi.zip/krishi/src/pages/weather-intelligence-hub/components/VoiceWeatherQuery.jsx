import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VoiceWeatherQuery = ({ onQuery, isListening, onToggleListening }) => {
  const [transcript, setTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(false);
  const [language, setLanguage] = useState('hi-IN'); // Default to Hindi

  const languages = [
    { code: 'hi-IN', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'en-IN', name: 'English', flag: '🇮🇳' },
    { code: 'bn-IN', name: 'বাংলা', flag: '🇮🇳' },
    { code: 'te-IN', name: 'తెలుగు', flag: '🇮🇳' },
    { code: 'ta-IN', name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'mr-IN', name: 'मराठी', flag: '🇮🇳' },
    { code: 'gu-IN', name: 'ગુજરાતી', flag: '🇮🇳' },
    { code: 'kn-IN', name: 'ಕನ್ನಡ', flag: '🇮🇳' }
  ];

  const sampleQueries = [
    "आज का मौसम कैसा है?",
    "कल बारिश होगी क्या?",
    "इस हफ्ते तापमान कैसा रहेगा?",
    "फसल के लिए मौसम कैसा है?",
    "What\'s the weather forecast?",
    "Will it rain tomorrow?",
    "Is it good weather for harvesting?"
  ];

  useEffect(() => {
    setIsSupported('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);
  }, []);

  const handleVoiceQuery = () => {
    if (!isSupported) {
      alert('Voice recognition is not supported in your browser');
      return;
    }

    if (isListening) {
      onToggleListening();
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.lang = language;
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
      onToggleListening();
      setTranscript('');
    };

    recognition.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event?.resultIndex; i < event?.results?.length; i++) {
        const transcript = event?.results?.[i]?.[0]?.transcript;
        if (event?.results?.[i]?.isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      setTranscript(finalTranscript || interimTranscript);
    };

    recognition.onend = () => {
      onToggleListening();
      if (transcript?.trim()) {
        onQuery(transcript?.trim());
      }
    };

    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event?.error);
      onToggleListening();
    };

    recognition?.start();
  };

  const handleSampleQuery = (query) => {
    setTranscript(query);
    onQuery(query);
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-2 bg-primary/10 rounded-lg">
          <Icon name="Mic" size={24} className="text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Voice Weather Query</h3>
          <p className="text-sm text-muted-foreground">Ask about weather in your preferred language</p>
        </div>
      </div>
      {/* Language Selection */}
      <div className="mb-6">
        <label className="text-sm font-medium text-foreground mb-3 block">Select Language:</label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {languages?.map((lang) => (
            <button
              key={lang?.code}
              onClick={() => setLanguage(lang?.code)}
              className={`p-3 rounded-lg border text-sm font-medium transition-all duration-200 ${
                language === lang?.code
                  ? 'border-primary bg-primary/10 text-primary' :'border-border hover:border-primary/50 text-foreground'
              }`}
            >
              <div className="flex items-center space-x-2">
                <span>{lang?.flag}</span>
                <span>{lang?.name}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
      {/* Voice Input */}
      <div className="mb-6">
        <div className="flex items-center space-x-4">
          <Button
            variant={isListening ? "destructive" : "default"}
            size="lg"
            onClick={handleVoiceQuery}
            disabled={!isSupported}
            iconName={isListening ? "MicOff" : "Mic"}
            iconPosition="left"
            className={isListening ? "animate-pulse" : ""}
          >
            {isListening ? 'Stop Listening' : 'Start Voice Query'}
          </Button>
          
          {!isSupported && (
            <div className="flex items-center space-x-2 text-warning">
              <Icon name="AlertTriangle" size={16} />
              <span className="text-sm">Voice not supported</span>
            </div>
          )}
        </div>

        {/* Transcript Display */}
        {(transcript || isListening) && (
          <div className="mt-4 p-4 bg-muted/50 rounded-lg border border-border">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="MessageSquare" size={16} className="text-primary" />
              <span className="text-sm font-medium text-foreground">
                {isListening ? 'Listening...' : 'Recognized:'}
              </span>
            </div>
            <p className="text-foreground">
              {transcript || (isListening ? 'Speak now...' : '')}
            </p>
            {isListening && (
              <div className="flex items-center space-x-2 mt-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
                <span className="text-xs text-muted-foreground">Processing speech...</span>
              </div>
            )}
          </div>
        )}
      </div>
      {/* Sample Queries */}
      <div>
        <h4 className="text-sm font-medium text-foreground mb-3">Try these sample queries:</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {sampleQueries?.map((query, index) => (
            <button
              key={index}
              onClick={() => handleSampleQuery(query)}
              className="p-3 text-left rounded-lg border border-border hover:border-primary/50 hover:bg-primary/5 transition-all duration-200 group"
            >
              <div className="flex items-center space-x-2">
                <Icon name="MessageCircle" size={14} className="text-muted-foreground group-hover:text-primary" />
                <span className="text-sm text-foreground">{query}</span>
              </div>
            </button>
          ))}
        </div>
      </div>
      {/* Tips */}
      <div className="mt-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
        <div className="flex items-start space-x-2">
          <Icon name="Lightbulb" size={16} className="text-accent mt-0.5" />
          <div>
            <h5 className="text-sm font-medium text-foreground mb-1">Voice Query Tips:</h5>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Speak clearly and at normal pace</li>
              <li>• Ask about weather, rainfall, temperature, or farming conditions</li>
              <li>• Use natural language - "Will it rain tomorrow?" or "कल बारिश होगी?"</li>
              <li>• Ensure microphone permissions are enabled</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VoiceWeatherQuery;