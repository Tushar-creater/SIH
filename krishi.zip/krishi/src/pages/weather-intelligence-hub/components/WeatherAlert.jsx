import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const WeatherAlert = ({ alert, onDismiss, onViewDetails }) => {
  const getAlertConfig = (severity) => {
    switch (severity) {
      case 'severe':
        return {
          bgColor: 'bg-error/10',
          borderColor: 'border-error/30',
          textColor: 'text-error',
          icon: 'AlertTriangle'
        };
      case 'moderate':
        return {
          bgColor: 'bg-warning/10',
          borderColor: 'border-warning/30',
          textColor: 'text-warning',
          icon: 'AlertCircle'
        };
      case 'low':
        return {
          bgColor: 'bg-accent/10',
          borderColor: 'border-accent/30',
          textColor: 'text-accent',
          icon: 'Info'
        };
      default:
        return {
          bgColor: 'bg-muted/50',
          borderColor: 'border-border',
          textColor: 'text-muted-foreground',
          icon: 'Bell'
        };
    }
  };

  const config = getAlertConfig(alert?.severity);

  return (
    <div className={`p-4 rounded-lg border-l-4 ${config?.bgColor} ${config?.borderColor} mb-4`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 flex-1">
          <div className={`p-2 rounded-full ${config?.bgColor}`}>
            <Icon name={config?.icon} size={20} className={config?.textColor} />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <h4 className="text-sm font-semibold text-foreground">{alert?.title}</h4>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${config?.bgColor} ${config?.textColor}`}>
                {alert?.severity?.toUpperCase()}
              </span>
            </div>
            
            <p className="text-sm text-muted-foreground mb-2">{alert?.description}</p>
            
            <div className="flex items-center space-x-4 text-xs text-muted-foreground mb-3">
              <div className="flex items-center space-x-1">
                <Icon name="Clock" size={12} />
                <span>Valid until: {alert?.validUntil}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="MapPin" size={12} />
                <span>{alert?.location}</span>
              </div>
            </div>
            
            {alert?.recommendations && (
              <div className="bg-white/50 rounded-md p-3 mb-3">
                <h5 className="text-xs font-semibold text-foreground mb-2 flex items-center space-x-1">
                  <Icon name="Lightbulb" size={12} />
                  <span>Recommended Actions:</span>
                </h5>
                <ul className="text-xs text-muted-foreground space-y-1">
                  {alert?.recommendations?.map((rec, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <Icon name="ChevronRight" size={10} className="mt-0.5 flex-shrink-0" />
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center space-x-2 ml-4">
          {onViewDetails && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onViewDetails(alert)}
              iconName="ExternalLink"
              iconPosition="right"
              iconSize={12}
            >
              Details
            </Button>
          )}
          {onDismiss && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDismiss(alert?.id)}
              className="h-8 w-8"
            >
              <Icon name="X" size={14} />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default WeatherAlert;