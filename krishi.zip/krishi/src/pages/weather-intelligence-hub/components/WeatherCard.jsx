import React from 'react';
import Icon from '../../../components/AppIcon';

const WeatherCard = ({ 
  title, 
  icon, 
  value, 
  unit, 
  description, 
  trend, 
  color = "text-primary",
  bgColor = "bg-primary/10",
  size = "default" 
}) => {
  const cardSize = size === "large" ? "p-6" : "p-4";
  const iconSize = size === "large" ? 32 : 24;
  const valueSize = size === "large" ? "text-3xl" : "text-2xl";

  return (
    <div className={`${cardSize} bg-white rounded-lg border border-border shadow-sm hover:shadow-md transition-all duration-300`}>
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2 rounded-lg ${bgColor}`}>
          <Icon name={icon} size={iconSize} className={color} />
        </div>
        {trend && (
          <div className={`flex items-center space-x-1 text-xs font-medium ${
            trend?.type === 'up' ? 'text-success' : trend?.type === 'down' ? 'text-error' : 'text-muted-foreground'
          }`}>
            <Icon 
              name={trend?.type === 'up' ? 'TrendingUp' : trend?.type === 'down' ? 'TrendingDown' : 'Minus'} 
              size={12} 
            />
            <span>{trend?.value}</span>
          </div>
        )}
      </div>
      <div className="space-y-1">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        <div className="flex items-baseline space-x-1">
          <span className={`${valueSize} font-bold text-foreground`}>{value}</span>
          {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
        </div>
        {description && (
          <p className="text-xs text-muted-foreground mt-2">{description}</p>
        )}
      </div>
    </div>
  );
};

export default WeatherCard;