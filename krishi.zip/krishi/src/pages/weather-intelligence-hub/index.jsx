import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import WeatherCard from './components/WeatherCard';
import ForecastChart from './components/ForecastChart';
import WeatherAlert from './components/WeatherAlert';
import FarmingCalendar from './components/FarmingCalendar';
import SatelliteView from './components/SatelliteView';
import VoiceWeatherQuery from './components/VoiceWeatherQuery';

const WeatherIntelligenceHub = () => {
  const [currentLocation, setCurrentLocation] = useState('Pune, Maharashtra');
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');
  const [alerts, setAlerts] = useState([]);

  // Mock current weather data
  const currentWeather = {
    temp: 28,
    humidity: 65,
    windSpeed: 12,
    rainfall: 2.5,
    pressure: 1013,
    visibility: 8,
    uvIndex: 6,
    soilMoisture: 45,
    pestActivity: 'Low',
    cropStress: 'Moderate'
  };

  // Mock forecast data
  const forecastData = [
    { time: '6 AM', temp: 24, humidity: 70, rainfall: 0, windSpeed: 8 },
    { time: '9 AM', temp: 26, humidity: 68, rainfall: 0, windSpeed: 10 },
    { time: '12 PM', temp: 30, humidity: 60, rainfall: 1, windSpeed: 15 },
    { time: '3 PM', temp: 32, humidity: 55, rainfall: 3, windSpeed: 18 },
    { time: '6 PM', temp: 29, humidity: 62, rainfall: 5, windSpeed: 14 },
    { time: '9 PM', temp: 26, humidity: 68, rainfall: 2, windSpeed: 10 }
  ];

  // Mock weather alerts
  const mockAlerts = [
    {
      id: 1,
      severity: 'moderate',
      title: 'Heavy Rainfall Expected',
      description: 'Moderate to heavy rainfall expected in the next 24-48 hours. Rainfall intensity may reach 15-25mm per hour.',
      validUntil: '18 Sep, 6:00 PM',
      location: 'Pune District',
      recommendations: [
        'Postpone spraying activities for 2-3 days',
        'Ensure proper drainage in fields',
        'Cover harvested crops to prevent damage',
        'Check weather updates every 6 hours'
      ]
    },
    {
      id: 2,
      severity: 'low',
      title: 'Optimal Harvesting Conditions',
      description: 'Clear skies and low humidity expected for the next 3 days. Ideal conditions for harvesting activities.',
      validUntil: '20 Sep, 6:00 PM',
      location: 'Regional Area',
      recommendations: [
        'Plan harvesting activities between 8 AM - 4 PM',
        'Ensure machinery is ready and functional',
        'Arrange for adequate storage facilities'
      ]
    }
  ];

  // Mock farming activities
  const farmingActivities = [
    {
      date: '2025-09-17',
      title: 'Irrigation',
      type: 'irrigation',
      time: '6:00 AM',
      icon: 'Droplets'
    },
    {
      date: '2025-09-18',
      title: 'Pest Monitoring',
      type: 'monitoring',
      time: '8:00 AM',
      icon: 'Search'
    },
    {
      date: '2025-09-19',
      title: 'Fertilizer Application',
      type: 'fertilizing',
      time: '7:00 AM',
      icon: 'Sprout'
    },
    {
      date: '2025-09-20',
      title: 'Harvesting',
      type: 'harvesting',
      time: '6:30 AM',
      icon: 'Scissors'
    }
  ];

  useEffect(() => {
    setAlerts(mockAlerts);
  }, []);

  const handleVoiceQuery = (query) => {
    console.log('Voice query received:', query);
    // Here you would typically send the query to an AI service
    // For demo purposes, we'll just log it
  };

  const handleToggleVoiceListening = () => {
    setIsVoiceListening(!isVoiceListening);
  };

  const handleDismissAlert = (alertId) => {
    setAlerts(alerts?.filter(alert => alert?.id !== alertId));
  };

  const handleViewAlertDetails = (alert) => {
    console.log('Viewing alert details:', alert);
  };

  const tabs = [
    { id: 'overview', name: 'Overview', icon: 'LayoutDashboard' },
    { id: 'forecast', name: 'Extended Forecast', icon: 'Calendar' },
    { id: 'satellite', name: 'Satellite View', icon: 'Satellite' },
    { id: 'voice', name: 'Voice Query', icon: 'Mic' }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <div className="p-3 bg-primary rounded-xl shadow-growth">
                  <Icon name="Cloud" size={32} color="white" />
                </div>
                <h1 className="text-4xl font-bold text-foreground font-poppins">
                  Weather Intelligence Hub
                </h1>
              </div>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Hyperlocal weather forecasts with farming-specific recommendations and AI-powered insights
              </p>
            </div>

            {/* Location & Quick Stats */}
            <div className="bg-white rounded-xl border border-border p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <Icon name="MapPin" size={20} className="text-primary" />
                  <span className="text-lg font-medium text-foreground">{currentLocation}</span>
                  <Button variant="ghost" size="sm" iconName="RefreshCw" iconPosition="left">
                    Update Location
                  </Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Last updated: {new Date()?.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>

              {/* Current Weather Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <WeatherCard
                  title="Temperature"
                  icon="Thermometer"
                  value={currentWeather?.temp}
                  unit="°C"
                  color="text-orange-600"
                  bgColor="bg-orange-100"
                  trend={{ type: 'up', value: '+2°' }}
                  description=""
                />
                <WeatherCard
                  title="Humidity"
                  icon="Droplets"
                  value={currentWeather?.humidity}
                  unit="%"
                  color="text-blue-600"
                  bgColor="bg-blue-100"
                  trend={null}
                  description=""
                />
                <WeatherCard
                  title="Wind Speed"
                  icon="Wind"
                  value={currentWeather?.windSpeed}
                  unit="km/h"
                  color="text-green-600"
                  bgColor="bg-green-100"
                  trend={null}
                  description=""
                />
                <WeatherCard
                  title="Rainfall"
                  icon="CloudRain"
                  value={currentWeather?.rainfall}
                  unit="mm"
                  color="text-blue-700"
                  bgColor="bg-blue-100"
                  trend={null}
                  description=""
                />
                <WeatherCard
                  title="Soil Moisture"
                  icon="Sprout"
                  value={currentWeather?.soilMoisture}
                  unit="%"
                  color="text-primary"
                  bgColor="bg-primary/10"
                  trend={null}
                  description=""
                />
                <WeatherCard
                  title="UV Index"
                  icon="Sun"
                  value={currentWeather?.uvIndex}
                  color="text-yellow-600"
                  bgColor="bg-yellow-100"
                  description="Moderate exposure"
                  unit=""
                  trend={null}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Weather Alerts */}
        {alerts?.length > 0 && (
          <section className="py-8">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center space-x-3 mb-6">
                <Icon name="AlertTriangle" size={24} className="text-warning" />
                <h2 className="text-2xl font-bold text-foreground font-poppins">Weather Alerts</h2>
              </div>
              
              <div className="space-y-4">
                {alerts?.map((alert) => (
                  <WeatherAlert
                    key={alert?.id}
                    alert={alert}
                    onDismiss={handleDismissAlert}
                    onViewDetails={handleViewAlertDetails}
                  />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Tab Navigation */}
        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center space-x-2 mb-8 overflow-x-auto">
              {tabs?.map((tab) => (
                <Button
                  key={tab?.id}
                  variant={selectedTab === tab?.id ? 'default' : 'outline'}
                  onClick={() => setSelectedTab(tab?.id)}
                  iconName={tab?.icon}
                  iconPosition="left"
                  className="whitespace-nowrap"
                >
                  {tab?.name}
                </Button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="space-y-8">
              {selectedTab === 'overview' && (
                <>
                  {/* Forecast Charts */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <ForecastChart
                      data={forecastData}
                      type="temperature"
                      title="Temperature Forecast (Today)"
                      height={300}
                    />
                    <ForecastChart
                      data={forecastData}
                      type="rainfall"
                      title="Rainfall Prediction (Today)"
                      height={300}
                    />
                  </div>

                  {/* Farming Calendar */}
                  <FarmingCalendar
                    activities={farmingActivities}
                    currentWeather={currentWeather}
                  />
                </>
              )}

              {selectedTab === 'forecast' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <ForecastChart
                    data={forecastData}
                    type="humidity"
                    title="Humidity Levels (7-Day Forecast)"
                    height={400}
                  />
                  <ForecastChart
                    data={forecastData}
                    type="wind"
                    title="Wind Speed Patterns (7-Day Forecast)"
                    height={400}
                  />
                </div>
              )}

              {selectedTab === 'satellite' && (
                <SatelliteView location={{ lat: 18.5204, lng: 73.8567 }} />
              )}

              {selectedTab === 'voice' && (
                <VoiceWeatherQuery
                  onQuery={handleVoiceQuery}
                  isListening={isVoiceListening}
                  onToggleListening={handleToggleVoiceListening}
                />
              )}
            </div>
          </div>
        </section>

        {/* Agricultural Impact Section */}
        <section className="py-12 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-foreground font-poppins mb-4">
                Agricultural Impact Analysis
              </h2>
              <p className="text-lg text-muted-foreground">
                Weather-based recommendations for optimal farming decisions
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Crop Health */}
              <div className="bg-white rounded-lg border border-border p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-success/10 rounded-lg">
                    <Icon name="Leaf" size={24} className="text-success" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">Crop Health Index</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Overall Health</span>
                    <span className="text-lg font-bold text-success">Good</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-success h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Current weather conditions are favorable for crop growth. Monitor soil moisture levels.
                  </p>
                </div>
              </div>

              {/* Pest Activity */}
              <div className="bg-white rounded-lg border border-border p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-warning/10 rounded-lg">
                    <Icon name="Bug" size={24} className="text-warning" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">Pest Activity</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Risk Level</span>
                    <span className="text-lg font-bold text-warning">Moderate</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-warning h-2 rounded-full" style={{ width: '45%' }}></div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Humid conditions may increase pest activity. Consider preventive measures.
                  </p>
                </div>
              </div>

              {/* Irrigation Needs */}
              <div className="bg-white rounded-lg border border-border p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Icon name="Droplets" size={24} className="text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">Irrigation Needs</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Water Requirement</span>
                    <span className="text-lg font-bold text-blue-600">Low</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '30%' }}></div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Recent rainfall has improved soil moisture. Reduce irrigation frequency.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-foreground font-poppins mb-6">Quick Actions</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                iconName="Bell"
                iconPosition="top"
              >
                <span className="text-sm font-medium">Set Weather Alerts</span>
              </Button>
              
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                iconName="Download"
                iconPosition="top"
              >
                <span className="text-sm font-medium">Download Report</span>
              </Button>
              
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                iconName="Share"
                iconPosition="top"
              >
                <span className="text-sm font-medium">Share Forecast</span>
              </Button>
              
              <Button
                variant="outline"
                className="h-20 flex-col space-y-2"
                iconName="Calendar"
                iconPosition="top"
              >
                <span className="text-sm font-medium">Plan Activities</span>
              </Button>
            </div>
          </div>
        </section>
      </main>
      {/* Footer */}
      <footer className="bg-white border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              © {new Date()?.getFullYear()} KrishiMitra Weather Intelligence Hub. 
              Empowering farmers with accurate weather insights.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default WeatherIntelligenceHub;