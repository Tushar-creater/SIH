import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import VoiceHeroSection from './components/VoiceHeroSection';
import WeatherWidget from './components/WeatherWidget';
import FeatureGrid from './components/FeatureGrid';
import SuccessMetrics from './components/SuccessMetrics';
import TestimonialCarousel from './components/TestimonialCarousel';
import LanguageSelector from './components/LanguageSelector';
import QuickAccessCards from './components/QuickAccessCards';

const Homepage = () => {
  const [currentLanguage, setCurrentLanguage] = useState('hi');

  useEffect(() => {
    // Load saved language preference from localStorage
    const savedLanguage = localStorage.getItem('krishiMitraLanguage');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  const handleLanguageChange = (languageCode) => {
    setCurrentLanguage(languageCode);
    localStorage.setItem('krishiMitraLanguage', languageCode);
  };

  const pageTitle = currentLanguage === 'hi' ?'KrishiMitra - आपका डिजिटल खेती सलाहकार | AI-Powered कृषि सहायक' :'KrishiMitra - Your Digital Farming Advisor | AI-Powered Agricultural Assistant';

  const pageDescription = currentLanguage === 'hi' ?'KrishiMitra के साथ स्मार्ट खेती करें। AI सलाहकार, मौसम अपडेट, मंडी भाव, सरकारी योजनाएं और विशेषज्ञ सलाह - सब कुछ 22 भाषाओं में। 2M+ किसानों का भरोसा।' :'Smart farming with KrishiMitra. AI advisor, weather updates, market prices, government schemes and expert advice - all in 22 languages. Trusted by 2M+ farmers.';

  return (
    <>
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="keywords" content={currentLanguage === 'hi' ?'कृषि सलाहकार, खेती AI, मंडी भाव, मौसम अपडेट, सरकारी योजना, किसान सहायता, फसल बीमारी, जैविक खेती' :'agriculture advisor, farming AI, market prices, weather updates, government schemes, farmer assistance, crop disease, organic farming'
        } />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://krishimitra.com/homepage" />
        <meta property="og:image" content="/assets/images/krishimitra-og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content="/assets/images/krishimitra-twitter-image.jpg" />
        <link rel="canonical" href="https://krishimitra.com/homepage" />
        <meta name="robots" content="index, follow" />
        <meta name="language" content={currentLanguage === 'hi' ? 'Hindi' : 'English'} />
        <meta name="geo.region" content="IN" />
        <meta name="geo.country" content="India" />
        <meta name="author" content="KrishiMitra Team" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta httpEquiv="Content-Language" content={currentLanguage} />
      </Helmet>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <Header />

        {/* Main Content */}
        <main className="pt-16">
          {/* Voice-Activated Hero Section */}
          <VoiceHeroSection currentLanguage={currentLanguage} />

          {/* Weather Intelligence Widget */}
          <WeatherWidget currentLanguage={currentLanguage} />

          {/* Core Services Feature Grid */}
          <FeatureGrid currentLanguage={currentLanguage} />

          {/* Success Metrics & Farmer Showcase */}
          <SuccessMetrics currentLanguage={currentLanguage} />

          {/* Testimonial Carousel */}
          <TestimonialCarousel currentLanguage={currentLanguage} />

          {/* Quick Access Cards */}
          <QuickAccessCards currentLanguage={currentLanguage} />

          {/* Language Selector */}
          <LanguageSelector 
            currentLanguage={currentLanguage} 
            onLanguageChange={handleLanguageChange} 
          />
        </main>

        {/* Footer */}
        <footer className="bg-primary text-primary-foreground py-12">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {/* Brand Section */}
                <div className="md:col-span-2">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                      <span className="text-white font-bold text-lg">K</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-poppins font-bold">KrishiMitra</h3>
                      <p className="text-sm opacity-80">
                        {currentLanguage === 'hi' ? 'डिजिटल खेती का ज्ञान' : 'Digital Farming Wisdom'}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm opacity-90 mb-4 max-w-md">
                    {currentLanguage === 'hi' ?'भारत का सबसे भरोसेमंद AI-पावर्ड कृषि सलाहकार। 2M+ किसानों का साथी।' :'India\'s most trusted AI-powered agricultural advisor. Companion to 2M+ farmers.'
                    }
                  </p>
                  <div className="text-xs opacity-70">
                    © {new Date()?.getFullYear()} KrishiMitra. {currentLanguage === 'hi' ? 'सभी अधिकार सुरक्षित।' : 'All rights reserved.'}
                  </div>
                </div>

                {/* Quick Links */}
                <div>
                  <h4 className="font-poppins font-semibold mb-4">
                    {currentLanguage === 'hi' ? 'त्वरित लिंक' : 'Quick Links'}
                  </h4>
                  <ul className="space-y-2 text-sm opacity-90">
                    <li><a href="/ai-assistant-interface" className="hover:opacity-100 transition-opacity">
                      {currentLanguage === 'hi' ? 'AI सहायक' : 'AI Assistant'}
                    </a></li>
                    <li><a href="/market-intelligence-center" className="hover:opacity-100 transition-opacity">
                      {currentLanguage === 'hi' ? 'मंडी भाव' : 'Market Prices'}
                    </a></li>
                    <li><a href="/weather-intelligence-hub" className="hover:opacity-100 transition-opacity">
                      {currentLanguage === 'hi' ? 'मौसम केंद्र' : 'Weather Hub'}
                    </a></li>
                    <li><a href="/government-schemes-navigator" className="hover:opacity-100 transition-opacity">
                      {currentLanguage === 'hi' ? 'सरकारी योजनाएं' : 'Govt Schemes'}
                    </a></li>
                  </ul>
                </div>

                {/* Contact Info */}
                <div>
                  <h4 className="font-poppins font-semibold mb-4">
                    {currentLanguage === 'hi' ? 'संपर्क' : 'Contact'}
                  </h4>
                  <ul className="space-y-2 text-sm opacity-90">
                    <li>{currentLanguage === 'hi' ? 'हेल्पलाइन:' : 'Helpline:'} 1800-180-1551</li>
                    <li>{currentLanguage === 'hi' ? 'ईमेल:' : 'Email:'} help@krishimitra.com</li>
                    <li>{currentLanguage === 'hi' ? 'समय:' : 'Hours:'} 24/7</li>
                    <li className="text-xs opacity-70 mt-4">
                      {currentLanguage === 'hi' ?'भारत सरकार कृषि मंत्रालय द्वारा समर्थित' :'Supported by Ministry of Agriculture, Govt of India'
                      }
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default Homepage;