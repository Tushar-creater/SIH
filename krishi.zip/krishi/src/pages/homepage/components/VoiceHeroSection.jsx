import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VoiceHeroSection = ({ currentLanguage }) => {
  const [isListening, setIsListening] = useState(false);
  const [voiceText, setVoiceText] = useState('');
  const [isAnimating, setIsAnimating] = useState(false);

  const greetings = {
    'hi': 'नमस्ते, मैं आपका कृषिमित्र हूं',
    'en': 'Namaste, I am your KrishiMitra',
    'bn': 'নমস্কার, আমি আপনার কৃষিমিত্র',
    'te': 'నమస్కారం, నేను మీ కృషిమిత్రుడు',
    'ta': 'வணக்கம், நான் உங்கள் கிருஷிமித்ரா',
    'gu': 'નમસ્તે, હું તમારો કૃષિમિત્ર છું',
    'mr': 'नमस्कार, मी तुमचा कृषिमित्र आहे',
    'kn': 'ನಮಸ್ಕಾರ, ನಾನು ನಿಮ್ಮ ಕೃಷಿಮಿತ್ರ',
    'pa': 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ, ਮੈਂ ਤੁਹਾਡਾ ਕ੍ਰਿਸ਼ੀਮਿਤਰ ਹਾਂ'
  };

  const ctaTexts = {
    'hi': 'अपना प्रश्न पूछें',
    'en': 'Ask Your Question',
    'bn': 'আপনার প্রশ্ন জিজ্ঞাসা করুন',
    'te': 'మీ ప్రశ్న అడగండి',
    'ta': 'உங்கள் கேள்வியைக் கேளுங்கள்',
    'gu': 'તમારો પ્રશ્ન પૂછો',
    'mr': 'तुमचा प्रश्न विचारा',
    'kn': 'ನಿಮ್ಮ ಪ್ರಶ್ನೆಯನ್ನು ಕೇಳಿ',
    'pa': 'ਆਪਣਾ ਸਵਾਲ ਪੁੱਛੋ'
  };

  const handleVoiceInput = () => {
    setIsListening(!isListening);
    setIsAnimating(true);
    
    // Simulate voice recognition
    setTimeout(() => {
      setIsAnimating(false);
      if (isListening) {
        setVoiceText('मेरी फसल में कीड़े लग गए हैं, क्या करूं?');
      } else {
        setVoiceText('');
      }
    }, 2000);
  };

  const handleCameraInput = () => {
    console.log('Camera input activated');
  };

  const handleTextInput = () => {
    console.log('Text input activated');
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(prev => !prev);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative bg-gradient-to-br from-primary/5 via-white to-accent/5 py-16 lg:py-24 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-20 h-20 bg-primary rounded-full animate-pulse"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-accent rounded-full animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-secondary rounded-full animate-pulse delay-2000"></div>
      </div>
      <div className="container mx-auto px-4 lg:px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* AI Assistant Avatar */}
          <div className="mb-8">
            <div className={`inline-flex items-center justify-center w-24 h-24 lg:w-32 lg:h-32 bg-gradient-to-br from-primary to-primary/80 rounded-full shadow-lg transition-all duration-500 ${
              isAnimating ? 'scale-110 shadow-xl' : 'scale-100'
            }`}>
              <Icon name="Bot" size={48} color="white" strokeWidth={2} />
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-success rounded-full animate-pulse">
                <div className="w-full h-full bg-success rounded-full animate-ping"></div>
              </div>
            </div>
          </div>

          {/* Greeting */}
          <div className="mb-8">
            <h1 className="text-2xl lg:text-4xl font-poppins font-bold text-primary mb-4 animate-fade-in">
              {greetings?.[currentLanguage] || greetings?.['en']}
            </h1>
            <p className="text-lg lg:text-xl text-muted-foreground font-inter">
              {currentLanguage === 'hi' ?'आपके खेती के सवालों का तुरंत जवाब पाएं' :'Get instant answers to your farming questions'
              }
            </p>
          </div>

          {/* Voice Input Section */}
          <div className="mb-12">
            <div className="relative inline-block">
              <button
                onClick={handleVoiceInput}
                className={`group relative w-20 h-20 lg:w-24 lg:h-24 rounded-full transition-all duration-300 ${
                  isListening 
                    ? 'bg-error shadow-lg animate-pulse' 
                    : 'bg-primary hover:bg-primary/90 shadow-growth hover:shadow-lg'
                }`}
              >
                <Icon 
                  name={isListening ? "MicOff" : "Mic"} 
                  size={32} 
                  color="white" 
                  strokeWidth={2.5}
                />
                
                {/* Voice Animation Rings */}
                {isListening && (
                  <>
                    <div className="absolute inset-0 rounded-full border-4 border-error/30 animate-ping"></div>
                    <div className="absolute inset-0 rounded-full border-4 border-error/20 animate-ping delay-75"></div>
                    <div className="absolute inset-0 rounded-full border-4 border-error/10 animate-ping delay-150"></div>
                  </>
                )}
              </button>

              {/* Status Indicator */}
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                <div className={`px-3 py-1 rounded-full text-xs font-medium transition-all duration-300 ${
                  isListening 
                    ? 'bg-error text-error-foreground' 
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {isListening 
                    ? (currentLanguage === 'hi' ? 'सुन रहा हूं...' : 'Listening...') 
                    : (currentLanguage === 'hi' ? 'बोलने के लिए दबाएं' : 'Tap to speak')
                  }
                </div>
              </div>
            </div>

            {/* Voice Text Display */}
            {voiceText && (
              <div className="mt-6 p-4 bg-muted rounded-lg max-w-md mx-auto animate-fade-in">
                <p className="text-sm text-foreground font-inter">{voiceText}</p>
              </div>
            )}
          </div>

          {/* Input Options */}
          <div className="mb-12">
            <h2 className="text-lg font-poppins font-semibold text-foreground mb-6">
              {ctaTexts?.[currentLanguage] || ctaTexts?.['en']}
            </h2>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-2xl mx-auto">
              {/* Voice Input */}
              <Button
                variant="default"
                size="lg"
                onClick={handleVoiceInput}
                className="w-full sm:w-auto bg-primary hover:bg-primary/90 shadow-growth"
                iconName="Mic"
                iconPosition="left"
                iconSize={20}
              >
                {currentLanguage === 'hi' ? 'आवाज़ से पूछें' : 'Voice Input'}
              </Button>

              {/* Text Input */}
              <Link to="/ai-assistant-interface" className="w-full sm:w-auto">
                <Button
                  variant="outline"
                  size="lg"
                  className="w-full border-primary text-primary hover:bg-primary/5"
                  iconName="MessageSquare"
                  iconPosition="left"
                  iconSize={20}
                >
                  {currentLanguage === 'hi' ? 'टाइप करें' : 'Type Question'}
                </Button>
              </Link>

              {/* Camera Input */}
              <Button
                variant="secondary"
                size="lg"
                onClick={handleCameraInput}
                className="w-full sm:w-auto bg-accent hover:bg-accent/90"
                iconName="Camera"
                iconPosition="left"
                iconSize={20}
              >
                {currentLanguage === 'hi' ? 'फोटो लें' : 'Take Photo'}
              </Button>
            </div>
          </div>

          {/* Quick Help Text */}
          <div className="text-center">
            <p className="text-sm text-muted-foreground font-inter mb-2">
              {currentLanguage === 'hi' ?'उदाहरण: "मेरी गेहूं की फसल पीली हो रही है" या "आज बारिश होगी क्या?"' : 'Example:"My wheat crop is turning yellow" or "Will it rain today?"'
              }
            </p>
            <div className="flex justify-center items-center space-x-4 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Icon name="Shield" size={14} />
                <span>{currentLanguage === 'hi' ? 'सुरक्षित' : 'Secure'}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Zap" size={14} />
                <span>{currentLanguage === 'hi' ? 'तुरंत जवाब' : 'Instant Response'}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Globe" size={14} />
                <span>{currentLanguage === 'hi' ? '22 भाषाएं' : '22 Languages'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VoiceHeroSection;