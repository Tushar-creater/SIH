import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const SuccessMetrics = ({ currentLanguage }) => {
  const [counters, setCounters] = useState({
    farmers: 0,
    crops: 0,
    queries: 0,
    satisfaction: 0
  });

  const targetValues = {
    farmers: 2000000,
    crops: 500,
    queries: 10000000,
    satisfaction: 98
  };

  const metrics = [
    {
      id: 'farmers',
      icon: 'Users',
      value: counters?.farmers,
      target: targetValues?.farmers,
      suffix: '+',
      title: {
        'hi': 'किसान मदद की गई',
        'en': 'Farmers Helped'
      },
      description: {
        'hi': 'देशभर के किसान',
        'en': 'Across India'
      },
      color: 'primary'
    },
    {
      id: 'crops',
      icon: 'Wheat',
      value: counters?.crops,
      target: targetValues?.crops,
      suffix: '+',
      title: {
        'hi': 'फसलों का समर्थन',
        'en': 'Crops Supported'
      },
      description: {
        'hi': 'विभिन्न फसलें',
        'en': 'Different Varieties'
      },
      color: 'success'
    },
    {
      id: 'queries',
      icon: 'MessageSquare',
      value: counters?.queries,
      target: targetValues?.queries,
      suffix: '+',
      title: {
        'hi': 'सवाल हल किए',
        'en': 'Queries Resolved'
      },
      description: {
        'hi': 'सफल समाधान',
        'en': 'Successful Solutions'
      },
      color: 'trust'
    },
    {
      id: 'satisfaction',
      icon: 'Star',
      value: counters?.satisfaction,
      target: targetValues?.satisfaction,
      suffix: '%',
      title: {
        'hi': 'संतुष्टि दर',
        'en': 'Satisfaction Rate'
      },
      description: {
        'hi': 'खुश किसान',
        'en': 'Happy Farmers'
      },
      color: 'accent'
    }
  ];

  const farmerImages = [
    {
      src: 'https://images.unsplash.com/photo-1595273670150-bd0c3c392e46?w=150&h=150&fit=crop&crop=face',
      alt: 'Farmer from Punjab',
      name: 'Rajesh Singh',
      location: 'Punjab'
    },
    {
      src: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop&crop=face',
      alt: 'Farmer from Maharashtra',
      name: 'Priya Patil',
      location: 'Maharashtra'
    },
    {
      src: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      alt: 'Farmer from Karnataka',
      name: 'Ravi Kumar',
      location: 'Karnataka'
    },
    {
      src: 'https://images.unsplash.com/photo-1494790108755-2616c9c0e8e4?w=150&h=150&fit=crop&crop=face',
      alt: 'Farmer from Tamil Nadu',
      name: 'Meera Devi',
      location: 'Tamil Nadu'
    },
    {
      src: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      alt: 'Farmer from Uttar Pradesh',
      name: 'Suresh Yadav',
      location: 'Uttar Pradesh'
    }
  ];

  useEffect(() => {
    const duration = 2000; // 2 seconds
    const steps = 60;
    const stepDuration = duration / steps;

    const intervals = Object.keys(targetValues)?.map(key => {
      const increment = targetValues?.[key] / steps;
      let currentStep = 0;

      return setInterval(() => {
        if (currentStep < steps) {
          setCounters(prev => ({
            ...prev,
            [key]: Math.floor(increment * currentStep)
          }));
          currentStep++;
        } else {
          setCounters(prev => ({
            ...prev,
            [key]: targetValues?.[key]
          }));
        }
      }, stepDuration);
    });

    return () => {
      intervals?.forEach(interval => clearInterval(interval));
    };
  }, []);

  const formatNumber = (num) => {
    if (num >= 10000000) {
      return (num / 10000000)?.toFixed(1) + 'Cr';
    } else if (num >= 100000) {
      return (num / 100000)?.toFixed(1) + 'L';
    } else if (num >= 1000) {
      return (num / 1000)?.toFixed(1) + 'K';
    }
    return num?.toString();
  };

  const getColorClasses = (color) => {
    const colorMap = {
      primary: {
        bg: 'bg-primary/10',
        text: 'text-primary',
        icon: 'text-primary'
      },
      success: {
        bg: 'bg-success/10',
        text: 'text-success',
        icon: 'text-success'
      },
      trust: {
        bg: 'bg-trust/10',
        text: 'text-trust',
        icon: 'text-trust'
      },
      accent: {
        bg: 'bg-accent/10',
        text: 'text-accent',
        icon: 'text-accent'
      }
    };
    return colorMap?.[color] || colorMap?.primary;
  };

  return (
    <section className="bg-white py-12 lg:py-16">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-2xl lg:text-3xl font-poppins font-bold text-primary mb-4">
              {currentLanguage === 'hi' ? 'हमारी उपलब्धियां' : 'Our Impact'}
            </h2>
            <p className="text-lg text-muted-foreground font-inter max-w-2xl mx-auto">
              {currentLanguage === 'hi' ?'लाखों किसानों का भरोसा और सफलता की कहानियां' :'Trusted by millions of farmers with countless success stories'
              }
            </p>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {metrics?.map((metric) => {
              const colors = getColorClasses(metric?.color);
              
              return (
                <div
                  key={metric?.id}
                  className="text-center p-6 rounded-xl bg-card border border-border hover:shadow-lg transition-all duration-300 animate-fade-in"
                >
                  <div className={`inline-flex items-center justify-center w-16 h-16 ${colors?.bg} rounded-full mb-4`}>
                    <Icon name={metric?.icon} size={24} className={colors?.icon} />
                  </div>
                  <div className={`text-3xl lg:text-4xl font-bold ${colors?.text} mb-2`}>
                    {formatNumber(metric?.value)}{metric?.suffix}
                  </div>
                  <h3 className="text-sm lg:text-base font-poppins font-semibold text-foreground mb-1">
                    {metric?.title?.[currentLanguage] || metric?.title?.['en']}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {metric?.description?.[currentLanguage] || metric?.description?.['en']}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Farmer Showcase */}
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 rounded-xl p-8">
            <div className="text-center mb-8">
              <h3 className="text-xl lg:text-2xl font-poppins font-bold text-foreground mb-2">
                {currentLanguage === 'hi' ? 'हमारे किसान भाई-बहन' : 'Our Farmer Community'}
              </h3>
              <p className="text-muted-foreground font-inter">
                {currentLanguage === 'hi' ?'देश के कोने-कोने से जुड़े हुए किसान' :'Connected farmers from every corner of the country'
                }
              </p>
            </div>

            {/* Farmer Avatars */}
            <div className="flex justify-center items-center space-x-4 mb-6">
              {farmerImages?.slice(0, 5)?.map((farmer, index) => (
                <div
                  key={index}
                  className="relative group"
                  style={{ zIndex: farmerImages?.length - index }}
                >
                  <div className="w-12 h-12 lg:w-16 lg:h-16 rounded-full overflow-hidden border-4 border-white shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <Image
                      src={farmer?.src}
                      alt={farmer?.alt}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-foreground text-background text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
                    {farmer?.name}, {farmer?.location}
                  </div>
                </div>
              ))}
              
              {/* More Indicator */}
              <div className="w-12 h-12 lg:w-16 lg:h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shadow-lg">
                2M+
              </div>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Icon name="Shield" size={16} className="text-success" />
                <span>{currentLanguage === 'hi' ? 'सुरक्षित और भरोसेमंद' : 'Safe & Trusted'}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Clock" size={16} className="text-trust" />
                <span>{currentLanguage === 'hi' ? '24/7 उपलब्ध' : '24/7 Available'}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Globe" size={16} className="text-accent" />
                <span>{currentLanguage === 'hi' ? '22 भाषाओं में' : '22 Languages'}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Award" size={16} className="text-warning" />
                <span>{currentLanguage === 'hi' ? 'सरकारी मान्यता प्राप्त' : 'Government Recognized'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SuccessMetrics;