import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickAccessCards = ({ currentLanguage }) => {
  const quickActions = [
    {
      id: 'weather-alerts',
      title: {
        'hi': 'मौसम अलर्ट',
        'en': 'Weather Alerts'
      },
      description: {
        'hi': 'तुरंत मौसम की चेतावनी पाएं',
        'en': 'Get instant weather warnings'
      },
      icon: 'CloudLightning',
      color: 'warning',
      urgency: 'high',
      path: '/weather-intelligence-hub',
      stats: '2 Active Alerts',
      action: {
        'hi': 'अलर्ट देखें',
        'en': 'View Alerts'
      }
    },
    {
      id: 'crop-scanner',
      title: {
        'hi': 'फसल स्कैनर',
        'en': 'Crop Disease Scanner'
      },
      description: {
        'hi': 'फोटो से बीमारी पहचानें',
        'en': 'Identify diseases from photos'
      },
      icon: 'Camera',
      color: 'primary',
      urgency: 'medium',
      path: '/ai-assistant-interface',
      stats: '95% Accuracy',
      action: {
        'hi': 'स्कैन करें',
        'en': 'Scan Now'
      }
    },
    {
      id: 'market-prices',
      title: {
        'hi': 'मंडी भाव',
        'en': 'Market Prices'
      },
      description: {
        'hi': 'आज के ताजा भाव देखें',
        'en': 'Check today\'s fresh prices'
      },
      icon: 'TrendingUp',
      color: 'success',
      urgency: 'medium',
      path: '/market-intelligence-center',
      stats: 'Updated 5 min ago',
      action: {
        'hi': 'भाव देखें',
        'en': 'Check Prices'
      }
    },
    {
      id: 'emergency-help',
      title: {
        'hi': 'आपातकालीन सहायता',
        'en': 'Emergency Help'
      },
      description: {
        'hi': 'तुरंत विशेषज्ञ से बात करें',
        'en': 'Talk to expert immediately'
      },
      icon: 'Phone',
      color: 'error',
      urgency: 'high',
      path: '/officer-connect-portal',
      stats: '24/7 Available',
      action: {
        'hi': 'कॉल करें',
        'en': 'Call Now'
      }
    },
    {
      id: 'schemes',
      title: {
        'hi': 'नई योजनाएं',
        'en': 'New Schemes'
      },
      description: {
        'hi': 'सरकारी योजनाओं की जानकारी',
        'en': 'Government scheme information'
      },
      icon: 'Gift',
      color: 'trust',
      urgency: 'low',
      path: '/government-schemes-navigator',
      stats: '5 New This Week',
      action: {
        'hi': 'देखें',
        'en': 'Explore'
      }
    },
    {
      id: 'voice-assistant',
      title: {
        'hi': 'आवाज़ सहायक',
        'en': 'Voice Assistant'
      },
      description: {
        'hi': 'बोलकर सवाल पूछें',
        'en': 'Ask questions by speaking'
      },
      icon: 'Mic',
      color: 'accent',
      urgency: 'medium',
      path: '/ai-assistant-interface',
      stats: 'Always Ready',
      action: {
        'hi': 'बोलें',
        'en': 'Speak'
      }
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      primary: {
        bg: 'bg-primary/5',
        border: 'border-primary/20',
        icon: 'text-primary',
        iconBg: 'bg-primary/10',
        button: 'bg-primary hover:bg-primary/90 text-primary-foreground',
        accent: 'bg-primary',
        text: 'text-primary'
      },
      success: {
        bg: 'bg-success/5',
        border: 'border-success/20',
        icon: 'text-success',
        iconBg: 'bg-success/10',
        button: 'bg-success hover:bg-success/90 text-success-foreground',
        accent: 'bg-success',
        text: 'text-success'
      },
      warning: {
        bg: 'bg-warning/5',
        border: 'border-warning/20',
        icon: 'text-warning',
        iconBg: 'bg-warning/10',
        button: 'bg-warning hover:bg-warning/90 text-warning-foreground',
        accent: 'bg-warning',
        text: 'text-warning'
      },
      error: {
        bg: 'bg-error/5',
        border: 'border-error/20',
        icon: 'text-error',
        iconBg: 'bg-error/10',
        button: 'bg-error hover:bg-error/90 text-error-foreground',
        accent: 'bg-error',
        text: 'text-error'
      },
      trust: {
        bg: 'bg-trust/5',
        border: 'border-trust/20',
        icon: 'text-trust',
        iconBg: 'bg-trust/10',
        button: 'bg-trust hover:bg-trust/90 text-trust-foreground',
        accent: 'bg-trust',
        text: 'text-trust'
      },
      accent: {
        bg: 'bg-accent/5',
        border: 'border-accent/20',
        icon: 'text-accent',
        iconBg: 'bg-accent/10',
        button: 'bg-accent hover:bg-accent/90 text-accent-foreground',
        accent: 'bg-accent',
        text: 'text-accent'
      }
    };
    return colorMap?.[color] || colorMap?.primary;
  };

  const getUrgencyIndicator = (urgency) => {
    switch (urgency) {
      case 'high':
        return 'animate-pulse';
      case 'medium':
        return 'animate-bounce';
      default:
        return '';
    }
  };

  return (
    <section className="bg-white py-12 lg:py-16">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-2xl lg:text-3xl font-poppins font-bold text-primary mb-4">
              {currentLanguage === 'hi' ? 'तुरंत सहायता' : 'Quick Access'}
            </h2>
            <p className="text-lg text-muted-foreground font-inter max-w-2xl mx-auto">
              {currentLanguage === 'hi' ?'आपकी जरूरी समस्याओं का तुरंत समाधान - एक क्लिक में' :'Instant solutions for your urgent farming needs - just one click away'
              }
            </p>
          </div>

          {/* Quick Access Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {quickActions?.map((action) => {
              const colors = getColorClasses(action?.color);
              const urgencyClass = getUrgencyIndicator(action?.urgency);
              
              return (
                <div
                  key={action?.id}
                  className={`group relative ${colors?.bg} ${colors?.border} border rounded-xl p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 animate-fade-in`}
                >
                  {/* Urgency Indicator */}
                  {action?.urgency === 'high' && (
                    <div className={`absolute -top-2 -right-2 w-4 h-4 ${colors?.accent} rounded-full ${urgencyClass}`}>
                      <div className={`w-full h-full ${colors?.accent} rounded-full animate-ping`}></div>
                    </div>
                  )}
                  {/* Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className={`${colors?.iconBg} rounded-lg p-3 ${urgencyClass}`}>
                      <Icon name={action?.icon} size={24} className={colors?.icon} />
                    </div>
                    <div className={`text-xs font-medium ${colors?.text} px-2 py-1 ${colors?.iconBg} rounded-full`}>
                      {action?.stats}
                    </div>
                  </div>
                  {/* Content */}
                  <div className="mb-4">
                    <h3 className="text-lg font-poppins font-semibold text-foreground mb-2">
                      {action?.title?.[currentLanguage] || action?.title?.['en']}
                    </h3>
                    <p className="text-muted-foreground font-inter text-sm">
                      {action?.description?.[currentLanguage] || action?.description?.['en']}
                    </p>
                  </div>
                  {/* Action Button */}
                  <Link to={action?.path} className="block">
                    <Button
                      variant="default"
                      fullWidth
                      className={`${colors?.button} shadow-growth group-hover:shadow-lg transition-all duration-300`}
                      iconName="ArrowRight"
                      iconPosition="right"
                      iconSize={16}
                    >
                      {action?.action?.[currentLanguage] || action?.action?.['en']}
                    </Button>
                  </Link>
                  {/* Hover Effect */}
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
                </div>
              );
            })}
          </div>

          {/* Emergency Contact */}
          <div className="mt-12 bg-gradient-to-r from-error/5 to-warning/5 border border-error/20 rounded-xl p-6 text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-error/10 rounded-full flex items-center justify-center">
                <Icon name="AlertTriangle" size={24} className="text-error" />
              </div>
              <div>
                <h3 className="text-lg font-poppins font-bold text-foreground">
                  {currentLanguage === 'hi' ? 'आपातकालीन हेल्पलाइन' : 'Emergency Helpline'}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {currentLanguage === 'hi' ? '24/7 उपलब्ध' : '24/7 Available'}
                </p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <div className="flex items-center space-x-2 text-lg font-bold text-error">
                <Icon name="Phone" size={20} />
                <span>1800-180-1551</span>
              </div>
              
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" iconName="Phone" iconPosition="left">
                  {currentLanguage === 'hi' ? 'कॉल करें' : 'Call Now'}
                </Button>
                <Button variant="outline" size="sm" iconName="MessageSquare" iconPosition="left">
                  {currentLanguage === 'hi' ? 'चैट करें' : 'Chat Now'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default QuickAccessCards;