import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const WeatherWidget = ({ currentLanguage }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [weatherData, setWeatherData] = useState({
    location: 'Pune, Maharashtra',
    temperature: 28,
    condition: 'Partly Cloudy',
    humidity: 65,
    windSpeed: 12,
    rainfall: 0,
    uvIndex: 6,
    alerts: [
      {
        id: 1,
        type: 'warning',
        message: 'Heavy rainfall expected in next 2 hours',
        action: 'Cover crops and secure equipment'
      },
      {
        id: 2,
        type: 'info',
        message: 'Ideal conditions for wheat sowing',
        action: 'Consider starting sowing operations'
      }
    ]
  });

  const weatherTexts = {
    'hi': {
      location: 'पुणे, महाराष्ट्र',
      condition: 'आंशिक बादल',
      humidity: 'नमी',
      windSpeed: 'हवा की गति',
      rainfall: 'बारिश',
      uvIndex: 'यूवी इंडेक्स',
      alerts: 'मौसम चेतावनी',
      viewDetails: 'विस्तार देखें',
      farmingAdvice: 'खेती सलाह'
    },
    'en': {
      location: 'Pune, Maharashtra',
      condition: 'Partly Cloudy',
      humidity: 'Humidity',
      windSpeed: 'Wind Speed',
      rainfall: 'Rainfall',
      uvIndex: 'UV Index',
      alerts: 'Weather Alerts',
      viewDetails: 'View Details',
      farmingAdvice: 'Farming Advice'
    }
  };

  const alertMessages = {
    'hi': [
      {
        type: 'warning',
        message: 'अगले 2 घंटों में भारी बारिश की संभावना',
        action: 'फसलों को ढकें और उपकरण सुरक्षित करें'
      },
      {
        type: 'info',
        message: 'गेहूं की बुआई के लिए आदर्श स्थितियां',
        action: 'बुआई शुरू करने पर विचार करें'
      }
    ],
    'en': [
      {
        type: 'warning',
        message: 'Heavy rainfall expected in next 2 hours',
        action: 'Cover crops and secure equipment'
      },
      {
        type: 'info',
        message: 'Ideal conditions for wheat sowing',
        action: 'Consider starting sowing operations'
      }
    ]
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  const getWeatherIcon = (condition) => {
    switch (condition?.toLowerCase()) {
      case 'sunny':
        return 'Sun';
      case 'partly cloudy':
        return 'CloudSun';
      case 'cloudy':
        return 'Cloud';
      case 'rainy':
        return 'CloudRain';
      case 'stormy':
        return 'CloudLightning';
      default:
        return 'CloudSun';
    }
  };

  const getAlertIcon = (type) => {
    switch (type) {
      case 'warning':
        return 'AlertTriangle';
      case 'danger':
        return 'AlertCircle';
      case 'info':
        return 'Info';
      default:
        return 'Bell';
    }
  };

  const getAlertColor = (type) => {
    switch (type) {
      case 'warning':
        return 'text-warning bg-warning/10 border-warning/20';
      case 'danger':
        return 'text-error bg-error/10 border-error/20';
      case 'info':
        return 'text-trust bg-trust/10 border-trust/20';
      default:
        return 'text-muted-foreground bg-muted border-border';
    }
  };

  const texts = weatherTexts?.[currentLanguage] || weatherTexts?.['en'];
  const alerts = alertMessages?.[currentLanguage] || alertMessages?.['en'];

  return (
    <section className="bg-white py-8 lg:py-12">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-8">
            <h2 className="text-2xl lg:text-3xl font-poppins font-bold text-primary mb-2">
              {currentLanguage === 'hi' ? 'मौसम अपडेट' : 'Weather Intelligence'}
            </h2>
            <p className="text-muted-foreground font-inter">
              {currentLanguage === 'hi' ?'आपके क्षेत्र के लिए विशेष मौसम जानकारी और खेती सलाह' :'Localized weather insights and farming recommendations'
              }
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Weather Card */}
            <div className="lg:col-span-2 bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl p-6 border border-border">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-poppins font-semibold text-foreground">
                    {texts?.location}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {currentTime?.toLocaleDateString('en-IN', { 
                      weekday: 'long', 
                      day: 'numeric', 
                      month: 'long' 
                    })} • {currentTime?.toLocaleTimeString('en-IN', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                </div>
                <Link to="/weather-intelligence-hub">
                  <Button variant="outline" size="sm" iconName="ExternalLink" iconPosition="right">
                    {texts?.viewDetails}
                  </Button>
                </Link>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {/* Temperature */}
                <div className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Icon name={getWeatherIcon(weatherData?.condition)} size={24} className="text-primary" />
                  </div>
                  <div className="text-2xl font-bold text-primary">{weatherData?.temperature}°C</div>
                  <div className="text-xs text-muted-foreground">{texts?.condition}</div>
                </div>

                {/* Humidity */}
                <div className="text-center">
                  <div className="w-16 h-16 bg-trust/10 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Icon name="Droplets" size={24} className="text-trust" />
                  </div>
                  <div className="text-2xl font-bold text-trust">{weatherData?.humidity}%</div>
                  <div className="text-xs text-muted-foreground">{texts?.humidity}</div>
                </div>

                {/* Wind Speed */}
                <div className="text-center">
                  <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Icon name="Wind" size={24} className="text-accent" />
                  </div>
                  <div className="text-2xl font-bold text-accent">{weatherData?.windSpeed}</div>
                  <div className="text-xs text-muted-foreground">km/h</div>
                </div>

                {/* UV Index */}
                <div className="text-center">
                  <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Icon name="Sun" size={24} className="text-warning" />
                  </div>
                  <div className="text-2xl font-bold text-warning">{weatherData?.uvIndex}</div>
                  <div className="text-xs text-muted-foreground">{texts?.uvIndex}</div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" iconName="CloudRain" iconPosition="left">
                  {currentLanguage === 'hi' ? '7-दिन पूर्वानुमान' : '7-Day Forecast'}
                </Button>
                <Button variant="outline" size="sm" iconName="Satellite" iconPosition="left">
                  {currentLanguage === 'hi' ? 'रडार मैप' : 'Radar Map'}
                </Button>
                <Button variant="outline" size="sm" iconName="Bell" iconPosition="left">
                  {currentLanguage === 'hi' ? 'अलर्ट सेट करें' : 'Set Alerts'}
                </Button>
              </div>
            </div>

            {/* Weather Alerts */}
            <div className="space-y-4">
              <h3 className="text-lg font-poppins font-semibold text-foreground flex items-center space-x-2">
                <Icon name="Bell" size={20} />
                <span>{texts?.alerts}</span>
              </h3>

              {alerts?.map((alert, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${getAlertColor(alert?.type)} transition-all duration-300 hover:shadow-md`}
                >
                  <div className="flex items-start space-x-3">
                    <Icon name={getAlertIcon(alert?.type)} size={20} className="flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium mb-1">{alert?.message}</p>
                      <p className="text-xs opacity-80">{alert?.action}</p>
                    </div>
                  </div>
                </div>
              ))}

              {/* Farming Advice Card */}
              <div className="bg-success/5 border border-success/20 rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Lightbulb" size={18} className="text-success" />
                  <h4 className="font-medium text-success">{texts?.farmingAdvice}</h4>
                </div>
                <p className="text-sm text-foreground">
                  {currentLanguage === 'hi' ?'मौजूदा मौसम की स्थिति के अनुसार, यह धान की रोपाई के लिए उपयुक्त समय है।' :'Based on current weather conditions, this is an ideal time for rice transplantation.'
                  }
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WeatherWidget;