import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FeatureGrid = ({ currentLanguage }) => {
  const features = [
    {
      id: 'ai-advisory',
      title: {
        'hi': 'AI सलाहकार',
        'en': 'AI Advisory'
      },
      description: {
        'hi': 'फसल की समस्याओं का तुरंत समाधान पाएं',
        'en': 'Get instant solutions for crop problems'
      },
      icon: 'Brain',
      secondaryIcon: 'Sprout',
      color: 'primary',
      path: '/ai-assistant-interface',
      stats: {
        'hi': '50,000+ समस्याएं हल',
        'en': '50,000+ Problems Solved'
      },
      features: [
        {
          'hi': 'तुरंत जवाब',
          'en': 'Instant Answers'
        },
        {
          'hi': 'फोटो से पहचान',
          'en': 'Photo Recognition'
        },
        {
          'hi': '22 भाषाओं में',
          'en': '22 Languages'
        }
      ]
    },
    {
      id: 'market-intelligence',
      title: {
        'hi': 'बाज़ार जानकारी',
        'en': 'Market Intelligence'
      },
      description: {
        'hi': 'सबसे अच्छी कीमत पर बेचें',
        'en': 'Sell at the best prices'
      },
      icon: 'TrendingUp',
      secondaryIcon: 'IndianRupee',
      color: 'trust',
      path: '/market-intelligence-center',
      stats: {
        'hi': '500+ मंडियों के भाव',
        'en': '500+ Market Prices'
      },
      features: [
        {
          'hi': 'लाइव भाव',
          'en': 'Live Prices'
        },
        {
          'hi': 'भविष्य की कीमत',
          'en': 'Price Predictions'
        },
        {
          'hi': 'बेहतर मंडी',
          'en': 'Best Markets'
        }
      ]
    },
    {
      id: 'government-schemes',
      title: {
        'hi': 'सरकारी योजनाएं',
        'en': 'Government Schemes'
      },
      description: {
        'hi': 'सब्सिडी और लाभ प्राप्त करें',
        'en': 'Access subsidies and benefits'
      },
      icon: 'Building2',
      secondaryIcon: 'FileText',
      color: 'accent',
      path: '/government-schemes-navigator',
      stats: {
        'hi': '200+ योजनाएं',
        'en': '200+ Schemes'
      },
      features: [
        {
          'hi': 'पात्रता जांच',
          'en': 'Eligibility Check'
        },
        {
          'hi': 'आवेदन सहायता',
          'en': 'Application Help'
        },
        {
          'hi': 'स्टेटस ट्रैकिंग',
          'en': 'Status Tracking'
        }
      ]
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      primary: {
        bg: 'bg-primary/5',
        border: 'border-primary/20',
        icon: 'text-primary',
        iconBg: 'bg-primary/10',
        button: 'bg-primary hover:bg-primary/90',
        accent: 'bg-primary',
        text: 'text-primary'
      },
      trust: {
        bg: 'bg-trust/5',
        border: 'border-trust/20',
        icon: 'text-trust',
        iconBg: 'bg-trust/10',
        button: 'bg-trust hover:bg-trust/90',
        accent: 'bg-trust',
        text: 'text-trust'
      },
      accent: {
        bg: 'bg-accent/5',
        border: 'border-accent/20',
        icon: 'text-accent',
        iconBg: 'bg-accent/10',
        button: 'bg-accent hover:bg-accent/90',
        accent: 'bg-accent',
        text: 'text-accent'
      }
    };
    return colorMap?.[color] || colorMap?.primary;
  };

  return (
    <section className="bg-muted/30 py-12 lg:py-16">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-2xl lg:text-3xl font-poppins font-bold text-primary mb-4">
              {currentLanguage === 'hi' ? 'मुख्य सेवाएं' : 'Core Services'}
            </h2>
            <p className="text-lg text-muted-foreground font-inter max-w-2xl mx-auto">
              {currentLanguage === 'hi' ?'आधुनिक तकनीक के साथ खेती को आसान और लाभदायक बनाएं' :'Make farming easier and more profitable with modern technology'
              }
            </p>
          </div>

          {/* Feature Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {features?.map((feature) => {
              const colors = getColorClasses(feature?.color);
              
              return (
                <div
                  key={feature?.id}
                  className={`group relative ${colors?.bg} ${colors?.border} border rounded-xl p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 animate-fade-in`}
                >
                  {/* Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className={`relative ${colors?.iconBg} rounded-lg p-3`}>
                        <Icon name={feature?.icon} size={24} className={colors?.icon} />
                        <div className={`absolute -top-1 -right-1 w-4 h-4 ${colors?.accent} rounded-full flex items-center justify-center`}>
                          <Icon name={feature?.secondaryIcon} size={10} color="white" />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-lg font-poppins font-semibold text-foreground">
                          {feature?.title?.[currentLanguage] || feature?.title?.['en']}
                        </h3>
                      </div>
                    </div>
                    <div className={`w-2 h-2 ${colors?.accent} rounded-full animate-pulse`}></div>
                  </div>
                  {/* Description */}
                  <p className="text-muted-foreground font-inter mb-4">
                    {feature?.description?.[currentLanguage] || feature?.description?.['en']}
                  </p>
                  {/* Stats */}
                  <div className={`inline-flex items-center space-x-2 px-3 py-1 ${colors?.iconBg} rounded-full mb-4`}>
                    <Icon name="CheckCircle" size={14} className={colors?.icon} />
                    <span className={`text-sm font-medium ${colors?.text}`}>
                      {feature?.stats?.[currentLanguage] || feature?.stats?.['en']}
                    </span>
                  </div>
                  {/* Features List */}
                  <div className="space-y-2 mb-6">
                    {feature?.features?.map((featureItem, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Icon name="Check" size={14} className={colors?.icon} />
                        <span className="text-sm text-foreground font-inter">
                          {featureItem?.[currentLanguage] || featureItem?.['en']}
                        </span>
                      </div>
                    ))}
                  </div>
                  {/* CTA Button */}
                  <Link to={feature?.path} className="block">
                    <Button
                      variant="default"
                      fullWidth
                      className={`${colors?.button} text-white shadow-growth group-hover:shadow-lg transition-all duration-300`}
                      iconName="ArrowRight"
                      iconPosition="right"
                      iconSize={16}
                    >
                      {currentLanguage === 'hi' ? 'शुरू करें' : 'Get Started'}
                    </Button>
                  </Link>
                  {/* Hover Effect */}
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
                </div>
              );
            })}
          </div>

          {/* Additional Services */}
          <div className="mt-12 text-center">
            <h3 className="text-lg font-poppins font-semibold text-foreground mb-6">
              {currentLanguage === 'hi' ? 'अन्य सेवाएं' : 'Additional Services'}
            </h3>
            
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/weather-intelligence-hub">
                <Button variant="outline" iconName="Cloud" iconPosition="left">
                  {currentLanguage === 'hi' ? 'मौसम केंद्र' : 'Weather Hub'}
                </Button>
              </Link>
              
              <Link to="/officer-connect-portal">
                <Button variant="outline" iconName="Users" iconPosition="left">
                  {currentLanguage === 'hi' ? 'अधिकारी संपर्क' : 'Officer Connect'}
                </Button>
              </Link>
              
              <Button variant="outline" iconName="BookOpen" iconPosition="left">
                {currentLanguage === 'hi' ? 'ज्ञान केंद्र' : 'Knowledge Center'}
              </Button>
              
              <Button variant="outline" iconName="Users2" iconPosition="left">
                {currentLanguage === 'hi' ? 'किसान समुदाय' : 'Farmer Community'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeatureGrid;