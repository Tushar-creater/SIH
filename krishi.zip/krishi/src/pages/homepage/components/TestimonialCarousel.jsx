import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const TestimonialCarousel = ({ currentLanguage }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const testimonials = [
    {
      id: 1,
      name: 'राजेश सिंह',
      nameEn: 'Rajesh Singh',
      location: 'पंजाब',
      locationEn: 'Punjab',
      crop: 'गेहूं',
      cropEn: 'Wheat',
      image: 'https://images.unsplash.com/photo-1595273670150-bd0c3c392e46?w=300&h=300&fit=crop&crop=face',
      testimonial: {
        'hi': `KrishiMitra की सलाह से मेरी गेहूं की पैदावार 25% बढ़ गई है। AI असिस्टेंट ने मेरी फसल की बीमारी को तुरंत पहचाना और सही इलाज बताया। अब मैं हर समस्या के लिए KrishiMitra का इस्तेमाल करता हूं।`,
        'en': `With KrishiMitra's advice, my wheat yield increased by 25%. The AI assistant immediately identified my crop disease and provided the right treatment. Now I use KrishiMitra for every farming problem.`
      },
      yieldIncrease: '25%',incomeIncrease: '₹45,000',
      rating: 5,
      verified: true
    },
    {
      id: 2,
      name: 'प्रिया पाटिल',nameEn: 'Priya Patil',location: 'महाराष्ट्र',locationEn: 'Maharashtra',crop: 'कपास',cropEn: 'Cotton',image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=300&h=300&fit=crop&crop=face',
      testimonial: {
        'hi': `मार्केट इंटेलिजेंस की मदद से मैंने अपनी कपास सही समय पर सही दाम में बेची। पहले मैं बिचौलियों के भरोसे थी, अब मुझे पता है कि कहां और कब बेचना है। मेरी आय दोगुनी हो गई है।`,'en': `With Market Intelligence help, I sold my cotton at the right time and right price. Earlier I depended on middlemen, now I know where and when to sell. My income has doubled.`
      },
      yieldIncrease: '18%',incomeIncrease: '₹80,000',
      rating: 5,
      verified: true
    },
    {
      id: 3,
      name: 'रवि कुमार',nameEn: 'Ravi Kumar',location: 'कर्नाटक',locationEn: 'Karnataka',crop: 'धान',cropEn: 'Rice',image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face',
      testimonial: {
        'hi': `सरकारी योजनाओं की जानकारी मिलने से मुझे ₹2 लाख की सब्सिडी मिली। KrishiMitra ने मेरा आवेदन भरने में भी मदद की। अब मेरे पास नया ट्रैक्टर और बेहतर उपकरण हैं।`,'en': `Getting information about government schemes helped me get ₹2 lakh subsidy. KrishiMitra also helped me fill the application. Now I have a new tractor and better equipment.`
      },
      yieldIncrease: '30%',incomeIncrease: '₹1,20,000',
      rating: 5,
      verified: true
    },
    {
      id: 4,
      name: 'मीरा देवी',nameEn: 'Meera Devi',location: 'तमिलनाडु',locationEn: 'Tamil Nadu',crop: 'टमाटर',cropEn: 'Tomato',image: 'https://images.unsplash.com/photo-1494790108755-2616c9c0e8e4?w=300&h=300&fit=crop&crop=face',
      testimonial: {
        'hi': `मौसम की सही जानकारी से मैंने अपनी टमाटर की फसल को नुकसान से बचाया। KrishiMitra का वेदर अलर्ट मिलते ही मैंने फसल को ढक दिया। इससे मेरा ₹60,000 का नुकसान बचा।`,'en': `With accurate weather information, I saved my tomato crop from damage. As soon as I got KrishiMitra's weather alert, I covered the crop. This saved me ₹60,000 in losses.`
      },
      yieldIncrease: '22%',
      incomeIncrease: '₹60,000',
      rating: 5,
      verified: true
    },
    {
      id: 5,
      name: 'सुरेश यादव',
      nameEn: 'Suresh Yadav',
      location: 'उत्तर प्रदेश',
      locationEn: 'Uttar Pradesh',
      crop: 'गन्ना',
      cropEn: 'Sugarcane',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face',
      testimonial: {
        'hi': `KrishiMitra के AI असिस्टेंट से मैंने जैविक खेती के बारे में सीखा। अब मैं कम लागत में ज्यादा मुनाफा कमा रहा हूं। मेरी मिट्टी की गुणवत्ता भी बेहतर हो गई है।`,
        'en': `I learned about organic farming from KrishiMitra's AI assistant. Now I'm earning more profit with less cost. My soil quality has also improved.`
      },
      yieldIncrease: '35%',
      incomeIncrease: '₹95,000',
      rating: 5,
      verified: true
    }
  ];

  useEffect(() => {
    if (isAutoPlaying) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % testimonials?.length);
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [isAutoPlaying, testimonials?.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % testimonials?.length);
    setIsAutoPlaying(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + testimonials?.length) % testimonials?.length);
    setIsAutoPlaying(false);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
  };

  const currentTestimonial = testimonials?.[currentSlide];

  return (
    <section className="bg-gradient-to-br from-primary/5 via-white to-accent/5 py-12 lg:py-16">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-2xl lg:text-3xl font-poppins font-bold text-primary mb-4">
              {currentLanguage === 'hi' ? 'सफलता की कहानियां' : 'Success Stories'}
            </h2>
            <p className="text-lg text-muted-foreground font-inter max-w-2xl mx-auto">
              {currentLanguage === 'hi' ?'देखिए कैसे KrishiMitra ने हजारों किसानों की जिंदगी बदली है' :'See how KrishiMitra has transformed the lives of thousands of farmers'
              }
            </p>
          </div>

          {/* Testimonial Card */}
          <div className="relative bg-white rounded-2xl shadow-lg p-8 lg:p-12 mb-8">
            {/* Navigation Buttons */}
            <div className="absolute top-1/2 -translate-y-1/2 left-4 lg:-left-6">
              <Button
                variant="outline"
                size="icon"
                onClick={prevSlide}
                className="w-12 h-12 rounded-full bg-white shadow-lg border-primary/20 hover:border-primary hover:bg-primary/5"
              >
                <Icon name="ChevronLeft" size={20} />
              </Button>
            </div>
            
            <div className="absolute top-1/2 -translate-y-1/2 right-4 lg:-right-6">
              <Button
                variant="outline"
                size="icon"
                onClick={nextSlide}
                className="w-12 h-12 rounded-full bg-white shadow-lg border-primary/20 hover:border-primary hover:bg-primary/5"
              >
                <Icon name="ChevronRight" size={20} />
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
              {/* Farmer Profile */}
              <div className="text-center lg:text-left">
                <div className="relative inline-block mb-4">
                  <div className="w-24 h-24 lg:w-32 lg:h-32 rounded-full overflow-hidden border-4 border-primary/20 shadow-lg">
                    <Image
                      src={currentTestimonial?.image}
                      alt={`${currentTestimonial?.nameEn} - Farmer`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {currentTestimonial?.verified && (
                    <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-success rounded-full flex items-center justify-center border-2 border-white">
                      <Icon name="CheckCircle" size={16} color="white" />
                    </div>
                  )}
                </div>

                <h3 className="text-xl font-poppins font-bold text-foreground mb-1">
                  {currentLanguage === 'hi' ? currentTestimonial?.name : currentTestimonial?.nameEn}
                </h3>
                
                <p className="text-muted-foreground font-inter mb-2">
                  {currentLanguage === 'hi' ? currentTestimonial?.location : currentTestimonial?.locationEn}
                </p>
                
                <div className="inline-flex items-center space-x-2 px-3 py-1 bg-primary/10 rounded-full">
                  <Icon name="Wheat" size={14} className="text-primary" />
                  <span className="text-sm font-medium text-primary">
                    {currentLanguage === 'hi' ? currentTestimonial?.crop : currentTestimonial?.cropEn}
                  </span>
                </div>

                {/* Rating */}
                <div className="flex justify-center lg:justify-start items-center space-x-1 mt-3">
                  {[...Array(currentTestimonial?.rating)]?.map((_, i) => (
                    <Icon key={i} name="Star" size={16} className="text-warning fill-current" />
                  ))}
                </div>
              </div>

              {/* Testimonial Content */}
              <div className="lg:col-span-2">
                <div className="relative">
                  <Icon name="Quote" size={32} className="text-primary/20 absolute -top-4 -left-2" />
                  <blockquote className="text-foreground font-inter text-lg leading-relaxed pl-6">
                    {currentTestimonial?.testimonial?.[currentLanguage] || currentTestimonial?.testimonial?.['en']}
                  </blockquote>
                </div>

                {/* Success Metrics */}
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="bg-success/10 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-success mb-1">
                      {currentTestimonial?.yieldIncrease}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {currentLanguage === 'hi' ? 'उत्पादन वृद्धि' : 'Yield Increase'}
                    </div>
                  </div>
                  
                  <div className="bg-accent/10 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-accent mb-1">
                      {currentTestimonial?.incomeIncrease}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {currentLanguage === 'hi' ? 'आय वृद्धि' : 'Income Increase'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center space-x-2 mb-8">
            {testimonials?.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentSlide 
                    ? 'bg-primary scale-125' :'bg-primary/30 hover:bg-primary/50'
                }`}
              />
            ))}
          </div>

          {/* Auto-play Control */}
          <div className="text-center">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              iconName={isAutoPlaying ? "Pause" : "Play"}
              iconPosition="left"
              iconSize={16}
            >
              {isAutoPlaying 
                ? (currentLanguage === 'hi' ? 'रोकें' : 'Pause') 
                : (currentLanguage === 'hi' ? 'चलाएं' : 'Play')
              }
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialCarousel;