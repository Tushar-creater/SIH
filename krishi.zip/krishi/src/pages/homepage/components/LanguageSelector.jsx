import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LanguageSelector = ({ currentLanguage, onLanguageChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const languages = [
    { code: 'hi', name: 'हिंदी', nameEn: 'Hindi', flag: '🇮🇳', region: 'North India' },
    { code: 'en', name: 'English', nameEn: 'English', flag: '🇬🇧', region: 'Global' },
    { code: 'bn', name: 'বাংলা', nameEn: 'Bengali', flag: '🇧🇩', region: 'West Bengal' },
    { code: 'te', name: 'తెలుగు', nameEn: 'Telugu', flag: '🇮🇳', region: 'Andhra Pradesh' },
    { code: 'ta', name: 'தமிழ்', nameEn: 'Tamil', flag: '🇮🇳', region: 'Tamil Nadu' },
    { code: 'gu', name: 'ગુજરાતી', nameEn: 'Gujarati', flag: '🇮🇳', region: 'Gujarat' },
    { code: 'mr', name: 'मराठी', nameEn: 'Marathi', flag: '🇮🇳', region: 'Maharashtra' },
    { code: 'kn', name: 'ಕನ್ನಡ', nameEn: 'Kannada', flag: '🇮🇳', region: 'Karnataka' },
    { code: 'pa', name: 'ਪੰਜਾਬੀ', nameEn: 'Punjabi', flag: '🇮🇳', region: 'Punjab' },
    { code: 'or', name: 'ଓଡ଼ିଆ', nameEn: 'Odia', flag: '🇮🇳', region: 'Odisha' },
    { code: 'as', name: 'অসমীয়া', nameEn: 'Assamese', flag: '🇮🇳', region: 'Assam' },
    { code: 'ml', name: 'മലയാളം', nameEn: 'Malayalam', flag: '🇮🇳', region: 'Kerala' },
    { code: 'ur', name: 'اردو', nameEn: 'Urdu', flag: '🇵🇰', region: 'North India' },
    { code: 'ne', name: 'नेपाली', nameEn: 'Nepali', flag: '🇳🇵', region: 'Nepal/Sikkim' },
    { code: 'si', name: 'සිංහල', nameEn: 'Sinhala', flag: '🇱🇰', region: 'Sri Lanka' },
    { code: 'my', name: 'မြန်မာ', nameEn: 'Myanmar', flag: '🇲🇲', region: 'Myanmar' },
    { code: 'th', name: 'ไทย', nameEn: 'Thai', flag: '🇹🇭', region: 'Thailand' },
    { code: 'vi', name: 'Tiếng Việt', nameEn: 'Vietnamese', flag: '🇻🇳', region: 'Vietnam' },
    { code: 'id', name: 'Bahasa Indonesia', nameEn: 'Indonesian', flag: '🇮🇩', region: 'Indonesia' },
    { code: 'ms', name: 'Bahasa Melayu', nameEn: 'Malay', flag: '🇲🇾', region: 'Malaysia' },
    { code: 'tl', name: 'Filipino', nameEn: 'Filipino', flag: '🇵🇭', region: 'Philippines' },
    { code: 'km', name: 'ខ្មែរ', nameEn: 'Khmer', flag: '🇰🇭', region: 'Cambodia' }
  ];

  const currentLang = languages?.find(lang => lang?.code === currentLanguage) || languages?.[0];

  const handleLanguageSelect = (languageCode) => {
    onLanguageChange(languageCode);
    setIsOpen(false);
  };

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  return (
    <section className="bg-muted/50 py-8 lg:py-12">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-8">
            <h2 className="text-2xl lg:text-3xl font-poppins font-bold text-primary mb-4">
              {currentLanguage === 'hi' ? 'अपनी भाषा चुनें' : 'Choose Your Language'}
            </h2>
            <p className="text-lg text-muted-foreground font-inter">
              {currentLanguage === 'hi' ?'KrishiMitra 22 भाषाओं में उपलब्ध है - अपनी सुविधा के अनुसार भाषा चुनें' :'KrishiMitra is available in 22 languages - choose your preferred language'
              }
            </p>
          </div>

          {/* Current Language Display */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center space-x-3 bg-white rounded-xl p-4 shadow-lg border border-border">
              <span className="text-2xl">{currentLang?.flag}</span>
              <div className="text-left">
                <div className="text-lg font-poppins font-semibold text-foreground">
                  {currentLang?.name}
                </div>
                <div className="text-sm text-muted-foreground">
                  {currentLang?.nameEn} • {currentLang?.region}
                </div>
              </div>
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            </div>
          </div>

          {/* Language Selector */}
          <div className="relative max-w-md mx-auto">
            <Button
              variant="outline"
              fullWidth
              onClick={toggleDropdown}
              className="justify-between h-12 text-left border-primary/20 hover:border-primary"
              iconName={isOpen ? "ChevronUp" : "ChevronDown"}
              iconPosition="right"
            >
              <div className="flex items-center space-x-3">
                <span className="text-xl">{currentLang?.flag}</span>
                <span className="font-medium">{currentLang?.name}</span>
              </div>
            </Button>

            {/* Dropdown Menu */}
            {isOpen && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-xl border border-border max-h-80 overflow-y-auto z-50 animate-fade-in">
                <div className="p-2">
                  {languages?.map((language) => (
                    <button
                      key={language?.code}
                      onClick={() => handleLanguageSelect(language?.code)}
                      className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-all duration-200 ${
                        language?.code === currentLanguage
                          ? 'bg-primary text-primary-foreground'
                          : 'hover:bg-muted text-foreground'
                      }`}
                    >
                      <span className="text-lg flex-shrink-0">{language?.flag}</span>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium truncate">{language?.name}</div>
                        <div className={`text-xs truncate ${
                          language?.code === currentLanguage 
                            ? 'text-primary-foreground/80' 
                            : 'text-muted-foreground'
                        }`}>
                          {language?.nameEn} • {language?.region}
                        </div>
                      </div>
                      {language?.code === currentLanguage && (
                        <Icon name="Check" size={16} className="text-primary-foreground flex-shrink-0" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Popular Languages Quick Access */}
          <div className="mt-8">
            <h3 className="text-center text-sm font-poppins font-semibold text-muted-foreground mb-4 uppercase tracking-wider">
              {currentLanguage === 'hi' ? 'लोकप्रिय भाषाएं' : 'Popular Languages'}
            </h3>
            
            <div className="flex flex-wrap justify-center gap-3">
              {languages?.slice(0, 8)?.map((language) => (
                <button
                  key={language?.code}
                  onClick={() => handleLanguageSelect(language?.code)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                    language?.code === currentLanguage
                      ? 'bg-primary text-primary-foreground shadow-growth'
                      : 'bg-white text-foreground hover:bg-muted border border-border hover:border-primary/30'
                  }`}
                >
                  <span>{language?.flag}</span>
                  <span>{language?.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Language Features */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-white rounded-lg border border-border">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="MessageSquare" size={24} className="text-primary" />
              </div>
              <h4 className="font-poppins font-semibold text-foreground mb-2">
                {currentLanguage === 'hi' ? 'स्थानीय भाषा में सलाह' : 'Local Language Advice'}
              </h4>
              <p className="text-sm text-muted-foreground">
                {currentLanguage === 'hi' ?'अपनी मातृभाषा में खेती की सलाह पाएं' :'Get farming advice in your native language'
                }
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg border border-border">
              <div className="w-12 h-12 bg-trust/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="Mic" size={24} className="text-trust" />
              </div>
              <h4 className="font-poppins font-semibold text-foreground mb-2">
                {currentLanguage === 'hi' ? 'आवाज़ पहचान' : 'Voice Recognition'}
              </h4>
              <p className="text-sm text-muted-foreground">
                {currentLanguage === 'hi' ?'अपनी भाषा में बोलकर सवाल पूछें' :'Ask questions by speaking in your language'
                }
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg border border-border">
              <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="Globe" size={24} className="text-accent" />
              </div>
              <h4 className="font-poppins font-semibold text-foreground mb-2">
                {currentLanguage === 'hi' ? 'क्षेत्रीय जानकारी' : 'Regional Information'}
              </h4>
              <p className="text-sm text-muted-foreground">
                {currentLanguage === 'hi' ?'आपके क्षेत्र के अनुकूल खेती की जानकारी' :'Farming information tailored to your region'
                }
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LanguageSelector;