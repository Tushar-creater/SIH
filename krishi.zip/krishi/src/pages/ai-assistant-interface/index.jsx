import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Header from '../../components/ui/Header';

// Import components
import AIAvatar from './components/AIAvatar';
import VoiceInput from './components/VoiceInput';
import ChatMessage from './components/ChatMessage';
import SmartSuggestions from './components/SmartSuggestions';
import ImageAnalysis from './components/ImageAnalysis';
import ConversationHistory from './components/ConversationHistory';
import RelatedResources from './components/RelatedResources';

const AIAssistantInterface = () => {
  const [messages, setMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [activeTab, setActiveTab] = useState('chat');
  const [userLocation, setUserLocation] = useState('दिल्ली, भारत');
  const [currentSeason, setCurrentSeason] = useState('monsoon');
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  
  const messagesEndRef = useRef(null);
  const chatContainerRef = useRef(null);

  // Mock conversation data
  const mockMessages = [
    {
      id: 1,
      sender: 'assistant',
      text: `नमस्कार! मैं KrishiMitra AI हूँ। मैं आपकी खेती से जुड़ी हर समस्या में मदद कर सकता हूँ।\n\nआप मुझसे पूछ सकते हैं:\n• फसल की बीमारियों के बारे में\n• मौसम और बुआई की जानकारी\n• सरकारी योजनाओं के बारे में\n• बाज़ार के भाव के बारे में\n\nकैसे मदद कर सकता हूँ?`,
      timestamp: new Date(Date.now() - 10 * 60 * 1000),
      category: 'General',
      hasAudio: true,
      isOffline: false
    }
  ];

  useEffect(() => {
    setMessages(mockMessages);
    
    // Check online status
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (text, image = null) => {
    if (!text?.trim() && !image) return;

    const userMessage = {
      id: Date.now(),
      sender: 'user',
      text: text?.trim(),
      image,
      timestamp: new Date(),
      isOffline
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage('');
    setIsThinking(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(text, image);
      setMessages(prev => [...prev, aiResponse]);
      setIsThinking(false);
    }, 2000);
  };

  const generateAIResponse = (query, image) => {
    let responseText = '';
    let category = 'General';
    
    const queryLower = query?.toLowerCase();
    
    if (image) {
      category = 'Disease';
      responseText = `मैंने आपकी फसल की तस्वीर का विश्लेषण किया है। यह पत्ती का धब्बा रोग (Leaf Spot Disease) लग रहा है।\n\n🔍 विश्वसनीयता: 87%\n\n📋 तुरंत करने योग्य कार्य:\n• प्रभावित पत्तियों को हटा दें\n• कॉपर सल्फेट का छिड़काव करें\n• खेत में जल निकासी सुनिश्चित करें\n\n💰 अनुमानित लागत: ₹500-800 प्रति एकड़\n\nक्या आप विशेषज्ञ से बात करना चाहेंगे?`;
    } else if (queryLower?.includes('मौसम') || queryLower?.includes('बारिश')) {
      category = 'Weather';
      responseText = `🌦️ आज का मौसम अपडेट (${userLocation}):\n\n• तापमान: 28°C - 35°C\n• आर्द्रता: 75%\n• बारिश की संभावना: 60%\n• हवा की गति: 12 km/h\n\n🌾 किसान सलाह:\n• धान की रोपाई के लिए अच्छा समय है\n• खेत में जल निकासी की व्यवस्था करें\n• कीटनाशक का छिड़काव बारिश के बाद करें\n\nक्या आप 7 दिन का मौसम पूर्वानुमान देखना चाहेंगे?`;
    } else if (queryLower?.includes('भाव') || queryLower?.includes('कीमत') || queryLower?.includes('बाज़ार')) {
      category = 'Market';
      responseText = `📈 आज के मुख्य फसलों के भाव:\n\n🌾 गेहूं: ₹2,150/क्विंटल (↑ ₹50)\n🌾 धान: ₹1,950/क्विंटल (↓ ₹25)\n🌽 मक्का: ₹1,750/क्विंटल (→ समान)\n🫘 सोयाबीन: ₹4,200/क्विंटल (↑ ₹100)\n\n💡 बाज़ार सुझाव:\n• गेहूं की कीमत बढ़ने की उम्मीद है\n• धान बेचने के लिए 1-2 सप्ताह प्रतीक्षा करें\n• सोयाबीन के लिए अच्छा समय है\n\nक्या आप किसी विशेष फसल की विस्तृत जानकारी चाहते हैं?`;
    } else if (queryLower?.includes('योजना') || queryLower?.includes('सब्सिडी') || queryLower?.includes('pm-kisan')) {
      category = 'Schemes';
      responseText = `🏛️ मुख्य सरकारी योजनाएं:\n\n💰 PM-KISAN योजना:\n• ₹6,000 सालाना (3 किस्तों में)\n• अगली किस्त: 15 अक्टूबर 2024\n• स्टेटस चेक करें: pmkisan.gov.in\n\n🌱 PM फसल बीमा योजना:\n• प्रीमियम: 2% (खरीफ), 1.5% (रबी)\n• आवेदन की अंतिम तिथि: 31 जुलाई\n\n🚜 कृषि यंत्र सब्सिडी:\n• 50% तक सब्सिडी\n• ट्रैक्टर, हार्वेस्टर, ड्रिप सिस्टम\n\nकिस योजना के बारे में विस्तार से जानना चाहते हैं?`;
    } else if (queryLower?.includes('कीड़े') || queryLower?.includes('बीमारी') || queryLower?.includes('रोग')) {
      category = 'Crops';
      responseText = `🐛 फसल में कीट-रोग प्रबंधन:\n\n🔍 सामान्य लक्षण:\n• पत्तियों पर धब्बे\n• पत्तियों का पीला होना\n• तने में छेद\n• फल का सड़ना\n\n💊 उपचार के तरीके:\n• नीम का तेल (जैविक)\n• कॉपर सल्फेट (फंगल रोग के लिए)\n• फेरोमोन ट्रैप (कीटों के लिए)\n\n📸 बेहतर सलाह के लिए:\n• फसल की तस्वीर भेजें\n• मैं AI विश्लेषण करूंगा\n• विशेषज्ञ से जोड़ सकता हूं\n\nक्या आप फसल की तस्वीर भेजना चाहेंगे?`;
    } else {
      responseText = `मैं समझ गया हूं कि आप "${query}" के बारे में पूछ रहे हैं।\n\n🤖 मैं आपकी निम्नलिखित में मदद कर सकता हूं:\n\n🌾 फसल संबंधी सलाह\n🌦️ मौसम की जानकारी\n💰 बाज़ार के भाव\n🏛️ सरकारी योजनाएं\n🔬 फसल रोग पहचान\n📞 विशेषज्ञ से संपर्क\n\nकृपया अपना सवाल और स्पष्ट रूप से पूछें या नीचे दिए गए सुझावों में से चुनें।`;
    }

    return {
      id: Date.now() + 1,
      sender: 'assistant',
      text: responseText,
      timestamp: new Date(),
      category,
      hasAudio: true,
      isOffline
    };
  };

  const handleVoiceStart = () => {
    setIsListening(true);
  };

  const handleVoiceStop = () => {
    setIsListening(false);
  };

  const handleVoiceResult = (text) => {
    setCurrentMessage(text);
    handleSendMessage(text);
  };

  const handleSuggestionClick = (suggestion) => {
    handleSendMessage(suggestion);
  };

  const handleImageAnalysis = (result) => {
    handleSendMessage('', result);
  };

  const handlePlayAudio = (messageId) => {
    console.log('Playing audio for message:', messageId);
  };

  const handleEscalate = (message) => {
    console.log('Escalating to officer:', message);
  };

  const handleSaveResponse = (message) => {
    console.log('Saving response:', message);
  };

  const handleClearHistory = () => {
    setMessages([mockMessages?.[0]]);
  };

  const handleLoadMore = () => {
    console.log('Loading more messages...');
  };

  const handleEmergencyQuery = () => {
    setShowEmergencyModal(true);
  };

  const handleKeyPress = (e) => {
    if (e?.key === 'Enter' && !e?.shiftKey) {
      e?.preventDefault();
      handleSendMessage(currentMessage);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-poppins font-bold text-foreground">
                  KrishiMitra AI Assistant
                </h1>
                <p className="text-muted-foreground mt-1">
                  आपका व्यक्तिगत कृषि सलाहकार - 24/7 उपलब्ध
                </p>
              </div>
              
              {/* Status Indicators */}
              <div className="flex items-center space-x-4">
                <div className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm ${
                  isOffline ? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'
                }`}>
                  <Icon name={isOffline ? 'WifiOff' : 'Wifi'} size={14} />
                  <span>{isOffline ? 'ऑफलाइन' : 'ऑनलाइन'}</span>
                </div>
                
                <div className="flex items-center space-x-2 px-3 py-1 rounded-full text-sm bg-primary/10 text-primary">
                  <Icon name="MapPin" size={14} />
                  <span>{userLocation}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Main Chat Area */}
            <div className="lg:col-span-3 space-y-6">
              {/* AI Avatar Section */}
              <div className="bg-white rounded-xl shadow-sm border border-border p-6">
                <AIAvatar 
                  isListening={isListening}
                  isThinking={isThinking}
                  isOffline={isOffline}
                />
              </div>

              {/* Chat Interface */}
              <div className="bg-white rounded-xl shadow-sm border border-border">
                {/* Chat Header */}
                <div className="p-4 border-b border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
                      <span className="text-sm font-medium text-foreground">
                        {isThinking ? 'AI सोच रहा है...' : 'बातचीत के लिए तैयार'}
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleClearHistory}
                        className="text-muted-foreground hover:text-foreground"
                      >
                        <Icon name="RotateCcw" size={16} />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-muted-foreground hover:text-foreground"
                      >
                        <Icon name="Settings" size={16} />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Messages Area */}
                <div 
                  ref={chatContainerRef}
                  className="h-96 overflow-y-auto p-4 space-y-4"
                >
                  {messages?.map((message) => (
                    <ChatMessage
                      key={message?.id}
                      message={message}
                      onPlayAudio={handlePlayAudio}
                      onEscalate={handleEscalate}
                      onSaveResponse={handleSaveResponse}
                    />
                  ))}
                  
                  {isThinking && (
                    <div className="flex justify-start">
                      <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3 max-w-xs">
                        <div className="flex items-center space-x-2">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                          </div>
                          <span className="text-sm text-muted-foreground">विश्लेषण हो रहा है...</span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </div>

                {/* Input Area */}
                <div className="p-4 border-t border-border">
                  <div className="flex items-end space-x-3">
                    {/* Text Input */}
                    <div className="flex-1">
                      <Input
                        type="text"
                        placeholder="अपना सवाल यहाँ लिखें..."
                        value={currentMessage}
                        onChange={(e) => setCurrentMessage(e?.target?.value)}
                        onKeyPress={handleKeyPress}
                        disabled={isThinking}
                        className="resize-none"
                      />
                    </div>

                    {/* Voice Input Button */}
                    <Button
                      variant={isListening ? "destructive" : "outline"}
                      size="icon"
                      onClick={isListening ? handleVoiceStop : handleVoiceStart}
                      disabled={isThinking}
                      className={isListening ? 'animate-pulse' : ''}
                    >
                      <Icon name={isListening ? "Square" : "Mic"} size={18} />
                    </Button>

                    {/* Send Button */}
                    <Button
                      variant="default"
                      onClick={() => handleSendMessage(currentMessage)}
                      disabled={!currentMessage?.trim() || isThinking}
                      loading={isThinking}
                    >
                      <Icon name="Send" size={18} />
                    </Button>
                  </div>

                  {/* Quick Actions */}
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs"
                      >
                        <Icon name="Camera" size={12} className="mr-1" />
                        फोटो
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs"
                      >
                        <Icon name="Paperclip" size={12} className="mr-1" />
                        फाइल
                      </Button>
                    </div>

                    <div className="text-xs text-muted-foreground">
                      Enter दबाएं या Send बटन क्लिक करें
                    </div>
                  </div>
                </div>
              </div>

              {/* Voice Input Component */}
              <div className="bg-white rounded-xl shadow-sm border border-border p-6">
                <VoiceInput
                  onVoiceStart={handleVoiceStart}
                  onVoiceStop={handleVoiceStop}
                  onVoiceResult={handleVoiceResult}
                  isListening={isListening}
                  disabled={isThinking}
                />
              </div>

              {/* Image Analysis Component */}
              <div className="bg-white rounded-xl shadow-sm border border-border p-6">
                <h3 className="text-lg font-poppins font-semibold text-foreground mb-4 flex items-center">
                  <Icon name="Camera" size={18} className="mr-2 text-primary" />
                  फसल रोग पहचान
                </h3>
                <ImageAnalysis
                  onImageAnalysis={handleImageAnalysis}
                  disabled={isThinking}
                />
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Smart Suggestions */}
              <div className="bg-white rounded-xl shadow-sm border border-border p-6">
                <SmartSuggestions
                  onSuggestionClick={handleSuggestionClick}
                  userLocation={userLocation}
                  currentSeason={currentSeason}
                />
              </div>

              {/* Conversation History */}
              <div className="bg-white rounded-xl shadow-sm border border-border p-6">
                <ConversationHistory
                  messages={messages}
                  onPlayAudio={handlePlayAudio}
                  onEscalate={handleEscalate}
                  onSaveResponse={handleSaveResponse}
                  onClearHistory={handleClearHistory}
                  onLoadMore={handleLoadMore}
                />
              </div>

              {/* Related Resources */}
              <div className="bg-white rounded-xl shadow-sm border border-border p-6">
                <RelatedResources
                  currentQuery={currentMessage}
                  userProfile={{ location: userLocation, season: currentSeason }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Emergency FAB */}
      <Button
        variant="destructive"
        size="lg"
        onClick={handleEmergencyQuery}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg hover:shadow-xl z-50 animate-pulse"
      >
        <Icon name="AlertTriangle" size={24} color="white" />
      </Button>
      {/* Emergency Modal */}
      {showEmergencyModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-poppins font-semibold text-foreground flex items-center">
                <Icon name="AlertTriangle" size={18} className="mr-2 text-error" />
                आपातकालीन सहायता
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowEmergencyModal(false)}
              >
                <Icon name="X" size={16} />
              </Button>
            </div>
            
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                तुरंत मदद की जरूरत है? नीचे दिए गए विकल्पों में से चुनें:
              </p>
              
              <div className="space-y-2">
                <Button
                  variant="outline"
                  fullWidth
                  className="justify-start"
                  onClick={() => {
                    handleSendMessage("मेरी फसल में अचानक बीमारी फैल गई है, तुरंत मदद चाहिए");
                    setShowEmergencyModal(false);
                  }}
                >
                  <Icon name="Bug" size={16} className="mr-2 text-error" />
                  फसल में अचानक बीमारी
                </Button>
                
                <Button
                  variant="outline"
                  fullWidth
                  className="justify-start"
                  onClick={() => {
                    handleSendMessage("मौसम की वजह से फसल को नुकसान हो रहा है");
                    setShowEmergencyModal(false);
                  }}
                >
                  <Icon name="CloudRain" size={16} className="mr-2 text-error" />
                  मौसम से नुकसान
                </Button>
                
                <Link to="/officer-connect-portal">
                  <Button
                    variant="default"
                    fullWidth
                    className="justify-start"
                  >
                    <Icon name="Phone" size={16} className="mr-2" />
                    विशेषज्ञ से तुरंत बात करें
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AIAssistantInterface;