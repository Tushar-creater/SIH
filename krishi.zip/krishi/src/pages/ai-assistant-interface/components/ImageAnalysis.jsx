import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const ImageAnalysis = ({ onImageAnalysis, disabled }) => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const fileInputRef = useRef(null);

  const handleImageSelect = (event) => {
    const file = event?.target?.files?.[0];
    if (file && file?.type?.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage({
          file,
          url: e?.target?.result,
          name: file?.name
        });
        setAnalysisResult(null);
      };
      reader?.readAsDataURL(file);
    }
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices?.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      
      // Create video element for camera preview
      const video = document.createElement('video');
      video.srcObject = stream;
      video?.play();
      
      // This would typically open a camera interface
      // For demo purposes, we'll simulate camera capture
      setTimeout(() => {
        stream?.getTracks()?.forEach(track => track?.stop());
        setSelectedImage({
          url: 'https://images.pexels.com/photos/1459339/pexels-photo-1459339.jpeg?auto=compress&cs=tinysrgb&w=400',
          name: 'camera_capture.jpg',
          isCamera: true
        });
      }, 1000);
      
    } catch (error) {
      console.error('Camera access failed:', error);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const mockAnalysis = {
        disease: "पत्ती का धब्बा रोग (Leaf Spot Disease)",
        confidence: 87,
        severity: "मध्यम",
        recommendations: [
          "तुरंत प्रभावित पत्तियों को हटा दें",
          "कॉपर सल्फेट का छिड़काव करें",
          "खेत में जल निकासी की व्यवस्था करें",
          "15 दिन बाद दोबारा जांच कराएं"
        ],
        preventiveMeasures: [
          "बीज उपचार करें",
          "फसल चक्र अपनाएं",
          "संतुलित उर्वरक का प्रयोग करें"
        ],
        urgency: "medium",
        estimatedCost: "₹500-800 प्रति एकड़"
      };

      setAnalysisResult(mockAnalysis);
      setIsAnalyzing(false);
      
      // Send result to parent component
      onImageAnalysis({
        image: selectedImage,
        analysis: mockAnalysis
      });
    }, 3000);
  };

  const clearImage = () => {
    setSelectedImage(null);
    setAnalysisResult(null);
    if (fileInputRef?.current) {
      fileInputRef.current.value = '';
    }
  };

  const getSeverityColor = (severity) => {
    const colors = {
      'कम': 'text-green-600 bg-green-50',
      'मध्यम': 'text-orange-600 bg-orange-50',
      'गंभीर': 'text-red-600 bg-red-50'
    };
    return colors?.[severity] || colors?.['मध्यम'];
  };

  return (
    <div className="space-y-4">
      {/* Image Upload Options */}
      {!selectedImage && (
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            onClick={() => fileInputRef?.current?.click()}
            disabled={disabled}
            className="h-20 flex-col space-y-2 border-dashed border-2 hover:border-primary hover:bg-primary/5"
          >
            <Icon name="Upload" size={20} className="text-primary" />
            <span className="text-sm">गैलरी से चुनें</span>
          </Button>

          <Button
            variant="outline"
            onClick={handleCameraCapture}
            disabled={disabled}
            className="h-20 flex-col space-y-2 border-dashed border-2 hover:border-primary hover:bg-primary/5"
          >
            <Icon name="Camera" size={20} className="text-primary" />
            <span className="text-sm">फोटो लें</span>
          </Button>
        </div>
      )}
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageSelect}
        className="hidden"
      />
      {/* Selected Image Preview */}
      {selectedImage && (
        <div className="space-y-4">
          <div className="relative">
            <Image
              src={selectedImage?.url}
              alt="Selected crop image"
              className="w-full h-48 object-cover rounded-lg border border-border"
            />
            
            <Button
              variant="ghost"
              size="icon"
              onClick={clearImage}
              className="absolute top-2 right-2 bg-white/80 hover:bg-white"
            >
              <Icon name="X" size={16} />
            </Button>

            {selectedImage?.isCamera && (
              <div className="absolute top-2 left-2 bg-primary text-primary-foreground px-2 py-1 rounded text-xs">
                <Icon name="Camera" size={12} className="inline mr-1" />
                कैमरा
              </div>
            )}
          </div>

          {/* Analysis Button */}
          {!analysisResult && (
            <Button
              variant="default"
              onClick={analyzeImage}
              disabled={isAnalyzing}
              loading={isAnalyzing}
              className="w-full"
            >
              {isAnalyzing ? 'विश्लेषण हो रहा है...' : 'AI विश्लेषण शुरू करें'}
            </Button>
          )}
        </div>
      )}
      {/* Analysis Results */}
      {analysisResult && (
        <div className="space-y-4 p-4 bg-muted rounded-lg">
          {/* Disease Identification */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-poppins font-semibold text-foreground">
                पहचान परिणाम
              </h4>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(analysisResult?.severity)}`}>
                {analysisResult?.severity}
              </span>
            </div>
            
            <p className="text-sm font-medium text-primary">
              {analysisResult?.disease}
            </p>
            
            <div className="flex items-center space-x-2">
              <span className="text-xs text-muted-foreground">विश्वसनीयता:</span>
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-500"
                  style={{ width: `${analysisResult?.confidence}%` }}
                ></div>
              </div>
              <span className="text-xs font-medium text-primary">
                {analysisResult?.confidence}%
              </span>
            </div>
          </div>

          {/* Recommendations */}
          <div className="space-y-2">
            <h5 className="text-sm font-poppins font-semibold text-foreground flex items-center">
              <Icon name="Lightbulb" size={14} className="mr-2 text-accent" />
              तुरंत करने योग्य कार्य
            </h5>
            <ul className="space-y-1">
              {analysisResult?.recommendations?.map((rec, index) => (
                <li key={index} className="text-xs text-muted-foreground flex items-start">
                  <Icon name="ArrowRight" size={10} className="mr-2 mt-1 text-primary flex-shrink-0" />
                  {rec}
                </li>
              ))}
            </ul>
          </div>

          {/* Cost Estimate */}
          <div className="flex items-center justify-between p-2 bg-white rounded border">
            <span className="text-xs text-muted-foreground">अनुमानित लागत:</span>
            <span className="text-sm font-medium text-primary">
              {analysisResult?.estimatedCost}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              className="text-xs"
            >
              <Icon name="BookOpen" size={12} className="mr-1" />
              विस्तार से पढ़ें
            </Button>
            
            <Button
              variant="default"
              size="sm"
              className="text-xs"
            >
              <Icon name="Phone" size={12} className="mr-1" />
              विशेषज्ञ से बात करें
            </Button>
          </div>
        </div>
      )}
      {/* Tips */}
      {!selectedImage && (
        <div className="text-center space-y-2">
          <p className="text-xs text-muted-foreground">
            बेहतर परिणाम के लिए सुझाव:
          </p>
          <div className="flex items-center justify-center space-x-4 text-xs text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="Sun" size={10} />
              <span>अच्छी रोशनी</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Focus" size={10} />
              <span>साफ फोकस</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Maximize" size={10} />
              <span>पास से फोटो</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageAnalysis;