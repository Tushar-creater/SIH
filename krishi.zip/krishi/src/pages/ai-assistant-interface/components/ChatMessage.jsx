import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const ChatMessage = ({ message, onPlayAudio, onEscalate, onSaveResponse }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showActions, setShowActions] = useState(false);

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp)?.toLocaleTimeString('hi-IN', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handlePlayAudio = () => {
    setIsPlaying(true);
    onPlayAudio(message?.id);
    setTimeout(() => setIsPlaying(false), 3000);
  };

  const getCategoryColor = (category) => {
    const colors = {
      'Weather': 'bg-blue-100 text-blue-800',
      'Crops': 'bg-green-100 text-green-800',
      'Schemes': 'bg-purple-100 text-purple-800',
      'Market': 'bg-orange-100 text-orange-800',
      'Disease': 'bg-red-100 text-red-800',
      'General': 'bg-gray-100 text-gray-800'
    };
    return colors?.[category] || colors?.['General'];
  };

  return (
    <div className={`flex ${message?.sender === 'user' ? 'justify-end' : 'justify-start'} mb-6`}>
      <div className={`max-w-xs lg:max-w-md xl:max-w-lg ${message?.sender === 'user' ? 'order-2' : 'order-1'}`}>
        {/* Avatar */}
        <div className={`flex items-end space-x-2 ${message?.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            message?.sender === 'user' ?'bg-secondary' :'bg-gradient-to-br from-primary to-primary/80'
          }`}>
            <Icon 
              name={message?.sender === 'user' ? 'User' : 'Bot'} 
              size={16} 
              color="white" 
            />
          </div>

          {/* Message Content */}
          <div 
            className={`relative px-4 py-3 rounded-2xl shadow-sm ${
              message?.sender === 'user' ?'bg-secondary text-secondary-foreground rounded-br-md' :'bg-white border border-border rounded-bl-md'
            }`}
            onMouseEnter={() => setShowActions(true)}
            onMouseLeave={() => setShowActions(false)}
          >
            {/* Category Tag */}
            {message?.category && message?.sender === 'assistant' && (
              <div className="mb-2">
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(message?.category)}`}>
                  <Icon name="Tag" size={10} className="mr-1" />
                  {message?.category}
                </span>
              </div>
            )}

            {/* Text Content */}
            {message?.text && (
              <p className="text-sm leading-relaxed whitespace-pre-wrap">
                {message?.text}
              </p>
            )}

            {/* Image Content */}
            {message?.image && (
              <div className="mt-2">
                <Image 
                  src={message?.image?.url} 
                  alt={message?.image?.alt || "Uploaded image"}
                  className="rounded-lg max-w-full h-auto"
                />
                {message?.image?.analysis && (
                  <div className="mt-2 p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="Eye" size={14} className="text-primary" />
                      <span className="text-xs font-medium text-primary">AI विश्लेषण</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {message?.image?.analysis}
                    </p>
                    {message?.image?.confidence && (
                      <div className="mt-2 flex items-center space-x-2">
                        <span className="text-xs text-muted-foreground">विश्वसनीयता:</span>
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all duration-300"
                            style={{ width: `${message?.image?.confidence}%` }}
                          ></div>
                        </div>
                        <span className="text-xs font-medium text-primary">
                          {message?.image?.confidence}%
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Audio Playback */}
            {message?.hasAudio && message?.sender === 'assistant' && (
              <div className="mt-3 flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handlePlayAudio}
                  disabled={isPlaying}
                  className="text-primary hover:bg-primary/10"
                >
                  <Icon 
                    name={isPlaying ? "Volume2" : "Play"} 
                    size={14} 
                    className={isPlaying ? "animate-pulse" : ""}
                  />
                  <span className="ml-1 text-xs">
                    {isPlaying ? 'बजा रहा है...' : 'सुनें'}
                  </span>
                </Button>
              </div>
            )}

            {/* Timestamp */}
            <div className={`mt-2 text-xs ${
              message?.sender === 'user' ?'text-secondary-foreground/70' :'text-muted-foreground'
            }`}>
              {formatTimestamp(message?.timestamp)}
              {message?.isOffline && (
                <span className="ml-2 inline-flex items-center">
                  <Icon name="WifiOff" size={10} className="mr-1" />
                  ऑफलाइन
                </span>
              )}
            </div>

            {/* Action Buttons */}
            {showActions && message?.sender === 'assistant' && (
              <div className="absolute -right-2 top-0 flex flex-col space-y-1 bg-white rounded-lg shadow-lg border border-border p-1 opacity-0 animate-fade-in">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onSaveResponse(message)}
                  className="w-6 h-6 hover:bg-primary/10"
                >
                  <Icon name="Bookmark" size={12} className="text-primary" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onEscalate(message)}
                  className="w-6 h-6 hover:bg-accent/10"
                >
                  <Icon name="ArrowUp" size={12} className="text-accent" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;