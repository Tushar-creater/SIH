import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const AIAvatar = ({ isListening, isThinking, isOffline }) => {
  const [animationState, setAnimationState] = useState('idle');

  useEffect(() => {
    if (isListening) {
      setAnimationState('listening');
    } else if (isThinking) {
      setAnimationState('thinking');
    } else {
      setAnimationState('idle');
    }
  }, [isListening, isThinking]);

  return (
    <div className="flex flex-col items-center space-y-4 p-6">
      {/* Avatar Container */}
      <div className="relative">
        {/* Main Avatar */}
        <div className={`w-24 h-24 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg transition-all duration-300 ${
          animationState === 'listening' ? 'scale-110 shadow-xl' : 
          animationState === 'thinking' ? 'animate-pulse' : ''
        }`}>
          {/* Avatar Character */}
          <div className="relative">
            <Icon 
              name="Bot" 
              size={32} 
              color="white" 
              strokeWidth={2}
            />
            {/* Traditional Elements */}
            <div className="absolute -top-2 -right-2 w-4 h-4 bg-accent rounded-full flex items-center justify-center">
              <Icon name="Wheat" size={10} color="white" />
            </div>
          </div>
        </div>

        {/* Status Indicators */}
        {isOffline && (
          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-warning rounded-full flex items-center justify-center border-2 border-white">
            <Icon name="WifiOff" size={12} color="white" />
          </div>
        )}

        {!isOffline && (
          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-success rounded-full flex items-center justify-center border-2 border-white animate-pulse">
            <Icon name="Wifi" size={12} color="white" />
          </div>
        )}

        {/* Voice Animation Rings */}
        {animationState === 'listening' && (
          <>
            <div className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping"></div>
            <div className="absolute inset-0 rounded-full border-2 border-primary/20 animate-ping" style={{ animationDelay: '0.5s' }}></div>
          </>
        )}
      </div>

      {/* Status Text */}
      <div className="text-center">
        <h3 className="text-lg font-poppins font-semibold text-foreground">
          KrishiMitra AI
        </h3>
        <p className="text-sm text-muted-foreground">
          {animationState === 'listening' ? 'सुन रहा हूँ...' :
           animationState === 'thinking'? 'सोच रहा हूँ...' : isOffline ?'ऑफलाइन मोड' : 'आपकी सेवा में तैयार'}
        </p>
      </div>

      {/* Personality Indicators */}
      <div className="flex items-center space-x-2 text-xs text-muted-foreground">
        <Icon name="Heart" size={12} className="text-error" />
        <span>किसान मित्र</span>
        <Icon name="Sparkles" size={12} className="text-accent" />
        <span>AI सहायक</span>
      </div>
    </div>
  );
};

export default AIAvatar;