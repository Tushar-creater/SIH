import React, { useState, useEffect, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const VoiceInput = ({ onVoiceStart, onVoiceStop, onVoiceResult, isListening, disabled }) => {
  const [audioLevel, setAudioLevel] = useState(0);
  const [isSupported, setIsSupported] = useState(false);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const microphoneRef = useRef(null);
  const animationRef = useRef(null);

  useEffect(() => {
    // Check if speech recognition is supported
    setIsSupported('webkitSpeechRecognition' in window || 'SpeechRecognition' in window);
    
    return () => {
      if (animationRef?.current) {
        cancelAnimationFrame(animationRef?.current);
      }
      if (audioContextRef?.current) {
        audioContextRef?.current?.close();
      }
    };
  }, []);

  const startVoiceRecording = async () => {
    if (!isSupported || disabled) return;

    try {
      // Start audio visualization
      const stream = await navigator.mediaDevices?.getUserMedia({ audio: true });
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      analyserRef.current = audioContextRef?.current?.createAnalyser();
      microphoneRef.current = audioContextRef?.current?.createMediaStreamSource(stream);
      
      microphoneRef?.current?.connect(analyserRef?.current);
      analyserRef.current.fftSize = 256;
      
      const bufferLength = analyserRef?.current?.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      
      const updateAudioLevel = () => {
        analyserRef?.current?.getByteFrequencyData(dataArray);
        const average = dataArray?.reduce((a, b) => a + b) / bufferLength;
        setAudioLevel(average);
        
        if (isListening) {
          animationRef.current = requestAnimationFrame(updateAudioLevel);
        }
      };
      
      updateAudioLevel();
      onVoiceStart();
      
    } catch (error) {
      console.error('Voice recording failed:', error);
    }
  };

  const stopVoiceRecording = () => {
    if (animationRef?.current) {
      cancelAnimationFrame(animationRef?.current);
    }
    if (audioContextRef?.current) {
      audioContextRef?.current?.close();
    }
    setAudioLevel(0);
    onVoiceStop();
    
    // Simulate voice result
    setTimeout(() => {
      onVoiceResult("मेरी फसल में कीड़े लग गए हैं, क्या करूं?");
    }, 1000);
  };

  const toggleVoiceRecording = () => {
    if (isListening) {
      stopVoiceRecording();
    } else {
      startVoiceRecording();
    }
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      {/* Voice Waveform Visualization */}
      {isListening && (
        <div className="flex items-center justify-center space-x-1 h-12">
          {[...Array(12)]?.map((_, i) => (
            <div
              key={i}
              className="w-1 bg-primary rounded-full transition-all duration-100"
              style={{
                height: `${Math.max(4, (audioLevel / 255) * 48 + Math.random() * 16)}px`,
                animationDelay: `${i * 0.1}s`
              }}
            />
          ))}
        </div>
      )}
      {/* Voice Button */}
      <div className="relative">
        <Button
          variant={isListening ? "destructive" : "default"}
          size="lg"
          onClick={toggleVoiceRecording}
          disabled={disabled || !isSupported}
          className={`w-16 h-16 rounded-full ${
            isListening ? 'animate-pulse shadow-lg' : 'hover:scale-105'
          } transition-all duration-300`}
        >
          <Icon 
            name={isListening ? "Square" : "Mic"} 
            size={24} 
            color="white"
          />
        </Button>

        {/* Recording Indicator */}
        {isListening && (
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-error rounded-full animate-pulse border-2 border-white">
          </div>
        )}
      </div>
      {/* Voice Instructions */}
      <div className="text-center">
        <p className="text-sm font-medium text-foreground">
          {isListening ? 'बोलिए...' : 'आवाज़ में पूछें'}
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          {isListening ? 'सुनने के लिए तैयार' : 'माइक बटन दबाएं'}
        </p>
      </div>
      {/* Language Support */}
      <div className="flex items-center space-x-2 text-xs text-muted-foreground">
        <Icon name="Languages" size={12} />
        <span>हिंदी, English, मराठी</span>
      </div>
      {/* Offline Indicator */}
      {!navigator.onLine && (
        <div className="flex items-center space-x-2 px-3 py-1 bg-warning/10 rounded-full">
          <Icon name="WifiOff" size={12} className="text-warning" />
          <span className="text-xs text-warning">ऑफलाइन मोड</span>
        </div>
      )}
    </div>
  );
};

export default VoiceInput;