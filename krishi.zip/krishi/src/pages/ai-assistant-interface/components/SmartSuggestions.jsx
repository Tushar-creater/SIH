import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SmartSuggestions = ({ onSuggestionClick, userLocation, currentSeason }) => {
  const [suggestions, setSuggestions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Mock suggestions based on season and location
  const mockSuggestions = [
    {
      id: 1,
      text: "मानसून की तैयारी के लिए क्या करना चाहिए?",
      category: "Weather",
      icon: "CloudRain",
      priority: "high",
      seasonal: true
    },
    {
      id: 2,
      text: "गेहूं का आज का भाव क्या है?",
      category: "Market",
      icon: "TrendingUp",
      priority: "medium",
      seasonal: false
    },
    {
      id: 3,
      text: "PM-KISAN की नई अपडेट बताएं",
      category: "Schemes",
      icon: "FileText",
      priority: "high",
      seasonal: false
    },
    {
      id: 4,
      text: "धान की बुआई का सही समय कब है?",
      category: "Crops",
      icon: "Sprout",
      priority: "high",
      seasonal: true
    },
    {
      id: 5,
      text: "मिट्टी की जांच कैसे कराएं?",
      category: "General",
      icon: "TestTube",
      priority: "medium",
      seasonal: false
    },
    {
      id: 6,
      text: "कृषि लोन के लिए कैसे अप्लाई करें?",
      category: "Schemes",
      icon: "CreditCard",
      priority: "medium",
      seasonal: false
    }
  ];

  useEffect(() => {
    // Simulate loading suggestions
    setIsLoading(true);
    setTimeout(() => {
      // Filter suggestions based on season and priority
      const filteredSuggestions = mockSuggestions?.filter(suggestion => {
          if (currentSeason === 'monsoon' && suggestion?.seasonal) {
            return suggestion?.category === 'Weather' || suggestion?.category === 'Crops';
          }
          return true;
        })?.sort((a, b) => {
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          return priorityOrder?.[b?.priority] - priorityOrder?.[a?.priority];
        })?.slice(0, 4);
      
      setSuggestions(filteredSuggestions);
      setIsLoading(false);
    }, 1000);
  }, [currentSeason, userLocation]);

  const getCategoryColor = (category) => {
    const colors = {
      'Weather': 'text-blue-600 bg-blue-50 border-blue-200',
      'Crops': 'text-green-600 bg-green-50 border-green-200',
      'Schemes': 'text-purple-600 bg-purple-50 border-purple-200',
      'Market': 'text-orange-600 bg-orange-50 border-orange-200',
      'General': 'text-gray-600 bg-gray-50 border-gray-200'
    };
    return colors?.[category] || colors?.['General'];
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Sparkles" size={16} className="text-primary animate-pulse" />
          <h3 className="text-sm font-poppins font-semibold text-foreground">
            सुझाव लोड हो रहे हैं...
          </h3>
        </div>
        {[...Array(4)]?.map((_, i) => (
          <div key={i} className="h-12 bg-muted rounded-lg animate-pulse"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Sparkles" size={16} className="text-primary" />
        <h3 className="text-sm font-poppins font-semibold text-foreground">
          स्मार्ट सुझाव
        </h3>
        {currentSeason && (
          <span className="text-xs text-muted-foreground">
            ({currentSeason === 'monsoon' ? 'मानसून' : 'सामान्य'})
          </span>
        )}
      </div>
      {/* Suggestions List */}
      <div className="space-y-2">
        {suggestions?.map((suggestion) => (
          <Button
            key={suggestion?.id}
            variant="ghost"
            onClick={() => onSuggestionClick(suggestion?.text)}
            className={`w-full justify-start text-left p-3 h-auto border transition-all duration-200 hover:scale-[1.02] ${getCategoryColor(suggestion?.category)}`}
          >
            <div className="flex items-start space-x-3 w-full">
              <Icon 
                name={suggestion?.icon} 
                size={16} 
                className="flex-shrink-0 mt-0.5"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium leading-relaxed">
                  {suggestion?.text}
                </p>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-xs opacity-70">
                    {suggestion?.category}
                  </span>
                  {suggestion?.priority === 'high' && (
                    <div className="w-2 h-2 bg-current rounded-full animate-pulse"></div>
                  )}
                </div>
              </div>
            </div>
          </Button>
        ))}
      </div>
      {/* Refresh Button */}
      <div className="pt-2 border-t border-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            setIsLoading(true);
            setTimeout(() => {
              // Shuffle suggestions
              const shuffled = [...mockSuggestions]?.sort(() => Math.random() - 0.5)?.slice(0, 4);
              setSuggestions(shuffled);
              setIsLoading(false);
            }, 500);
          }}
          className="w-full text-muted-foreground hover:text-primary"
        >
          <Icon name="RefreshCw" size={14} className="mr-2" />
          नए सुझाव देखें
        </Button>
      </div>
      {/* Location Context */}
      {userLocation && (
        <div className="text-xs text-muted-foreground text-center pt-2 border-t border-border">
          <Icon name="MapPin" size={10} className="inline mr-1" />
          {userLocation} के लिए व्यक्तिगत सुझाव
        </div>
      )}
    </div>
  );
};

export default SmartSuggestions;