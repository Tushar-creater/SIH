import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const RelatedResources = ({ currentQuery, userProfile }) => {
  const [resources, setResources] = useState([]);
  const [communityPosts, setCommunityPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Mock resources data
  const mockResources = [
    {
      id: 1,
      title: "धान की खेती की संपूर्ण जानकारी",
      type: "guide",
      category: "Crops",
      description: "धान की बुआई से कटाई तक की पूरी प्रक्रिया",
      thumbnail: "https://images.pexels.com/photos/1459339/pexels-photo-1459339.jpeg?auto=compress&cs=tinysrgb&w=200",
      duration: "15 मिनट",
      views: "12.5K",
      rating: 4.8,
      isNew: false
    },
    {
      id: 2,
      title: "मौसम आधारित फसल योजना",
      type: "video",
      category: "Weather",
      description: "मौसम के अनुसार फसल का चुनाव कैसे करें",
      thumbnail: "https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg?auto=compress&cs=tinysrgb&w=200",
      duration: "8 मिनट",
      views: "8.2K",
      rating: 4.6,
      isNew: true
    },
    {
      id: 3,
      title: "PM-KISAN योजना की पूरी जानकारी",
      type: "article",
      category: "Schemes",
      description: "पीएम किसान योजना के लिए आवेदन प्रक्रिया",
      thumbnail: "https://images.pexels.com/photos/5650026/pexels-photo-5650026.jpeg?auto=compress&cs=tinysrgb&w=200",
      duration: "5 मिनट",
      views: "25.1K",
      rating: 4.9,
      isNew: false
    }
  ];

  const mockCommunityPosts = [
    {
      id: 1,
      author: "राजेश कुमार",
      location: "पंजाब",
      title: "गेहूं में कीट प्रबंधन के सफल तरीके",
      excerpt: "इस साल मैंने जैविक कीट नियंत्रण का उपयोग करके बेहतर उत्पादन प्राप्त किया है...",
      likes: 45,
      comments: 12,
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      category: "Crops",
      isExpert: false
    },
    {
      id: 2,
      author: "डॉ. सुनीता शर्मा",
      location: "कृषि विशेषज्ञ",
      title: "मानसून के लिए मिट्टी की तैयारी",
      excerpt: "मानसून से पहले मिट्टी की उचित तैयारी करना बहुत महत्वपूर्ण है। यहाँ कुछ प्रभावी तरीके हैं...",
      likes: 78,
      comments: 23,
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      category: "Weather",
      isExpert: true
    },
    {
      id: 3,
      author: "अमित पटेल",
      location: "गुजरात",
      title: "ड्रिप इरिगेशन से पानी की बचत",
      excerpt: "ड्रिप सिंचाई प्रणाली लगाने के बाद मेरी पानी की खपत 40% कम हो गई है...",
      likes: 32,
      comments: 8,
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      category: "Technology",
      isExpert: false
    }
  ];

  useEffect(() => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      // Filter resources based on current query context
      let filteredResources = mockResources;
      if (currentQuery) {
        const queryLower = currentQuery?.toLowerCase();
        filteredResources = mockResources?.filter(resource => 
          resource?.title?.toLowerCase()?.includes('धान') ||
          resource?.title?.toLowerCase()?.includes('मौसम') ||
          resource?.category === 'Crops'
        );
      }
      
      setResources(filteredResources);
      setCommunityPosts(mockCommunityPosts);
      setIsLoading(false);
    }, 1000);
  }, [currentQuery]);

  const getResourceIcon = (type) => {
    const icons = {
      'guide': 'BookOpen',
      'video': 'Play',
      'article': 'FileText',
      'tool': 'Tool'
    };
    return icons?.[type] || 'File';
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'अभी';
    if (hours < 24) return `${hours} घंटे पहले`;
    return `${Math.floor(hours / 24)} दिन पहले`;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="space-y-3">
          <div className="h-4 bg-muted rounded animate-pulse"></div>
          {[...Array(3)]?.map((_, i) => (
            <div key={i} className="h-20 bg-muted rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Related Resources */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-poppins font-semibold text-foreground flex items-center">
            <Icon name="BookOpen" size={18} className="mr-2 text-primary" />
            संबंधित संसाधन
          </h3>
          <Link to="/knowledge-center">
            <Button variant="ghost" size="sm" className="text-primary">
              सभी देखें
              <Icon name="ArrowRight" size={14} className="ml-1" />
            </Button>
          </Link>
        </div>

        <div className="space-y-3">
          {resources?.map((resource) => (
            <div
              key={resource?.id}
              className="flex items-start space-x-3 p-3 bg-white rounded-lg border border-border hover:shadow-md transition-all duration-200 cursor-pointer group"
            >
              {/* Thumbnail */}
              <div className="relative flex-shrink-0">
                <Image
                  src={resource?.thumbnail}
                  alt={resource?.title}
                  className="w-16 h-16 object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-black/20 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <Icon name={getResourceIcon(resource?.type)} size={16} color="white" />
                </div>
                {resource?.isNew && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse"></div>
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-poppins font-semibold text-foreground group-hover:text-primary transition-colors duration-200 line-clamp-1">
                  {resource?.title}
                </h4>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                  {resource?.description}
                </p>
                
                <div className="flex items-center space-x-3 mt-2 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Icon name="Clock" size={10} />
                    <span>{resource?.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Eye" size={10} />
                    <span>{resource?.views}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={10} className="text-accent" />
                    <span>{resource?.rating}</span>
                  </div>
                </div>
              </div>

              {/* Type Badge */}
              <div className="flex-shrink-0">
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                  <Icon name={getResourceIcon(resource?.type)} size={10} className="mr-1" />
                  {resource?.type === 'guide' ? 'गाइड' : 
                   resource?.type === 'video' ? 'वीडियो' : 
                   resource?.type === 'article' ? 'लेख' : 'टूल'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Community Discussions */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-poppins font-semibold text-foreground flex items-center">
            <Icon name="Users" size={18} className="mr-2 text-secondary" />
            समुदायिक चर्चा
          </h3>
          <Link to="/community">
            <Button variant="ghost" size="sm" className="text-secondary">
              सभी देखें
              <Icon name="ArrowRight" size={14} className="ml-1" />
            </Button>
          </Link>
        </div>

        <div className="space-y-3">
          {communityPosts?.map((post) => (
            <div
              key={post?.id}
              className="p-3 bg-white rounded-lg border border-border hover:shadow-md transition-all duration-200 cursor-pointer"
            >
              {/* Author Info */}
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-8 h-8 bg-gradient-to-br from-secondary to-secondary/80 rounded-full flex items-center justify-center">
                  <Icon name="User" size={12} color="white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-foreground">
                      {post?.author}
                    </span>
                    {post?.isExpert && (
                      <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                        <Icon name="Check" size={8} color="white" />
                      </div>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {post?.location} • {formatTimeAgo(post?.timestamp)}
                  </span>
                </div>
              </div>

              {/* Post Content */}
              <h4 className="text-sm font-poppins font-semibold text-foreground mb-1">
                {post?.title}
              </h4>
              <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
                {post?.excerpt}
              </p>

              {/* Post Stats */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Icon name="Heart" size={12} />
                    <span>{post?.likes}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="MessageCircle" size={12} />
                    <span>{post?.comments}</span>
                  </div>
                </div>
                
                <span className="text-xs text-primary font-medium">
                  {post?.category === 'Crops' ? 'फसल' :
                   post?.category === 'Weather' ? 'मौसम' :
                   post?.category === 'Technology' ? 'तकनीक' : post?.category}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Quick Links */}
      <div className="space-y-4">
        <h3 className="text-lg font-poppins font-semibold text-foreground flex items-center">
          <Icon name="ExternalLink" size={18} className="mr-2 text-accent" />
          त्वरित लिंक
        </h3>

        <div className="grid grid-cols-2 gap-3">
          <Link to="/weather-intelligence-hub">
            <Button
              variant="outline"
              className="w-full justify-start text-left h-auto p-3 hover:bg-blue-50 hover:border-blue-200"
            >
              <div className="flex items-center space-x-3">
                <Icon name="Cloud" size={16} className="text-blue-600" />
                <div>
                  <div className="text-sm font-medium">मौसम केंद्र</div>
                  <div className="text-xs text-muted-foreground">आज का मौसम</div>
                </div>
              </div>
            </Button>
          </Link>

          <Link to="/market-intelligence-center">
            <Button
              variant="outline"
              className="w-full justify-start text-left h-auto p-3 hover:bg-orange-50 hover:border-orange-200"
            >
              <div className="flex items-center space-x-3">
                <Icon name="TrendingUp" size={16} className="text-orange-600" />
                <div>
                  <div className="text-sm font-medium">बाज़ार भाव</div>
                  <div className="text-xs text-muted-foreground">आज की कीमतें</div>
                </div>
              </div>
            </Button>
          </Link>

          <Link to="/government-schemes-navigator">
            <Button
              variant="outline"
              className="w-full justify-start text-left h-auto p-3 hover:bg-purple-50 hover:border-purple-200"
            >
              <div className="flex items-center space-x-3">
                <Icon name="FileText" size={16} className="text-purple-600" />
                <div>
                  <div className="text-sm font-medium">सरकारी योजनाएं</div>
                  <div className="text-xs text-muted-foreground">नई अपडेट</div>
                </div>
              </div>
            </Button>
          </Link>

          <Link to="/officer-connect-portal">
            <Button
              variant="outline"
              className="w-full justify-start text-left h-auto p-3 hover:bg-green-50 hover:border-green-200"
            >
              <div className="flex items-center space-x-3">
                <Icon name="Phone" size={16} className="text-green-600" />
                <div>
                  <div className="text-sm font-medium">विशेषज्ञ सहायता</div>
                  <div className="text-xs text-muted-foreground">तुरंत संपर्क</div>
                </div>
              </div>
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default RelatedResources;