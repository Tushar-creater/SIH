import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import ChatMessage from './ChatMessage';

const ConversationHistory = ({ 
  messages, 
  onPlayAudio, 
  onEscalate, 
  onSaveResponse,
  onClearHistory,
  onLoadMore 
}) => {
  const [filteredMessages, setFilteredMessages] = useState(messages);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchVisible, setIsSearchVisible] = useState(false);

  const categories = [
    { id: 'all', name: 'सभी', icon: 'MessageCircle', count: messages?.length },
    { id: 'Weather', name: 'मौसम', icon: 'Cloud', count: messages?.filter(m => m?.category === 'Weather')?.length },
    { id: 'Crops', name: 'फसल', icon: 'Sprout', count: messages?.filter(m => m?.category === 'Crops')?.length },
    { id: 'Schemes', name: 'योजना', icon: 'FileText', count: messages?.filter(m => m?.category === 'Schemes')?.length },
    { id: 'Market', name: 'बाज़ार', icon: 'TrendingUp', count: messages?.filter(m => m?.category === 'Market')?.length }
  ];

  useEffect(() => {
    let filtered = messages;

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered?.filter(message => message?.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery?.trim()) {
      filtered = filtered?.filter(message => 
        message?.text?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        message?.image?.analysis?.toLowerCase()?.includes(searchQuery?.toLowerCase())
      );
    }

    setFilteredMessages(filtered);
  }, [messages, selectedCategory, searchQuery]);

  const handleCategorySelect = (categoryId) => {
    setSelectedCategory(categoryId);
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
  };

  const getMessageStats = () => {
    const today = new Date()?.toDateString();
    const todayMessages = messages?.filter(m => new Date(m.timestamp)?.toDateString() === today);
    const totalQueries = messages?.filter(m => m?.sender === 'user')?.length;
    
    return {
      total: messages?.length,
      today: todayMessages?.length,
      queries: totalQueries
    };
  };

  const stats = getMessageStats();

  if (messages?.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
          <Icon name="MessageCircle" size={24} className="text-muted-foreground" />
        </div>
        <h3 className="text-lg font-poppins font-semibold text-foreground mb-2">
          कोई बातचीत नहीं
        </h3>
        <p className="text-sm text-muted-foreground mb-4">
          KrishiMitra से अपना पहला सवाल पूछें
        </p>
        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
          <div className="flex items-center space-x-1">
            <Icon name="Mic" size={12} />
            <span>आवाज़ में पूछें</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Camera" size={12} />
            <span>फोटो भेजें</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Type" size={12} />
            <span>टाइप करें</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header with Stats */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h3 className="text-lg font-poppins font-semibold text-foreground">
            बातचीत का इतिहास
          </h3>
          <div className="flex items-center space-x-4 text-xs text-muted-foreground">
            <span>कुल: {stats?.total}</span>
            <span>आज: {stats?.today}</span>
            <span>प्रश्न: {stats?.queries}</span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* Search Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsSearchVisible(!isSearchVisible)}
            className={isSearchVisible ? 'bg-primary/10 text-primary' : ''}
          >
            <Icon name="Search" size={16} />
          </Button>

          {/* Clear History */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onClearHistory}
            className="text-muted-foreground hover:text-error"
          >
            <Icon name="Trash2" size={16} />
          </Button>
        </div>
      </div>
      {/* Search Bar */}
      {isSearchVisible && (
        <div className="relative">
          <Icon name="Search" size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="बातचीत में खोजें..."
            value={searchQuery}
            onChange={(e) => handleSearch(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleSearch('')}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 w-6 h-6"
            >
              <Icon name="X" size={12} />
            </Button>
          )}
        </div>
      )}
      {/* Category Filters */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2">
        {categories?.map((category) => (
          <Button
            key={category?.id}
            variant={selectedCategory === category?.id ? "default" : "outline"}
            size="sm"
            onClick={() => handleCategorySelect(category?.id)}
            className="flex-shrink-0 text-xs"
          >
            <Icon name={category?.icon} size={12} className="mr-1" />
            {category?.name}
            {category?.count > 0 && (
              <span className="ml-1 px-1.5 py-0.5 bg-current/20 rounded-full text-xs">
                {category?.count}
              </span>
            )}
          </Button>
        ))}
      </div>
      {/* Messages List */}
      <div className="space-y-4 max-h-96 overflow-y-auto">
        {filteredMessages?.length > 0 ? (
          <>
            {filteredMessages?.map((message) => (
              <ChatMessage
                key={message?.id}
                message={message}
                onPlayAudio={onPlayAudio}
                onEscalate={onEscalate}
                onSaveResponse={onSaveResponse}
              />
            ))}
            
            {/* Load More Button */}
            {filteredMessages?.length >= 10 && (
              <div className="text-center pt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onLoadMore}
                  className="text-muted-foreground"
                >
                  <Icon name="ChevronDown" size={14} className="mr-1" />
                  और देखें
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-8">
            <Icon name="Search" size={24} className="text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">
              {searchQuery ? 'कोई परिणाम नहीं मिला' : 'इस श्रेणी में कोई संदेश नहीं'}
            </p>
          </div>
        )}
      </div>
      {/* Quick Actions */}
      <div className="flex items-center justify-between pt-4 border-t border-border">
        <div className="text-xs text-muted-foreground">
          {filteredMessages?.length} संदेश दिखाए गए
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-muted-foreground"
          >
            <Icon name="Download" size={12} className="mr-1" />
            निर्यात करें
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-muted-foreground"
          >
            <Icon name="Share" size={12} className="mr-1" />
            साझा करें
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ConversationHistory;