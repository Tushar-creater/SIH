import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';

const QueryFilters = ({ filters, onFilterChange, onClearFilters }) => {
  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'pending', label: 'Pending' },
    { value: 'in-progress', label: 'In Progress' },
    { value: 'resolved', label: 'Resolved' }
  ];

  const priorityOptions = [
    { value: 'all', label: 'All Priority' },
    { value: 'urgent', label: 'Urgent' },
    { value: 'high', label: 'High' },
    { value: 'medium', label: 'Medium' },
    { value: 'low', label: 'Low' }
  ];

  const categoryOptions = [
    { value: 'all', label: 'All Categories' },
    { value: 'crop-disease', label: 'Crop Disease' },
    { value: 'pest-control', label: 'Pest Control' },
    { value: 'soil-health', label: 'Soil Health' },
    { value: 'weather', label: 'Weather' },
    { value: 'irrigation', label: 'Irrigation' },
    { value: 'fertilizer', label: 'Fertilizer' },
    { value: 'market-price', label: 'Market Price' },
    { value: 'government-scheme', label: 'Government Scheme' }
  ];

  const languageOptions = [
    { value: 'all', label: 'All Languages' },
    { value: 'hindi', label: 'Hindi' },
    { value: 'english', label: 'English' },
    { value: 'bengali', label: 'Bengali' },
    { value: 'tamil', label: 'Tamil' },
    { value: 'telugu', label: 'Telugu' },
    { value: 'marathi', label: 'Marathi' },
    { value: 'gujarati', label: 'Gujarati' },
    { value: 'kannada', label: 'Kannada' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-poppins font-semibold text-foreground flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-primary" />
          <span>Filter Queries</span>
        </h3>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearFilters}
          iconName="X"
          iconPosition="left"
          iconSize={14}
        >
          Clear All
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <Select
          label="Status"
          options={statusOptions}
          value={filters?.status}
          onChange={(value) => onFilterChange('status', value)}
        />
        
        <Select
          label="Priority"
          options={priorityOptions}
          value={filters?.priority}
          onChange={(value) => onFilterChange('priority', value)}
        />
        
        <Select
          label="Category"
          options={categoryOptions}
          value={filters?.category}
          onChange={(value) => onFilterChange('category', value)}
          searchable
        />
        
        <Select
          label="Language"
          options={languageOptions}
          value={filters?.language}
          onChange={(value) => onFilterChange('language', value)}
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Input
          label="Search Farmer"
          type="search"
          placeholder="Search by name, phone, or location"
          value={filters?.search}
          onChange={(e) => onFilterChange('search', e?.target?.value)}
        />
        
        <Input
          label="Date From"
          type="date"
          value={filters?.dateFrom}
          onChange={(e) => onFilterChange('dateFrom', e?.target?.value)}
        />
        
        <Input
          label="Date To"
          type="date"
          value={filters?.dateTo}
          onChange={(e) => onFilterChange('dateTo', e?.target?.value)}
        />
      </div>
      {/* Active Filters Display */}
      {Object.values(filters)?.some(value => value && value !== 'all') && (
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-sm font-medium text-foreground mb-2">Active Filters:</p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(filters)?.map(([key, value]) => {
              if (!value || value === 'all') return null;
              
              return (
                <span 
                  key={key}
                  className="inline-flex items-center space-x-1 px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full border border-primary/20"
                >
                  <span>{key}: {value}</span>
                  <button
                    onClick={() => onFilterChange(key, key === 'status' || key === 'priority' || key === 'category' || key === 'language' ? 'all' : '')}
                    className="hover:bg-primary/20 rounded-full p-0.5"
                  >
                    <Icon name="X" size={10} />
                  </button>
                </span>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default QueryFilters;