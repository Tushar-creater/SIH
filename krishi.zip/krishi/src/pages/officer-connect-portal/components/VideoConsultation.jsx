import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const VideoConsultation = ({ consultation, onEndCall, onToggleMute, onToggleVideo, onShareScreen }) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [callDuration, setCallDuration] = useState('05:23');

  const handleMuteToggle = () => {
    setIsMuted(!isMuted);
    onToggleMute(!isMuted);
  };

  const handleVideoToggle = () => {
    setIsVideoOff(!isVideoOff);
    onToggleVideo(!isVideoOff);
  };

  const handleScreenShare = () => {
    setIsScreenSharing(!isScreenSharing);
    onShareScreen(!isScreenSharing);
  };

  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex flex-col">
      {/* Header */}
      <div className="bg-black/50 backdrop-blur-sm p-4 flex items-center justify-between text-white">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-white/20">
            <Image 
              src={consultation?.farmerAvatar} 
              alt={consultation?.farmerName}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="font-poppins font-semibold">{consultation?.farmerName}</h3>
            <p className="text-sm text-white/80">{consultation?.location}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            <span className="text-sm">{callDuration}</span>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={onEndCall}
            className="text-white hover:bg-white/10"
            iconName="X"
            iconSize={16}
          />
        </div>
      </div>
      {/* Video Area */}
      <div className="flex-1 relative">
        {/* Main Video */}
        <div className="w-full h-full bg-gray-900 flex items-center justify-center">
          {isVideoOff ? (
            <div className="text-center text-white">
              <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="User" size={48} color="white" />
              </div>
              <p className="text-lg font-medium">{consultation?.farmerName}</p>
              <p className="text-sm text-white/80">Video is turned off</p>
            </div>
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
              <div className="text-center text-white">
                <Icon name="Video" size={64} className="mx-auto mb-4 opacity-50" />
                <p className="text-lg">Video call in progress...</p>
              </div>
            </div>
          )}
          
          {/* Picture-in-Picture (Officer's view) */}
          <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-lg border-2 border-white/20 overflow-hidden">
            <div className="w-full h-full bg-gradient-to-br from-secondary/20 to-primary/20 flex items-center justify-center">
              <div className="text-center text-white">
                <Icon name="User" size={32} className="mx-auto mb-2 opacity-80" />
                <p className="text-sm">You</p>
              </div>
            </div>
          </div>
          
          {/* Screen Sharing Indicator */}
          {isScreenSharing && (
            <div className="absolute top-4 left-4 bg-accent text-white px-3 py-2 rounded-lg flex items-center space-x-2">
              <Icon name="Monitor" size={16} />
              <span className="text-sm font-medium">Screen Sharing</span>
            </div>
          )}
        </div>
      </div>
      {/* Controls */}
      <div className="bg-black/50 backdrop-blur-sm p-6">
        <div className="flex items-center justify-center space-x-4">
          <Button
            variant={isMuted ? "destructive" : "secondary"}
            size="lg"
            onClick={handleMuteToggle}
            className="rounded-full w-14 h-14"
          >
            <Icon name={isMuted ? "MicOff" : "Mic"} size={24} />
          </Button>
          
          <Button
            variant={isVideoOff ? "destructive" : "secondary"}
            size="lg"
            onClick={handleVideoToggle}
            className="rounded-full w-14 h-14"
          >
            <Icon name={isVideoOff ? "VideoOff" : "Video"} size={24} />
          </Button>
          
          <Button
            variant={isScreenSharing ? "accent" : "secondary"}
            size="lg"
            onClick={handleScreenShare}
            className="rounded-full w-14 h-14"
          >
            <Icon name="Monitor" size={24} />
          </Button>
          
          <Button
            variant="secondary"
            size="lg"
            className="rounded-full w-14 h-14"
          >
            <Icon name="MessageCircle" size={24} />
          </Button>
          
          <Button
            variant="secondary"
            size="lg"
            className="rounded-full w-14 h-14"
          >
            <Icon name="Settings" size={24} />
          </Button>
          
          <Button
            variant="destructive"
            size="lg"
            onClick={onEndCall}
            className="rounded-full w-14 h-14"
          >
            <Icon name="PhoneOff" size={24} />
          </Button>
        </div>
        
        {/* Additional Controls */}
        <div className="flex items-center justify-center space-x-6 mt-4">
          <button className="text-white/80 hover:text-white flex items-center space-x-2 text-sm">
            <Icon name="FileText" size={16} />
            <span>Notes</span>
          </button>
          
          <button className="text-white/80 hover:text-white flex items-center space-x-2 text-sm">
            <Icon name="Camera" size={16} />
            <span>Screenshot</span>
          </button>
          
          <button className="text-white/80 hover:text-white flex items-center space-x-2 text-sm">
            <Icon name="Users" size={16} />
            <span>Invite Expert</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default VideoConsultation;