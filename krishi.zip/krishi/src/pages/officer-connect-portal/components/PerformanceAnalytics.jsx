import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const PerformanceAnalytics = () => {
  const [timeRange, setTimeRange] = useState('7d');

  const timeRangeOptions = [
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 3 Months' },
    { value: '1y', label: 'Last Year' }
  ];

  const queryResolutionData = [
    { day: 'Mon', resolved: 12, pending: 3, escalated: 1 },
    { day: 'Tue', resolved: 15, pending: 2, escalated: 2 },
    { day: 'Wed', resolved: 18, pending: 4, escalated: 1 },
    { day: 'Thu', resolved: 14, pending: 5, escalated: 3 },
    { day: 'Fri', resolved: 20, pending: 2, escalated: 1 },
    { day: 'Sat', resolved: 8, pending: 1, escalated: 0 },
    { day: 'Sun', resolved: 6, pending: 2, escalated: 1 }
  ];

  const responseTimeData = [
    { day: 'Mon', avgTime: 2.5 },
    { day: 'Tue', avgTime: 1.8 },
    { day: 'Wed', avgTime: 3.2 },
    { day: 'Thu', avgTime: 2.1 },
    { day: 'Fri', avgTime: 1.9 },
    { day: 'Sat', avgTime: 4.1 },
    { day: 'Sun', avgTime: 3.8 }
  ];

  const categoryDistribution = [
    { name: 'Crop Disease', value: 35, color: '#2E7D32' },
    { name: 'Pest Control', value: 25, color: '#FF8F00' },
    { name: 'Soil Health', value: 20, color: '#1976D2' },
    { name: 'Weather', value: 12, color: '#5D4037' },
    { name: 'Others', value: 8, color: '#616161' }
  ];

  const satisfactionData = [
    { month: 'Jan', satisfaction: 4.2 },
    { month: 'Feb', satisfaction: 4.4 },
    { month: 'Mar', satisfaction: 4.1 },
    { month: 'Apr', satisfaction: 4.6 },
    { month: 'May', satisfaction: 4.5 },
    { month: 'Jun', satisfaction: 4.7 },
    { month: 'Jul', satisfaction: 4.8 },
    { month: 'Aug', satisfaction: 4.6 },
    { month: 'Sep', satisfaction: 4.9 }
  ];

  const performanceMetrics = [
    {
      title: 'Total Queries Handled',
      value: '1,247',
      change: '+12%',
      changeType: 'positive',
      icon: 'MessageCircle',
      color: 'primary'
    },
    {
      title: 'Average Response Time',
      value: '2.3h',
      change: '-15%',
      changeType: 'positive',
      icon: 'Clock',
      color: 'success'
    },
    {
      title: 'Resolution Rate',
      value: '94.2%',
      change: '+3%',
      changeType: 'positive',
      icon: 'CheckCircle',
      color: 'accent'
    },
    {
      title: 'Farmer Satisfaction',
      value: '4.7/5',
      change: '+0.2',
      changeType: 'positive',
      icon: 'Star',
      color: 'warning'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-poppins font-bold text-foreground">Performance Analytics</h2>
          <p className="text-muted-foreground">Track your query resolution and farmer satisfaction metrics</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Select
            options={timeRangeOptions}
            value={timeRange}
            onChange={setTimeRange}
            className="w-40"
          />
          
          <Button
            variant="outline"
            iconName="Download"
            iconPosition="left"
          >
            Export Report
          </Button>
        </div>
      </div>
      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {performanceMetrics?.map((metric, index) => (
          <div key={index} className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground mb-1">{metric?.title}</p>
                <p className="text-2xl font-poppins font-bold text-foreground">{metric?.value}</p>
                
                <div className="flex items-center space-x-1 mt-2">
                  <Icon 
                    name={metric?.changeType === 'positive' ? 'TrendingUp' : 'TrendingDown'} 
                    size={14} 
                    className={metric?.changeType === 'positive' ? 'text-success' : 'text-error'}
                  />
                  <span className={`text-sm font-medium ${metric?.changeType === 'positive' ? 'text-success' : 'text-error'}`}>
                    {metric?.change}
                  </span>
                  <span className="text-sm text-muted-foreground">vs last period</span>
                </div>
              </div>
              
              <div className={`w-12 h-12 rounded-lg border flex items-center justify-center ${
                metric?.color === 'primary' ? 'bg-primary/10 text-primary border-primary/20' :
                metric?.color === 'success' ? 'bg-success/10 text-success border-success/20' :
                metric?.color === 'accent' ? 'bg-accent/10 text-accent border-accent/20' :
                metric?.color === 'warning'? 'bg-warning/10 text-warning border-warning/20' : 'bg-muted text-muted-foreground border-border'
              }`}>
                <Icon name={metric?.icon} size={24} />
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Query Resolution Chart */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-poppins font-semibold text-foreground">Query Resolution Trends</h3>
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-primary rounded-full"></div>
                <span className="text-muted-foreground">Resolved</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-warning rounded-full"></div>
                <span className="text-muted-foreground">Pending</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-error rounded-full"></div>
                <span className="text-muted-foreground">Escalated</span>
              </div>
            </div>
          </div>
          
          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={queryResolutionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E0E0E0" />
                <XAxis dataKey="day" stroke="#616161" />
                <YAxis stroke="#616161" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #E0E0E0', 
                    borderRadius: '8px' 
                  }} 
                />
                <Bar dataKey="resolved" fill="#2E7D32" radius={[2, 2, 0, 0]} />
                <Bar dataKey="pending" fill="#FF9800" radius={[2, 2, 0, 0]} />
                <Bar dataKey="escalated" fill="#F44336" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Response Time Chart */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-poppins font-semibold text-foreground">Average Response Time</h3>
            <span className="text-sm text-muted-foreground">Hours</span>
          </div>
          
          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={responseTimeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E0E0E0" />
                <XAxis dataKey="day" stroke="#616161" />
                <YAxis stroke="#616161" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #E0E0E0', 
                    borderRadius: '8px' 
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="avgTime" 
                  stroke="#2E7D32" 
                  strokeWidth={3}
                  dot={{ fill: '#2E7D32', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Distribution */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="font-poppins font-semibold text-foreground mb-6">Query Categories</h3>
          
          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryDistribution?.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry?.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #E0E0E0', 
                    borderRadius: '8px' 
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="space-y-2 mt-4">
            {categoryDistribution?.map((category, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: category?.color }}
                  ></div>
                  <span className="text-sm text-foreground">{category?.name}</span>
                </div>
                <span className="text-sm font-medium text-foreground">{category?.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Satisfaction Trend */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-poppins font-semibold text-foreground">Farmer Satisfaction Trend</h3>
            <span className="text-sm text-muted-foreground">Rating out of 5</span>
          </div>
          
          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={satisfactionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E0E0E0" />
                <XAxis dataKey="month" stroke="#616161" />
                <YAxis domain={[3.5, 5]} stroke="#616161" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #E0E0E0', 
                    borderRadius: '8px' 
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="satisfaction" 
                  stroke="#FF8F00" 
                  strokeWidth={3}
                  dot={{ fill: '#FF8F00', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      {/* Performance Insights */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="font-poppins font-semibold text-foreground mb-4">Performance Insights</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-success/10 border border-success/20 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="TrendingUp" size={16} className="text-success" />
              <span className="text-sm font-medium text-success">Improvement</span>
            </div>
            <p className="text-sm text-foreground">Response time improved by 15% this week compared to last week.</p>
          </div>
          
          <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="AlertTriangle" size={16} className="text-warning" />
              <span className="text-sm font-medium text-warning">Attention Needed</span>
            </div>
            <p className="text-sm text-foreground">Weekend queries have longer response times. Consider weekend coverage.</p>
          </div>
          
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Target" size={16} className="text-primary" />
              <span className="text-sm font-medium text-primary">Goal Achievement</span>
            </div>
            <p className="text-sm text-foreground">You're 94% towards your monthly resolution target of 500 queries.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceAnalytics;