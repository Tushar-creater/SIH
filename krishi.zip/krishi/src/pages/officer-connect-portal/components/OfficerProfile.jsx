import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const OfficerProfile = ({ officer, onEditProfile, onViewSchedule }) => {
  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-start space-x-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-primary/20">
            <Image 
              src={officer?.avatar} 
              alt={officer?.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-success rounded-full border-2 border-white flex items-center justify-center">
            <div className="w-2 h-2 bg-white rounded-full"></div>
          </div>
        </div>
        
        <div className="flex-1">
          <h3 className="font-poppins font-semibold text-foreground text-lg">{officer?.name}</h3>
          <p className="text-primary font-medium mb-1">{officer?.designation}</p>
          <p className="text-sm text-muted-foreground mb-2">{officer?.department}</p>
          
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="MapPin" size={14} />
              <span>{officer?.jurisdiction}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Users" size={14} />
              <span>{officer?.farmersServed} farmers</span>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col space-y-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onEditProfile}
            iconName="Edit"
            iconPosition="left"
            iconSize={14}
          >
            Edit Profile
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onViewSchedule}
            iconName="Calendar"
            iconPosition="left"
            iconSize={14}
          >
            Schedule
          </Button>
        </div>
      </div>
      {/* Expertise Tags */}
      <div className="mt-4 pt-4 border-t border-border">
        <p className="text-sm font-medium text-foreground mb-2">Expertise Areas</p>
        <div className="flex flex-wrap gap-2">
          {officer?.expertise?.map((skill, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full border border-primary/20"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
      {/* Quick Stats */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-lg font-poppins font-bold text-foreground">{officer?.stats?.queriesResolved}</p>
            <p className="text-xs text-muted-foreground">Resolved</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-poppins font-bold text-foreground">{officer?.stats?.avgResponseTime}h</p>
            <p className="text-xs text-muted-foreground">Avg Response</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-poppins font-bold text-foreground">{officer?.stats?.satisfaction}%</p>
            <p className="text-xs text-muted-foreground">Satisfaction</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfficerProfile;