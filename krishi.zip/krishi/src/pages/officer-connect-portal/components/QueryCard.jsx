import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const QueryCard = ({ query, onViewDetails, onAssign, onResolve }) => {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'urgent': return 'text-error bg-error/10 border-error/20';
      case 'high': return 'text-warning bg-warning/10 border-warning/20';
      case 'medium': return 'text-accent bg-accent/10 border-accent/20';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'text-warning bg-warning/10';
      case 'in-progress': return 'text-primary bg-primary/10';
      case 'resolved': return 'text-success bg-success/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const queryTime = new Date(timestamp);
    const diffInHours = Math.floor((now - queryTime) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-all duration-300">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center">
            <Icon name="User" size={20} color="white" />
          </div>
          <div>
            <h3 className="font-poppins font-semibold text-foreground">{query?.farmerName}</h3>
            <p className="text-sm text-muted-foreground">{query?.location}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(query?.priority)}`}>
            {query?.priority?.toUpperCase()}
          </span>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(query?.status)}`}>
            {query?.status?.replace('-', ' ')?.toUpperCase()}
          </span>
        </div>
      </div>
      {/* Query Content */}
      <div className="mb-4">
        <div className="flex items-center space-x-2 mb-2">
          <Icon name={query?.category === 'crop-disease' ? 'Bug' : query?.category === 'weather' ? 'Cloud' : 'HelpCircle'} size={16} className="text-primary" />
          <span className="text-sm font-medium text-primary capitalize">{query?.category?.replace('-', ' ')}</span>
          <span className="text-sm text-muted-foreground">•</span>
          <span className="text-sm text-muted-foreground">{formatTimeAgo(query?.timestamp)}</span>
        </div>
        
        <p className="text-foreground mb-3 line-clamp-2">{query?.description}</p>
        
        {query?.images && query?.images?.length > 0 && (
          <div className="flex space-x-2 mb-3">
            {query?.images?.slice(0, 3)?.map((image, index) => (
              <div key={index} className="w-16 h-16 rounded-lg overflow-hidden border border-border">
                <Image 
                  src={image} 
                  alt={`Query image ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
            {query?.images?.length > 3 && (
              <div className="w-16 h-16 rounded-lg bg-muted border border-border flex items-center justify-center">
                <span className="text-xs text-muted-foreground">+{query?.images?.length - 3}</span>
              </div>
            )}
          </div>
        )}
      </div>
      {/* Farmer Details */}
      <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1">
            <Icon name="Phone" size={14} />
            <span>{query?.phone}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="MapPin" size={14} />
            <span>{query?.district}</span>
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <Icon name="Languages" size={14} />
          <span>{query?.preferredLanguage}</span>
        </div>
      </div>
      {/* Actions */}
      <div className="flex items-center justify-between pt-4 border-t border-border">
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onViewDetails(query)}
            iconName="Eye"
            iconPosition="left"
            iconSize={14}
          >
            View Details
          </Button>
          
          {query?.status === 'pending' && (
            <Button
              variant="default"
              size="sm"
              onClick={() => onAssign(query)}
              iconName="UserPlus"
              iconPosition="left"
              iconSize={14}
            >
              Assign
            </Button>
          )}
          
          {query?.status === 'in-progress' && (
            <Button
              variant="success"
              size="sm"
              onClick={() => onResolve(query)}
              iconName="CheckCircle"
              iconPosition="left"
              iconSize={14}
            >
              Mark Resolved
            </Button>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            iconName="MessageCircle"
            iconSize={16}
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="Video"
            iconSize={16}
          />
          <Button
            variant="ghost"
            size="sm"
            iconName="Phone"
            iconSize={16}
          />
        </div>
      </div>
    </div>
  );
};

export default QueryCard;