import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const KnowledgeBase = ({ onSelectResource }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Resources', icon: 'BookOpen', count: 156 },
    { id: 'crop-diseases', name: 'Crop Diseases', icon: 'Bug', count: 45 },
    { id: 'soil-management', name: 'Soil Management', icon: 'Layers', count: 32 },
    { id: 'pest-control', name: 'Pest Control', icon: 'Shield', count: 28 },
    { id: 'fertilizers', name: 'Fertilizers', icon: 'Droplets', count: 24 },
    { id: 'government-schemes', name: 'Government Schemes', icon: 'FileText', count: 18 },
    { id: 'weather-advisory', name: 'Weather Advisory', icon: 'Cloud', count: 9 }
  ];

  const resources = [
    {
      id: 1,
      title: "Complete Guide to Rice Blast Disease Management",
      category: "crop-diseases",
      type: "research-paper",
      author: "Dr. Rajesh Kumar",
      institution: "IARI, New Delhi",
      publishedDate: "2024-08-15",
      downloads: 1250,
      rating: 4.8,
      description: `Comprehensive research on rice blast disease identification, prevention, and treatment methods. Includes latest fungicide recommendations and integrated pest management strategies.`,
      tags: ["Rice", "Blast Disease", "Fungicide", "IPM"],
      thumbnail: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=300&h=200&fit=crop"
    },
    {
      id: 2,
      title: "Soil Health Assessment Techniques for Indian Agriculture",
      category: "soil-management",
      type: "technical-guide",
      author: "Dr. Priya Sharma",
      institution: "ICRISAT, Hyderabad",
      publishedDate: "2024-09-01",
      downloads: 890,
      rating: 4.6,
      description: `Detailed methodology for soil testing, nutrient management, and organic matter enhancement in Indian agricultural conditions.`,
      tags: ["Soil Testing", "Nutrients", "Organic Matter"],
      thumbnail: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=300&h=200&fit=crop"
    },
    {
      id: 3,
      title: "PM-KISAN Scheme: Complete Application Guide 2024",
      category: "government-schemes",
      type: "policy-document",
      author: "Ministry of Agriculture",
      institution: "Government of India",
      publishedDate: "2024-09-10",
      downloads: 2100,
      rating: 4.9,
      description: `Updated guidelines for PM-KISAN scheme application, eligibility criteria, and documentation requirements for 2024-25.`,
      tags: ["PM-KISAN", "Subsidy", "Application", "Documentation"],
      thumbnail: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=300&h=200&fit=crop"
    },
    {
      id: 4,
      title: "Integrated Pest Management for Cotton Crops",
      category: "pest-control",
      type: "best-practices",
      author: "Dr. Anil Verma",
      institution: "CICR, Nagpur",
      publishedDate: "2024-08-28",
      downloads: 675,
      rating: 4.7,
      description: `Sustainable pest control strategies for cotton cultivation including biological control agents and resistant varieties.`,
      tags: ["Cotton", "IPM", "Biological Control", "Resistant Varieties"],
      thumbnail: "https://images.unsplash.com/photo-1516738901171-8eb4fc13bd20?w=300&h=200&fit=crop"
    }
  ];

  const filteredResources = resources?.filter(resource => {
    const matchesSearch = resource?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                         resource?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
                         resource?.tags?.some(tag => tag?.toLowerCase()?.includes(searchQuery?.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || resource?.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getTypeIcon = (type) => {
    switch (type) {
      case 'research-paper': return 'FileText';
      case 'technical-guide': return 'BookOpen';
      case 'policy-document': return 'FileCheck';
      case 'best-practices': return 'Lightbulb';
      default: return 'File';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'research-paper': return 'text-primary bg-primary/10 border-primary/20';
      case 'technical-guide': return 'text-accent bg-accent/10 border-accent/20';
      case 'policy-document': return 'text-success bg-success/10 border-success/20';
      case 'best-practices': return 'text-warning bg-warning/10 border-warning/20';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-poppins font-bold text-foreground">Knowledge Base</h2>
          <p className="text-muted-foreground">Access technical resources and research papers</p>
        </div>
        
        <Button
          variant="outline"
          iconName="Upload"
          iconPosition="left"
        >
          Upload Resource
        </Button>
      </div>
      {/* Search */}
      <div className="bg-card border border-border rounded-lg p-6">
        <Input
          type="search"
          placeholder="Search resources, topics, or authors..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e?.target?.value)}
          className="mb-4"
        />
        
        {/* Categories */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {categories?.map((category) => (
            <button
              key={category?.id}
              onClick={() => setSelectedCategory(category?.id)}
              className={`p-3 rounded-lg border text-center transition-all duration-200 ${
                selectedCategory === category?.id
                  ? 'bg-primary text-primary-foreground border-primary shadow-growth'
                  : 'bg-card text-foreground border-border hover:bg-muted'
              }`}
            >
              <Icon name={category?.icon} size={20} className="mx-auto mb-2" />
              <p className="text-xs font-medium mb-1">{category?.name}</p>
              <p className="text-xs opacity-80">{category?.count}</p>
            </button>
          ))}
        </div>
      </div>
      {/* Resources Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredResources?.map((resource) => (
          <div key={resource?.id} className="bg-card border border-border rounded-lg overflow-hidden hover:shadow-md transition-all duration-300">
            <div className="aspect-video relative overflow-hidden">
              <Image 
                src={resource?.thumbnail} 
                alt={resource?.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3 left-3">
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getTypeColor(resource?.type)}`}>
                  <Icon name={getTypeIcon(resource?.type)} size={12} className="inline mr-1" />
                  {resource?.type?.replace('-', ' ')?.toUpperCase()}
                </span>
              </div>
              <div className="absolute top-3 right-3 bg-black/50 text-white px-2 py-1 rounded-full text-xs">
                <Icon name="Download" size={12} className="inline mr-1" />
                {resource?.downloads}
              </div>
            </div>
            
            <div className="p-6">
              <h3 className="font-poppins font-semibold text-foreground mb-2 line-clamp-2">
                {resource?.title}
              </h3>
              
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                {resource?.description}
              </p>
              
              <div className="flex items-center justify-between text-sm text-muted-foreground mb-3">
                <div>
                  <p className="font-medium text-foreground">{resource?.author}</p>
                  <p>{resource?.institution}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={14} className="text-warning fill-current" />
                    <span>{resource?.rating}</span>
                  </div>
                  <p>{new Date(resource.publishedDate)?.toLocaleDateString()}</p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-1 mb-4">
                {resource?.tags?.slice(0, 3)?.map((tag, index) => (
                  <span 
                    key={index}
                    className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-full"
                  >
                    {tag}
                  </span>
                ))}
                {resource?.tags?.length > 3 && (
                  <span className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-full">
                    +{resource?.tags?.length - 3}
                  </span>
                )}
              </div>
              
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onSelectResource(resource)}
                  iconName="Eye"
                  iconPosition="left"
                  iconSize={14}
                >
                  View Details
                </Button>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Download"
                    iconSize={16}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Share"
                    iconSize={16}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="Bookmark"
                    iconSize={16}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      {filteredResources?.length === 0 && (
        <div className="text-center py-12">
          <Icon name="Search" size={48} className="mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-poppins font-semibold text-foreground mb-2">No resources found</h3>
          <p className="text-muted-foreground">Try adjusting your search terms or category filter</p>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBase;