import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import QueryCard from './components/QueryCard';
import StatsCard from './components/StatsCard';
import OfficerProfile from './components/OfficerProfile';
import QueryFilters from './components/QueryFilters';
import VideoConsultation from './components/VideoConsultation';
import KnowledgeBase from './components/KnowledgeBase';
import PerformanceAnalytics from './components/PerformanceAnalytics';

const OfficerConnectPortal = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [selectedQuery, setSelectedQuery] = useState(null);
  const [filters, setFilters] = useState({
    status: 'all',
    priority: 'all',
    category: 'all',
    language: 'all',
    search: '',
    dateFrom: '',
    dateTo: ''
  });

  // Mock data for officer profile
  const officerData = {
    name: "Dr. Rajesh Kumar Singh",
    designation: "Senior Agricultural Extension Officer",
    department: "Department of Agriculture, Uttar Pradesh",
    jurisdiction: "Lucknow District",
    farmersServed: 1247,
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    expertise: ["Crop Disease Management", "Soil Health", "Pest Control", "Government Schemes", "Organic Farming"],
    stats: {
      queriesResolved: 1156,
      avgResponseTime: 2.3,
      satisfaction: 94
    }
  };

  // Mock data for queries
  const queriesData = [
    {
      id: 1,
      farmerName: "Ramesh Sharma",
      location: "Village Rampur, Lucknow",
      district: "Lucknow",
      phone: "+91 9876543210",
      preferredLanguage: "Hindi",
      category: "crop-disease",
      priority: "urgent",
      status: "pending",
      description: `My wheat crop is showing yellow spots on leaves and some plants are dying. This started 3 days ago after the recent rain. I have attached photos of affected plants. Please help urgently as the disease is spreading fast.`,
      images: [
        "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=300&h=200&fit=crop",
        "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=300&h=200&fit=crop"
      ],
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
    },
    {
      id: 2,
      farmerName: "Priya Devi",
      location: "Village Sultanpur, Lucknow",
      district: "Lucknow",
      phone: "+91 9876543211",
      preferredLanguage: "Hindi",
      category: "pest-control",
      priority: "high",
      status: "in-progress",
      description: `There are small green insects attacking my tomato plants. They are eating the leaves and flowers. I tried neem oil spray but it's not working effectively. What other treatment should I use?`,
      images: [
        "https://images.unsplash.com/photo-1592419044706-39796d40f98c?w=300&h=200&fit=crop"
      ],
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000) // 5 hours ago
    },
    {
      id: 3,
      farmerName: "Suresh Yadav",
      location: "Village Mohanlalganj, Lucknow",
      district: "Lucknow",
      phone: "+91 9876543212",
      preferredLanguage: "Hindi",
      category: "soil-health",
      priority: "medium",
      status: "pending",
      description: `I want to test my soil before sowing the next crop. Where can I get soil testing done and what is the procedure? Also, what documents are required for soil health card?`,
      images: [],
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000) // 8 hours ago
    },
    {
      id: 4,
      farmerName: "Kavita Singh",
      location: "Village Malihabad, Lucknow",
      district: "Lucknow",
      phone: "+91 9876543213",
      preferredLanguage: "Hindi",
      category: "government-scheme",
      priority: "low",
      status: "resolved",
      description: `I applied for PM-KISAN scheme 3 months ago but haven't received any payment yet. My application status shows approved. When will I receive the money? My registration number is PM123456789.`,
      images: [],
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
    }
  ];

  // Mock consultation data
  const consultationData = {
    farmerName: "Ramesh Sharma",
    farmerAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    location: "Village Rampur, Lucknow",
    queryId: 1
  };

  // Stats data
  const statsData = [
    {
      title: "Pending Queries",
      value: "23",
      change: "+5",
      changeType: "negative",
      icon: "Clock",
      color: "warning"
    },
    {
      title: "Resolved Today",
      value: "18",
      change: "+12%",
      changeType: "positive",
      icon: "CheckCircle",
      color: "success"
    },
    {
      title: "Active Farmers",
      value: "1,247",
      change: "+8%",
      changeType: "positive",
      icon: "Users",
      color: "primary"
    },
    {
      title: "Satisfaction Rate",
      value: "94%",
      change: "+2%",
      changeType: "positive",
      icon: "Star",
      color: "accent"
    }
  ];

  const tabs = [
    { id: 'dashboard', name: 'Dashboard', icon: 'LayoutDashboard' },
    { id: 'queries', name: 'Queries', icon: 'MessageCircle' },
    { id: 'knowledge', name: 'Knowledge Base', icon: 'BookOpen' },
    { id: 'analytics', name: 'Analytics', icon: 'BarChart3' }
  ];

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleClearFilters = () => {
    setFilters({
      status: 'all',
      priority: 'all',
      category: 'all',
      language: 'all',
      search: '',
      dateFrom: '',
      dateTo: ''
    });
  };

  const handleViewDetails = (query) => {
    setSelectedQuery(query);
    // Open query details modal or navigate to details page
    console.log('View details for query:', query);
  };

  const handleAssignQuery = (query) => {
    console.log('Assign query:', query);
    // Implement query assignment logic
  };

  const handleResolveQuery = (query) => {
    console.log('Resolve query:', query);
    // Implement query resolution logic
  };

  const handleStartVideoCall = () => {
    setShowVideoCall(true);
  };

  const handleEndVideoCall = () => {
    setShowVideoCall(false);
  };

  const handleToggleMute = (isMuted) => {
    console.log('Toggle mute:', isMuted);
  };

  const handleToggleVideo = (isVideoOff) => {
    console.log('Toggle video:', isVideoOff);
  };

  const handleShareScreen = (isSharing) => {
    console.log('Share screen:', isSharing);
  };

  const handleSelectResource = (resource) => {
    console.log('Select resource:', resource);
    // Open resource details or download
  };

  const handleEditProfile = () => {
    console.log('Edit profile');
    // Open profile edit modal
  };

  const handleViewSchedule = () => {
    console.log('View schedule');
    // Open schedule view
  };

  // Filter queries based on current filters
  const filteredQueries = queriesData?.filter(query => {
    const matchesStatus = filters?.status === 'all' || query?.status === filters?.status;
    const matchesPriority = filters?.priority === 'all' || query?.priority === filters?.priority;
    const matchesCategory = filters?.category === 'all' || query?.category === filters?.category;
    const matchesLanguage = filters?.language === 'all' || query?.preferredLanguage?.toLowerCase() === filters?.language;
    const matchesSearch = !filters?.search || 
      query?.farmerName?.toLowerCase()?.includes(filters?.search?.toLowerCase()) ||
      query?.location?.toLowerCase()?.includes(filters?.search?.toLowerCase()) ||
      query?.description?.toLowerCase()?.includes(filters?.search?.toLowerCase());
    
    return matchesStatus && matchesPriority && matchesCategory && matchesLanguage && matchesSearch;
  });

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {statsData?.map((stat, index) => (
                <StatsCard key={index} {...stat} />
              ))}
            </div>
            {/* Officer Profile & Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <OfficerProfile 
                  officer={officerData}
                  onEditProfile={handleEditProfile}
                  onViewSchedule={handleViewSchedule}
                />
              </div>
              
              <div className="space-y-4">
                <div className="bg-card border border-border rounded-lg p-6">
                  <h3 className="font-poppins font-semibold text-foreground mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <Button
                      variant="default"
                      fullWidth
                      iconName="Video"
                      iconPosition="left"
                      onClick={handleStartVideoCall}
                    >
                      Start Video Consultation
                    </Button>
                    <Button
                      variant="outline"
                      fullWidth
                      iconName="MessageCircle"
                      iconPosition="left"
                    >
                      Broadcast Advisory
                    </Button>
                    <Button
                      variant="outline"
                      fullWidth
                      iconName="FileText"
                      iconPosition="left"
                    >
                      Create Report
                    </Button>
                  </div>
                </div>
                
                <div className="bg-card border border-border rounded-lg p-6">
                  <h3 className="font-poppins font-semibold text-foreground mb-4">Today's Schedule</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-primary/10 rounded-lg">
                      <Icon name="Clock" size={16} className="text-primary" />
                      <div>
                        <p className="text-sm font-medium text-foreground">Field Visit</p>
                        <p className="text-xs text-muted-foreground">10:00 AM - Village Rampur</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-accent/10 rounded-lg">
                      <Icon name="Users" size={16} className="text-accent" />
                      <div>
                        <p className="text-sm font-medium text-foreground">Farmer Meeting</p>
                        <p className="text-xs text-muted-foreground">2:00 PM - District Office</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Recent Queries */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-poppins font-semibold text-foreground">Recent Queries</h3>
                <Button
                  variant="outline"
                  onClick={() => setActiveTab('queries')}
                  iconName="ArrowRight"
                  iconPosition="right"
                >
                  View All
                </Button>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {queriesData?.slice(0, 4)?.map((query) => (
                  <QueryCard
                    key={query?.id}
                    query={query}
                    onViewDetails={handleViewDetails}
                    onAssign={handleAssignQuery}
                    onResolve={handleResolveQuery}
                  />
                ))}
              </div>
            </div>
          </div>
        );

      case 'queries':
        return (
          <div className="space-y-6">
            <QueryFilters
              filters={filters}
              onFilterChange={handleFilterChange}
              onClearFilters={handleClearFilters}
            />
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-poppins font-semibold text-foreground">
                All Queries ({filteredQueries?.length})
              </h3>
              
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  iconName="Download"
                  iconPosition="left"
                >
                  Export
                </Button>
                <Button
                  variant="default"
                  iconName="Plus"
                  iconPosition="left"
                >
                  Create Advisory
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredQueries?.map((query) => (
                <QueryCard
                  key={query?.id}
                  query={query}
                  onViewDetails={handleViewDetails}
                  onAssign={handleAssignQuery}
                  onResolve={handleResolveQuery}
                />
              ))}
            </div>
            {filteredQueries?.length === 0 && (
              <div className="text-center py-12">
                <Icon name="Search" size={48} className="mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-poppins font-semibold text-foreground mb-2">No queries found</h3>
                <p className="text-muted-foreground">Try adjusting your filters to see more results</p>
              </div>
            )}
          </div>
        );

      case 'knowledge':
        return <KnowledgeBase onSelectResource={handleSelectResource} />;

      case 'analytics':
        return <PerformanceAnalytics />;

      default:
        return null;
    }
  };

  return (
    <>
      <Helmet>
        <title>Officer Connect Portal - KrishiMitra</title>
        <meta name="description" content="Agricultural extension officer dashboard for managing farmer queries and providing expert guidance through KrishiMitra platform." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        <div className="pt-16">
          <div className="w-full px-4 lg:px-6 py-8">
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center">
                  <Icon name="Users" size={24} color="white" />
                </div>
                <div>
                  <h1 className="text-3xl font-poppins font-bold text-foreground">Officer Connect Portal</h1>
                  <p className="text-muted-foreground">Manage farmer queries and provide expert agricultural guidance</p>
                </div>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="mb-8">
              <div className="border-b border-border">
                <nav className="flex space-x-8">
                  {tabs?.map((tab) => (
                    <button
                      key={tab?.id}
                      onClick={() => setActiveTab(tab?.id)}
                      className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                        activeTab === tab?.id
                          ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                      }`}
                    >
                      <Icon name={tab?.icon} size={18} />
                      <span>{tab?.name}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Tab Content */}
            <div className="animate-fade-in">
              {renderTabContent()}
            </div>
          </div>
        </div>

        {/* Video Consultation Modal */}
        {showVideoCall && (
          <VideoConsultation
            consultation={consultationData}
            onEndCall={handleEndVideoCall}
            onToggleMute={handleToggleMute}
            onToggleVideo={handleToggleVideo}
            onShareScreen={handleShareScreen}
          />
        )}
      </div>
    </>
  );
};

export default OfficerConnectPortal;