import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Header from '../../components/ui/Header';
import SchemeCard from './components/SchemeCard';
import FilterPanel from './components/FilterPanel';
import EligibilityChecker from './components/EligibilityChecker';
import SchemeDetails from './components/SchemeDetails';
import ApplicationTracker from './components/ApplicationTracker';
import ComparisonTool from './components/ComparisonTool';

const GovernmentSchemesNavigator = () => {
  const [schemes, setSchemes] = useState([]);
  const [filteredSchemes, setFilteredSchemes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedScheme, setSelectedScheme] = useState(null);
  const [showEligibilityChecker, setShowEligibilityChecker] = useState(false);
  const [showSchemeDetails, setShowSchemeDetails] = useState(false);
  const [showApplicationTracker, setShowApplicationTracker] = useState(false);
  const [showComparisonTool, setShowComparisonTool] = useState(false);
  const [isFilterCollapsed, setIsFilterCollapsed] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('relevance');

  const [filters, setFilters] = useState({
    search: '',
    state: 'all',
    cropType: 'all',
    landSize: 'all',
    benefitRange: 'all',
    schemeTypes: [],
    onlyOpen: false,
    onlyNew: false,
    highSuccessRate: false,
    minAge: '',
    maxAge: '',
    maxIncome: ''
  });

  // Mock schemes data
  const mockSchemes = [
    {
      id: 'pm-kisan',
      name: 'PM-KISAN Samman Nidhi',
      description: 'Direct income support to farmers with landholding up to 2 hectares',
      fullDescription: `The Pradhan Mantri Kisan Samman Nidhi (PM-KISAN) is a Central Sector Scheme launched in February 2019 to supplement the financial needs of land holding farmers. Under the scheme, financial benefit of Rs.6000/- per year is transferred in three equal installments of Rs.2000/- each every four months into the bank accounts of landholding farmer families across the country.`,
      agency: 'Ministry of Agriculture & Farmers Welfare',
      department: 'Department of Agriculture & Cooperation',
      coverage: 'All India',
      maxBenefit: 6000,
      beneficiaries: '11.8 Cr',
      successRate: 92,
      isNew: false,
      deadline: '31-03-2025',
      daysLeft: 165,
      keyFeatures: ['Direct Bank Transfer', 'No Application Fee', 'Online Application', 'Aadhaar Linked'],
      eligibility: {
        cropType: 'All Crops',
        landSize: 'Up to 2 hectares',
        income: 'No Income Limit',
        age: '18+ years'
      },
      eligibilityDetails: {
        basic: [
          'Must be a landholding farmer family',
          'Land holding should not exceed 2 hectares',
          'Must have valid Aadhaar card',
          'Bank account should be linked with Aadhaar'
        ],
        age: '18 years and above',
        income: 'No income limit specified',
        landSize: 'Up to 2 hectares of cultivable land',
        cropType: 'All types of crops eligible',
        exclusions: [
          'Institutional landholders',
          'Farmer families with any member as income tax payer',
          'Farmer families with members holding constitutional posts'
        ]
      },
      documents: {
        required: [
          { name: 'Aadhaar Card', description: 'Valid Aadhaar card of the applicant' },
          { name: 'Bank Account Details', description: 'Bank passbook or cancelled cheque' },
          { name: 'Land Records', description: 'Khatauni/Khata number, Survey number' }
        ],
        optional: [
          { name: 'Mobile Number', description: 'For SMS updates' },
          { name: 'Email ID', description: 'For email notifications' }
        ]
      },
      applicationProcess: [
        {
          title: 'Online Registration',
          description: 'Visit PM-KISAN portal and register with required details',
          duration: '10-15 minutes'
        },
        {
          title: 'Document Upload',
          description: 'Upload scanned copies of required documents',
          duration: '5-10 minutes'
        },
        {
          title: 'Verification',
          description: 'Local revenue officer verifies the application',
          duration: '7-15 days'
        },
        {
          title: 'Approval',
          description: 'Application approved and added to beneficiary list',
          duration: '15-30 days'
        },
        {
          title: 'Benefit Transfer',
          description: 'First installment transferred to bank account',
          duration: '30-45 days'
        }
      ],
      benefits: {
        financial: [
          {
            type: 'Annual Income Support',
            amount: 6000,
            description: 'Paid in 3 installments of ₹2000 each'
          }
        ],
        nonFinancial: [
          {
            type: 'Direct Benefit Transfer',
            description: 'Money directly credited to bank account'
          },
          {
            type: 'No Intermediary',
            description: 'No middleman involvement in benefit transfer'
          }
        ]
      },
      successStories: [
        {
          name: 'Ramesh Kumar',
          location: 'Uttar Pradesh',
          story: 'Used PM-KISAN support to buy quality seeds and fertilizers, increased crop yield by 25%',
          benefitReceived: 18000
        }
      ],
      helpline: '155261',
      email: 'pmkisan-ict@gov.in',
      website: 'pmkisan.gov.in'
    },
    {
      id: 'fasal-bima',
      name: 'Pradhan Mantri Fasal Bima Yojana',
      description: 'Crop insurance scheme providing financial support against crop loss',
      fullDescription: `Pradhan Mantri Fasal Bima Yojana (PMFBY) aims to provide insurance coverage and financial support to the farmers in the event of failure of any of the notified crop as a result of natural calamities, pests & diseases.`,
      agency: 'Ministry of Agriculture & Farmers Welfare',
      department: 'Department of Agriculture & Cooperation',
      coverage: 'All India',
      maxBenefit: 200000,
      beneficiaries: '5.5 Cr',
      successRate: 78,
      isNew: false,
      deadline: '31-07-2024',
      daysLeft: 45,
      keyFeatures: ['Crop Insurance', 'Premium Subsidy', 'Technology Use', 'Quick Settlement'],
      eligibility: {
        cropType: 'Notified Crops',
        landSize: 'All Sizes',
        income: 'No Limit',
        age: '18+ years'
      },
      eligibilityDetails: {
        basic: [
          'Must be a farmer (owner or tenant)',
          'Crop should be notified for the area',
          'Must have insurable interest in the crop',
          'Should comply with loan conditions if applicable'
        ],
        age: '18 years and above',
        income: 'No income limit',
        landSize: 'All land sizes eligible',
        cropType: 'Only notified crops for the specific area',
        exclusions: [
          'Crops not notified for the area',
          'Crops sown outside notified period',
          'Crops affected by war or nuclear risks'
        ]
      },
      documents: {
        required: [
          { name: 'Aadhaar Card', description: 'Identity proof' },
          { name: 'Bank Account Details', description: 'For premium deduction and claim settlement' },
          { name: 'Land Records', description: 'Ownership or tenancy proof' },
          { name: 'Sowing Certificate', description: 'From village revenue officer' }
        ],
        optional: [
          { name: 'Previous Insurance Policy', description: 'If renewing' },
          { name: 'Loan Sanction Letter', description: 'For loanee farmers' }
        ]
      },
      applicationProcess: [
        {
          title: 'Enrollment',
          description: 'Enroll through bank, CSC, or insurance company',
          duration: '15-30 minutes'
        },
        {
          title: 'Premium Payment',
          description: 'Pay farmer share of premium',
          duration: '5 minutes'
        },
        {
          title: 'Coverage Period',
          description: 'Crop covered from sowing to harvesting',
          duration: 'Full crop season'
        },
        {
          title: 'Loss Assessment',
          description: 'Crop cutting experiments and technology assessment',
          duration: '15-30 days'
        },
        {
          title: 'Claim Settlement',
          description: 'Insurance amount credited to bank account',
          duration: '60 days'
        }
      ],
      benefits: {
        financial: [
          {
            type: 'Crop Loss Coverage',
            amount: 200000,
            description: 'Up to sum insured amount based on crop loss'
          }
        ],
        nonFinancial: [
          {
            type: 'Risk Mitigation',
            description: 'Protection against natural calamities'
          },
          {
            type: 'Technology Integration',
            description: 'Use of drones and satellites for assessment'
          }
        ]
      },
      successStories: [
        {
          name: 'Sunita Devi',
          location: 'Maharashtra',
          story: 'Received insurance claim of ₹45,000 after crop loss due to unseasonal rains',
          benefitReceived: 45000
        }
      ],
      helpline: '14447',
      email: 'support.pmfby@gov.in',
      website: 'pmfby.gov.in'
    },
    {
      id: 'soil-health',
      name: 'Soil Health Card Scheme',
      description: 'Provides soil health cards to farmers with crop-wise recommendations',
      fullDescription: `The Soil Health Card Scheme aims to issue soil health cards to all farmers in the country. The card provides information to farmers on nutrient status of their soil along with recommendations on appropriate dosage of nutrients to be applied for improving soil health and its fertility.`,
      agency: 'Ministry of Agriculture & Farmers Welfare',
      department: 'Department of Agriculture & Cooperation',
      coverage: 'All India',
      maxBenefit: 5000,
      beneficiaries: '22 Cr',
      successRate: 85,
      isNew: false,
      deadline: 'Ongoing',
      daysLeft: 365,
      keyFeatures: ['Free Soil Testing', 'Nutrient Recommendations', 'Digital Cards', 'Crop Specific'],
      eligibility: {
        cropType: 'All Crops',
        landSize: 'All Sizes',
        income: 'No Limit',
        age: '18+ years'
      },
      eligibilityDetails: {
        basic: [
          'Must be a farmer with agricultural land',
          'Land should be used for agricultural purposes',
          'One card per 2.5 acres of land',
          'Valid land ownership or tenancy documents required'
        ],
        age: '18 years and above',
        income: 'No income limit',
        landSize: 'All land sizes, one card per 2.5 acres',
        cropType: 'All crops grown on agricultural land',
        exclusions: [
          'Non-agricultural land',
          'Land not used for farming',
          'Duplicate applications for same land'
        ]
      },
      documents: {
        required: [
          { name: 'Land Records', description: 'Khatauni, Khata number, Survey number' },
          { name: 'Aadhaar Card', description: 'Identity proof of farmer' },
          { name: 'Application Form', description: 'Filled application form' }
        ],
        optional: [
          { name: 'Mobile Number', description: 'For SMS updates' },
          { name: 'Previous Soil Health Card', description: 'If applying for renewal' }
        ]
      },
      applicationProcess: [
        {
          title: 'Application Submission',
          description: 'Submit application at nearest soil testing lab or online',
          duration: '10 minutes'
        },
        {
          title: 'Soil Sample Collection',
          description: 'Collect soil sample from the field as per guidelines',
          duration: '30 minutes'
        },
        {
          title: 'Laboratory Testing',
          description: 'Soil sample tested for various parameters',
          duration: '15-20 days'
        },
        {
          title: 'Card Generation',
          description: 'Soil health card generated with recommendations',
          duration: '5-7 days'
        },
        {
          title: 'Card Distribution',
          description: 'Card distributed to farmer through various channels',
          duration: '2-3 days'
        }
      ],
      benefits: {
        financial: [
          {
            type: 'Cost Savings',
            amount: 5000,
            description: 'Average annual savings on fertilizer costs'
          }
        ],
        nonFinancial: [
          {
            type: 'Soil Health Information',
            description: 'Detailed analysis of soil nutrient status'
          },
          {
            type: 'Fertilizer Recommendations',
            description: 'Crop-specific nutrient recommendations'
          }
        ]
      },
      successStories: [
        {
          name: 'Mohan Singh',
          location: 'Punjab',
          story: 'Reduced fertilizer costs by 30% and improved crop yield using soil health card recommendations',
          benefitReceived: 8000
        }
      ],
      helpline: '1800-180-1551',
      email: 'soilhealth.dac@nic.in',
      website: 'soilhealth.dac.gov.in'
    },
    {
      id: 'kcc',
      name: 'Kisan Credit Card',
      description: 'Credit facility for farmers to meet agricultural and allied activities',
      fullDescription: `Kisan Credit Card (KCC) scheme was introduced to provide adequate and timely credit support from the banking system under a single window to the farmers for their cultivation and other needs.`,
      agency: 'Ministry of Agriculture & Farmers Welfare',
      department: 'Department of Financial Services',
      coverage: 'All India',
      maxBenefit: 300000,
      beneficiaries: '7 Cr',
      successRate: 88,
      isNew: false,
      deadline: 'Ongoing',
      daysLeft: 365,
      keyFeatures: ['Flexible Credit', 'Low Interest', 'Multiple Use', 'Easy Renewal'],
      eligibility: {
        cropType: 'All Crops',
        landSize: 'All Sizes',
        income: 'No Limit',
        age: '18-75 years'
      },
      eligibilityDetails: {
        basic: [
          'Must be a farmer (owner cultivator)',
          'Tenant farmers, oral lessees, and sharecroppers eligible',
          'Self Help Group members engaged in farming',
          'Good credit history preferred'
        ],
        age: '18 to 75 years',
        income: 'No specific income limit',
        landSize: 'All land sizes eligible',
        cropType: 'All crops and allied activities',
        exclusions: [
          'Defaulters in previous loans',
          'Farmers with poor credit history',
          'Non-agricultural activities (unless specified)'
        ]
      },
      documents: {
        required: [
          { name: 'Application Form', description: 'Duly filled KCC application form' },
          { name: 'Identity Proof', description: 'Aadhaar card, PAN card, or voter ID' },
          { name: 'Address Proof', description: 'Utility bills, ration card' },
          { name: 'Land Documents', description: 'Land ownership or tenancy proof' }
        ],
        optional: [
          { name: 'Income Proof', description: 'For higher credit limits' },
          { name: 'Crop Insurance', description: 'Insurance policy documents' }
        ]
      },
      applicationProcess: [
        {
          title: 'Bank Visit',
          description: 'Visit nearest bank branch with required documents',
          duration: '30-45 minutes'
        },
        {
          title: 'Application Processing',
          description: 'Bank processes application and verifies documents',
          duration: '7-15 days'
        },
        {
          title: 'Credit Assessment',
          description: 'Bank assesses creditworthiness and land value',
          duration: '5-10 days'
        },
        {
          title: 'Card Issuance',
          description: 'KCC issued with approved credit limit',
          duration: '2-3 days'
        },
        {
          title: 'Credit Utilization',
          description: 'Start using credit facility for farming needs',
          duration: 'Immediate'
        }
      ],
      benefits: {
        financial: [
          {
            type: 'Credit Facility',
            amount: 300000,
            description: 'Flexible credit up to approved limit'
          }
        ],
        nonFinancial: [
          {
            type: 'Interest Subvention',
            description: 'Subsidized interest rates for timely repayment'
          },
          {
            type: 'Insurance Coverage',
            description: 'Personal accident insurance coverage'
          }
        ]
      },
      successStories: [
        {
          name: 'Ravi Patel',
          location: 'Gujarat',
          story: 'Expanded farming operations using KCC credit, doubled annual income',
          benefitReceived: 150000
        }
      ],
      helpline: '1800-180-1111',
      email: 'kcc.support@nabard.org',
      website: 'kcc.nabard.org'
    },
    {
      id: 'organic-farming',
      name: 'Paramparagat Krishi Vikas Yojana',
      description: 'Promotes organic farming through cluster-based approach',
      fullDescription: `Paramparagat Krishi Vikas Yojana (PKVY) is an elaborated component of Soil Health Management (SHM) of National Mission of Sustainable Agriculture (NMSA). The scheme promotes organic farming through cluster approach and PGS certification.`,
      agency: 'Ministry of Agriculture & Farmers Welfare',
      department: 'Department of Agriculture & Cooperation',
      coverage: 'All India',
      maxBenefit: 50000,
      beneficiaries: '8.75 Lakh',
      successRate: 82,
      isNew: true,
      deadline: '30-09-2024',
      daysLeft: 28,
      keyFeatures: ['Organic Certification', 'Cluster Approach', 'Premium Price', 'Sustainable Farming'],
      eligibility: {
        cropType: 'All Crops',
        landSize: 'Minimum 1 acre',
        income: 'No Limit',
        age: '18+ years'
      },
      eligibilityDetails: {
        basic: [
          'Must be a farmer willing to adopt organic farming',
          'Minimum 1 acre of land required',
          'Must be part of a cluster (minimum 20 farmers)',
          'Commitment to organic farming for 3 years'
        ],
        age: '18 years and above',
        income: 'No income limit',
        landSize: 'Minimum 1 acre, maximum 2 acres per farmer',
        cropType: 'All crops suitable for organic farming',
        exclusions: [
          'Farmers not willing to commit for 3 years',
          'Land with heavy chemical residue',
          'Farmers outside designated clusters'
        ]
      },
      documents: {
        required: [
          { name: 'Land Records', description: 'Proof of land ownership or tenancy' },
          { name: 'Aadhaar Card', description: 'Identity proof' },
          { name: 'Bank Account Details', description: 'For benefit transfer' },
          { name: 'Cluster Registration', description: 'Proof of cluster membership' }
        ],
        optional: [
          { name: 'Soil Test Report', description: 'Recent soil analysis report' },
          { name: 'Water Test Report', description: 'Water quality analysis' }
        ]
      },
      applicationProcess: [
        {
          title: 'Cluster Formation',
          description: 'Form or join a cluster of minimum 20 farmers',
          duration: '15-30 days'
        },
        {
          title: 'Registration',
          description: 'Register with implementing agency',
          duration: '7-10 days'
        },
        {
          title: 'Training Program',
          description: 'Attend organic farming training sessions',
          duration: '5-7 days'
        },
        {
          title: 'Conversion Period',
          description: 'Convert land to organic farming practices',
          duration: '3 years'
        },
        {
          title: 'Certification',
          description: 'Obtain PGS organic certification',
          duration: '30-45 days'
        }
      ],
      benefits: {
        financial: [
          {
            type: 'Conversion Support',
            amount: 31000,
            description: 'Financial assistance during conversion period'
          },
          {
            type: 'Certification Support',
            amount: 19000,
            description: 'Support for organic certification process'
          }
        ],
        nonFinancial: [
          {
            type: 'Organic Certification',
            description: 'PGS certification for organic produce'
          },
          {
            type: 'Market Linkage',
            description: 'Access to premium organic markets'
          }
        ]
      },
      successStories: [
        {
          name: 'Lakshmi Reddy',
          location: 'Andhra Pradesh',
          story: 'Achieved 40% premium price for organic rice, improved soil health significantly',
          benefitReceived: 75000
        }
      ],
      helpline: '1800-180-1551',
      email: 'pkvy.dac@nic.in',
      website: 'pgsindia-ncof.gov.in'
    },
    {
      id: 'micro-irrigation',
      name: 'Pradhan Mantri Krishi Sinchayee Yojana',
      description: 'Promotes efficient water use through micro-irrigation systems',
      fullDescription: `Pradhan Mantri Krishi Sinchayee Yojana (PMKSY) was formulated with the vision of extending the coverage of irrigation 'Har Khet ko Pani' and improving water use efficiency 'More Crop per Drop' in a focused manner.`,
      agency: 'Ministry of Agriculture & Farmers Welfare',
      department: 'Department of Agriculture & Cooperation',
      coverage: 'All India',
      maxBenefit: 80000,
      beneficiaries: '15 Lakh',
      successRate: 79,
      isNew: false,
      deadline: '31-12-2024',
      daysLeft: 105,
      keyFeatures: ['Water Efficiency', 'Subsidy Support', 'Technology Adoption', 'Yield Improvement'],
      eligibility: {
        cropType: 'All Crops',
        landSize: 'Minimum 0.2 hectare',
        income: 'No Limit',
        age: '18+ years'
      },
      eligibilityDetails: {
        basic: [
          'Must be a farmer with agricultural land',
          'Minimum 0.2 hectare of land required',
          'Water source should be available',
          'Must not have availed similar subsidy in last 7 years'
        ],
        age: '18 years and above',
        income: 'No income limit',
        landSize: 'Minimum 0.2 hectare, no upper limit',
        cropType: 'All crops suitable for micro-irrigation',
        exclusions: [
          'Farmers who availed subsidy in last 7 years',
          'Land without assured water source',
          'Non-agricultural land'
        ]
      },
      documents: {
        required: [
          { name: 'Land Records', description: 'Proof of land ownership' },
          { name: 'Water Source Certificate', description: 'Proof of water availability' },
          { name: 'Aadhaar Card', description: 'Identity proof' },
          { name: 'Bank Account Details', description: 'For subsidy transfer' }
        ],
        optional: [
          { name: 'Soil Test Report', description: 'For better system design' },
          { name: 'Crop Plan', description: 'Cropping pattern details' }
        ]
      },
      applicationProcess: [
        {
          title: 'Application Submission',
          description: 'Submit application to district agriculture office',
          duration: '1 day'
        },
        {
          title: 'Technical Approval',
          description: 'Technical committee approves the proposal',
          duration: '15-20 days'
        },
        {
          title: 'Vendor Selection',
          description: 'Select approved vendor for system installation',
          duration: '5-7 days'
        },
        {
          title: 'System Installation',
          description: 'Install micro-irrigation system',
          duration: '15-30 days'
        },
        {
          title: 'Subsidy Release',
          description: 'Subsidy amount released to farmer account',
          duration: '30-45 days'
        }
      ],
      benefits: {
        financial: [
          {
            type: 'Installation Subsidy',
            amount: 80000,
            description: 'Up to 55% subsidy on system cost'
          }
        ],
        nonFinancial: [
          {
            type: 'Water Savings',
            description: '40-60% reduction in water usage'
          },
          {
            type: 'Yield Increase',
            description: '20-40% increase in crop productivity'
          }
        ]
      },
      successStories: [
        {
          name: 'Kiran Patil',
          location: 'Karnataka',
          story: 'Installed drip irrigation system, saved 50% water and increased tomato yield by 35%',
          benefitReceived: 65000
        }
      ],
      helpline: '1800-180-1551',
      email: 'pmksy.dac@nic.in',
      website: 'pmksy.gov.in'
    }
  ];

  useEffect(() => {
    // Simulate API call
    const loadSchemes = async () => {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1500));
      setSchemes(mockSchemes);
      setFilteredSchemes(mockSchemes);
      setIsLoading(false);
    };

    loadSchemes();
  }, []);

  useEffect(() => {
    // Apply filters and search
    let filtered = schemes;

    // Search filter
    if (searchQuery?.trim()) {
      filtered = filtered?.filter(scheme =>
        scheme?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        scheme?.description?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        scheme?.agency?.toLowerCase()?.includes(searchQuery?.toLowerCase())
      );
    }

    // Apply other filters
    if (filters?.state !== 'all') {
      // In a real app, this would filter by state-specific schemes
    }

    if (filters?.onlyOpen) {
      filtered = filtered?.filter(scheme => scheme?.daysLeft > 0);
    }

    if (filters?.onlyNew) {
      filtered = filtered?.filter(scheme => scheme?.isNew);
    }

    if (filters?.highSuccessRate) {
      filtered = filtered?.filter(scheme => scheme?.successRate >= 80);
    }

    // Sort schemes
    switch (sortBy) {
      case 'benefit':
        filtered?.sort((a, b) => b?.maxBenefit - a?.maxBenefit);
        break;
      case 'deadline':
        filtered?.sort((a, b) => a?.daysLeft - b?.daysLeft);
        break;
      case 'success':
        filtered?.sort((a, b) => b?.successRate - a?.successRate);
        break;
      default:
        // Keep original order for relevance
        break;
    }

    setFilteredSchemes(filtered);
  }, [schemes, searchQuery, filters, sortBy]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleClearFilters = () => {
    setFilters({
      search: '',
      state: 'all',
      cropType: 'all',
      landSize: 'all',
      benefitRange: 'all',
      schemeTypes: [],
      onlyOpen: false,
      onlyNew: false,
      highSuccessRate: false,
      minAge: '',
      maxAge: '',
      maxIncome: ''
    });
    setSearchQuery('');
  };

  const handleViewDetails = (scheme) => {
    setSelectedScheme(scheme);
    setShowSchemeDetails(true);
  };

  const handleCheckEligibility = (scheme) => {
    setSelectedScheme(scheme);
    setShowEligibilityChecker(true);
  };

  const handleApply = (scheme) => {
    // In a real app, this would redirect to the application portal
    window.open(`https://www.example.com/apply/${scheme?.id}`, '_blank');
  };

  const handleSelectScheme = (scheme) => {
    setSelectedScheme(scheme);
    setShowComparisonTool(false);
    setShowSchemeDetails(true);
  };

  const quickStats = [
    {
      label: 'Total Schemes',
      value: schemes?.length,
      icon: 'FileText',
      color: 'text-primary'
    },
    {
      label: 'Active Applications',
      value: '2.5 Cr',
      icon: 'Users',
      color: 'text-success'
    },
    {
      label: 'Benefits Disbursed',
      value: '₹1.2 Lakh Cr',
      icon: 'IndianRupee',
      color: 'text-accent'
    },
    {
      label: 'Success Rate',
      value: '85%',
      icon: 'TrendingUp',
      color: 'text-warning'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/10 via-background to-accent/5 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-poppins font-bold text-foreground mb-4">
                Government Schemes Navigator
              </h1>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                Discover and apply for agricultural subsidies, loans, and support schemes. 
                Get personalized recommendations based on your farming profile.
              </p>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {quickStats?.map((stat, index) => (
                <div key={index} className="bg-card border border-border rounded-lg p-4 text-center">
                  <Icon name={stat?.icon} size={24} className={`${stat?.color} mx-auto mb-2`} />
                  <div className="text-2xl font-bold text-foreground">{stat?.value}</div>
                  <div className="text-sm text-muted-foreground">{stat?.label}</div>
                </div>
              ))}
            </div>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto">
              <div className="flex space-x-3">
                <div className="flex-1">
                  <Input
                    type="search"
                    placeholder="Search schemes by name, benefit, or agency..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e?.target?.value)}
                    className="w-full"
                  />
                </div>
                <Button
                  variant="default"
                  iconName="Search"
                  iconPosition="left"
                >
                  Search
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-8 border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                variant="outline"
                onClick={() => setShowApplicationTracker(true)}
                iconName="Search"
                iconPosition="left"
              >
                Track Application
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowComparisonTool(true)}
                iconName="GitCompare"
                iconPosition="left"
              >
                Compare Schemes
              </Button>
              <Button
                variant="outline"
                iconName="Download"
                iconPosition="left"
              >
                Download Guide
              </Button>
              <Button
                variant="outline"
                iconName="HelpCircle"
                iconPosition="left"
              >
                Get Help
              </Button>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Filters Sidebar */}
              <div className="lg:w-80 flex-shrink-0">
                <FilterPanel
                  filters={filters}
                  onFilterChange={handleFilterChange}
                  onClearFilters={handleClearFilters}
                  isCollapsed={isFilterCollapsed}
                  onToggleCollapse={() => setIsFilterCollapsed(!isFilterCollapsed)}
                />
              </div>

              {/* Schemes List */}
              <div className="flex-1">
                {/* Results Header */}
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-semibold text-foreground">
                      Available Schemes
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      {filteredSchemes?.length} schemes found
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="text-sm text-muted-foreground">Sort by:</span>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e?.target?.value)}
                      className="px-3 py-1 border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="relevance">Relevance</option>
                      <option value="benefit">Highest Benefit</option>
                      <option value="deadline">Deadline</option>
                      <option value="success">Success Rate</option>
                    </select>
                  </div>
                </div>

                {/* Loading State */}
                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[...Array(6)]?.map((_, index) => (
                      <div key={index} className="bg-card border border-border rounded-lg p-6 animate-pulse">
                        <div className="h-6 bg-muted rounded mb-4"></div>
                        <div className="h-4 bg-muted rounded mb-2"></div>
                        <div className="h-4 bg-muted rounded mb-4 w-3/4"></div>
                        <div className="flex space-x-2 mb-4">
                          <div className="h-6 bg-muted rounded w-16"></div>
                          <div className="h-6 bg-muted rounded w-20"></div>
                        </div>
                        <div className="flex space-x-2">
                          <div className="h-8 bg-muted rounded flex-1"></div>
                          <div className="h-8 bg-muted rounded flex-1"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : filteredSchemes?.length > 0 ? (
                  /* Schemes Grid */
                  (<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filteredSchemes?.map((scheme) => (
                      <SchemeCard
                        key={scheme?.id}
                        scheme={scheme}
                        onViewDetails={handleViewDetails}
                        onCheckEligibility={handleCheckEligibility}
                        onApply={handleApply}
                      />
                    ))}
                  </div>)
                ) : (
                  /* Empty State */
                  (<div className="text-center py-12">
                    <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-foreground mb-2">
                      No schemes found
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Try adjusting your search criteria or filters
                    </p>
                    <Button
                      variant="outline"
                      onClick={handleClearFilters}
                      iconName="RotateCcw"
                      iconPosition="left"
                    >
                      Clear Filters
                    </Button>
                  </div>)
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Help Section */}
        <section className="py-12 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-poppins font-bold text-foreground mb-4">
                Need Help?
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Get assistance with scheme applications, eligibility checks, and more
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-card border border-border rounded-lg p-6 text-center">
                <Icon name="Phone" size={32} className="text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">Call Helpline</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Get instant support from our experts
                </p>
                <Button variant="outline" size="sm">
                  1800-180-1551
                </Button>
              </div>

              <div className="bg-card border border-border rounded-lg p-6 text-center">
                <Icon name="MessageCircle" size={32} className="text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">Live Chat</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Chat with our support team
                </p>
                <Button variant="outline" size="sm">
                  Start Chat
                </Button>
              </div>

              <div className="bg-card border border-border rounded-lg p-6 text-center">
                <Icon name="Users" size={32} className="text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-foreground mb-2">Officer Connect</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Connect with local agricultural officers
                </p>
                <Link to="/officer-connect-portal">
                  <Button variant="outline" size="sm">
                    Connect Now
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      {/* Modals */}
      {showEligibilityChecker && selectedScheme && (
        <EligibilityChecker
          scheme={selectedScheme}
          onClose={() => {
            setShowEligibilityChecker(false);
            setSelectedScheme(null);
          }}
          onCheckEligibility={(scheme, result) => {
            console.log('Eligibility result:', result);
            setShowEligibilityChecker(false);
            if (result?.eligible) {
              handleApply(scheme);
            }
          }}
        />
      )}
      {showSchemeDetails && selectedScheme && (
        <SchemeDetails
          scheme={selectedScheme}
          onClose={() => {
            setShowSchemeDetails(false);
            setSelectedScheme(null);
          }}
          onApply={handleApply}
          onCheckEligibility={handleCheckEligibility}
        />
      )}
      {showApplicationTracker && (
        <ApplicationTracker
          onClose={() => setShowApplicationTracker(false)}
        />
      )}
      {showComparisonTool && (
        <ComparisonTool
          schemes={schemes}
          onClose={() => setShowComparisonTool(false)}
          onSelectScheme={handleSelectScheme}
        />
      )}
      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-semibold text-foreground mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link to="/homepage" className="block text-sm text-muted-foreground hover:text-primary">
                  Home
                </Link>
                <Link to="/ai-assistant-interface" className="block text-sm text-muted-foreground hover:text-primary">
                  AI Assistant
                </Link>
                <Link to="/market-intelligence-center" className="block text-sm text-muted-foreground hover:text-primary">
                  Market Intelligence
                </Link>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Support</h3>
              <div className="space-y-2">
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  Help Center
                </a>
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  Contact Us
                </a>
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  FAQ
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Resources</h3>
              <div className="space-y-2">
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  Application Guide
                </a>
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  Document Checklist
                </a>
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  Success Stories
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Connect</h3>
              <div className="space-y-2">
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  Helpline: 1800-180-1551
                </a>
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  Email Support
                </a>
                <a href="#" className="block text-sm text-muted-foreground hover:text-primary">
                  WhatsApp
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-sm text-muted-foreground">
              © {new Date()?.getFullYear()} KrishiMitra. All rights reserved. | A Digital India Initiative
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default GovernmentSchemesNavigator;