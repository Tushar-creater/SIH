import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SchemeCard = ({ scheme, onViewDetails, onCheckEligibility, onApply }) => {
  const getBenefitColor = (amount) => {
    if (amount >= 100000) return 'text-success';
    if (amount >= 50000) return 'text-accent';
    return 'text-primary';
  };

  const getUrgencyColor = (daysLeft) => {
    if (daysLeft <= 7) return 'bg-error text-error-foreground';
    if (daysLeft <= 30) return 'bg-warning text-warning-foreground';
    return 'bg-success text-success-foreground';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-all duration-300 group">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-lg font-poppins font-semibold text-foreground group-hover:text-primary transition-colors">
              {scheme?.name}
            </h3>
            {scheme?.isNew && (
              <span className="px-2 py-1 bg-accent text-accent-foreground text-xs font-medium rounded-full">
                New
              </span>
            )}
          </div>
          <p className="text-sm text-muted-foreground mb-2">{scheme?.description}</p>
          <div className="flex items-center space-x-4 text-sm">
            <span className="flex items-center space-x-1">
              <Icon name="MapPin" size={14} className="text-muted-foreground" />
              <span className="text-muted-foreground">{scheme?.coverage}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Icon name="Users" size={14} className="text-muted-foreground" />
              <span className="text-muted-foreground">{scheme?.beneficiaries} farmers</span>
            </span>
          </div>
        </div>
        <div className="text-right">
          <div className={`text-2xl font-bold ${getBenefitColor(scheme?.maxBenefit)}`}>
            ₹{(scheme?.maxBenefit / 1000)?.toFixed(0)}K
          </div>
          <div className="text-xs text-muted-foreground">Max Benefit</div>
        </div>
      </div>
      {/* Key Features */}
      <div className="mb-4">
        <div className="flex flex-wrap gap-2">
          {scheme?.keyFeatures?.map((feature, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-muted text-muted-foreground text-xs rounded-full"
            >
              {feature}
            </span>
          ))}
        </div>
      </div>
      {/* Eligibility Preview */}
      <div className="mb-4 p-3 bg-muted/50 rounded-lg">
        <h4 className="text-sm font-medium text-foreground mb-2">Quick Eligibility</h4>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center space-x-2">
            <Icon name="Crop" size={12} className="text-primary" />
            <span className="text-muted-foreground">{scheme?.eligibility?.cropType}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Ruler" size={12} className="text-primary" />
            <span className="text-muted-foreground">{scheme?.eligibility?.landSize}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="IndianRupee" size={12} className="text-primary" />
            <span className="text-muted-foreground">{scheme?.eligibility?.income}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Icon name="Calendar" size={12} className="text-primary" />
            <span className="text-muted-foreground">{scheme?.eligibility?.age}</span>
          </div>
        </div>
      </div>
      {/* Application Deadline */}
      {scheme?.deadline && (
        <div className="mb-4">
          <div className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-medium ${getUrgencyColor(scheme?.daysLeft)}`}>
            <Icon name="Clock" size={12} />
            <span>
              {scheme?.daysLeft > 0 
                ? `${scheme?.daysLeft} days left` 
                : 'Deadline passed'
              }
            </span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Deadline: {scheme?.deadline}
          </div>
        </div>
      )}
      {/* Action Buttons */}
      <div className="flex space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onViewDetails(scheme)}
          className="flex-1"
          iconName="Eye"
          iconPosition="left"
          iconSize={14}
        >
          Details
        </Button>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => onCheckEligibility(scheme)}
          className="flex-1"
          iconName="CheckCircle"
          iconPosition="left"
          iconSize={14}
        >
          Check Eligibility
        </Button>
        <Button
          variant="default"
          size="sm"
          onClick={() => onApply(scheme)}
          disabled={scheme?.daysLeft <= 0}
          iconName="ExternalLink"
          iconPosition="left"
          iconSize={14}
        >
          Apply
        </Button>
      </div>
      {/* Success Rate */}
      <div className="mt-3 pt-3 border-t border-border">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Success Rate</span>
          <span className="font-medium text-success">{scheme?.successRate}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-1 mt-1">
          <div 
            className="bg-success h-1 rounded-full transition-all duration-300"
            style={{ width: `${scheme?.successRate}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default SchemeCard;