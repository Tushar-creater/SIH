import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const ApplicationTracker = ({ onClose }) => {
  const [trackingId, setTrackingId] = useState('');
  const [applicationData, setApplicationData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Mock application data
  const mockApplications = {
    'KM2024001': {
      id: 'KM2024001',
      schemeName: 'PM-KISAN Samman Nidhi',
      applicantName: 'Rajesh Kumar',
      applicationDate: '2024-01-15',
      status: 'approved',
      currentStage: 4,
      stages: [
        {
          id: 1,
          name: 'Application Submitted',
          description: 'Your application has been successfully submitted',
          date: '2024-01-15',
          status: 'completed'
        },
        {
          id: 2,
          name: 'Document Verification',
          description: 'Documents are being verified by the concerned officer',
          date: '2024-01-18',
          status: 'completed'
        },
        {
          id: 3,
          name: 'Field Verification',
          description: 'Field officer has verified your land details',
          date: '2024-01-25',
          status: 'completed'
        },
        {
          id: 4,
          name: 'Approval',
          description: 'Your application has been approved',
          date: '2024-02-01',
          status: 'completed'
        },
        {
          id: 5,
          name: 'Benefit Disbursal',
          description: 'Benefit amount will be transferred to your account',
          date: 'Expected: 2024-02-10',
          status: 'pending'
        }
      ],
      benefitAmount: 6000,
      nextAction: 'Benefit will be credited to your registered bank account within 7 working days',
      officerContact: {
        name: 'Suresh Sharma',
        designation: 'Block Development Officer',
        phone: '+91-9876543210',
        email: 'suresh.sharma@gov.in'
      }
    },
    'KM2024002': {
      id: 'KM2024002',
      schemeName: 'Pradhan Mantri Fasal Bima Yojana',
      applicantName: 'Priya Devi',
      applicationDate: '2024-02-01',
      status: 'under_review',
      currentStage: 2,
      stages: [
        {
          id: 1,
          name: 'Application Submitted',
          description: 'Your application has been successfully submitted',
          date: '2024-02-01',
          status: 'completed'
        },
        {
          id: 2,
          name: 'Document Verification',
          description: 'Documents are being verified by the concerned officer',
          date: '2024-02-03',
          status: 'in_progress'
        },
        {
          id: 3,
          name: 'Field Verification',
          description: 'Field verification will be conducted',
          date: 'Pending',
          status: 'pending'
        },
        {
          id: 4,
          name: 'Approval',
          description: 'Final approval decision',
          date: 'Pending',
          status: 'pending'
        },
        {
          id: 5,
          name: 'Policy Issuance',
          description: 'Insurance policy will be issued',
          date: 'Pending',
          status: 'pending'
        }
      ],
      benefitAmount: 15000,
      nextAction: 'Please submit missing land revenue records. Contact officer for details.',
      officerContact: {
        name: 'Amit Verma',
        designation: 'Agriculture Extension Officer',
        phone: '+91-9876543211',
        email: 'amit.verma@gov.in'
      }
    }
  };

  const handleTrackApplication = async () => {
    if (!trackingId?.trim()) return;
    
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const application = mockApplications?.[trackingId?.toUpperCase()];
    setApplicationData(application);
    setIsLoading(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'text-success';
      case 'in_progress': return 'text-accent';
      case 'pending': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return 'CheckCircle';
      case 'in_progress': return 'Clock';
      case 'pending': return 'Circle';
      default: return 'Circle';
    }
  };

  const getApplicationStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'bg-success/10 text-success border-success';
      case 'under_review': return 'bg-accent/10 text-accent border-accent';
      case 'rejected': return 'bg-error/10 text-error border-error';
      default: return 'bg-muted/10 text-muted-foreground border-border';
    }
  };

  const getApplicationStatusText = (status) => {
    switch (status) {
      case 'approved': return 'Approved';
      case 'under_review': return 'Under Review';
      case 'rejected': return 'Rejected';
      default: return 'Unknown';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-poppins font-semibold text-foreground">
              Application Tracker
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Track your scheme application status
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        <div className="p-6">
          {/* Search Section */}
          <div className="mb-6">
            <div className="flex space-x-3">
              <div className="flex-1">
                <Input
                  label="Application ID"
                  type="text"
                  placeholder="Enter your application ID (e.g., KM2024001)"
                  value={trackingId}
                  onChange={(e) => setTrackingId(e?.target?.value)}
                  description="You can find your application ID in the confirmation SMS/email"
                />
              </div>
              <div className="flex items-end">
                <Button
                  variant="default"
                  onClick={handleTrackApplication}
                  loading={isLoading}
                  iconName="Search"
                  iconPosition="left"
                >
                  Track
                </Button>
              </div>
            </div>
          </div>

          {/* Sample IDs */}
          <div className="mb-6 p-4 bg-muted/50 rounded-lg">
            <h4 className="font-medium text-foreground mb-2">Sample Application IDs for Testing</h4>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setTrackingId('KM2024001')}
                className="px-3 py-1 bg-primary/10 text-primary text-sm rounded hover:bg-primary/20 transition-colors"
              >
                KM2024001 (Approved)
              </button>
              <button
                onClick={() => setTrackingId('KM2024002')}
                className="px-3 py-1 bg-accent/10 text-accent text-sm rounded hover:bg-accent/20 transition-colors"
              >
                KM2024002 (Under Review)
              </button>
            </div>
          </div>

          {/* Application Details */}
          {applicationData ? (
            <div className="space-y-6">
              {/* Application Summary */}
              <div className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">
                      {applicationData?.schemeName}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Application ID: {applicationData?.id}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Applicant: {applicationData?.applicantName}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getApplicationStatusColor(applicationData?.status)}`}>
                      {getApplicationStatusText(applicationData?.status)}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Applied: {applicationData?.applicationDate}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-sm text-muted-foreground">Benefit Amount</div>
                    <div className="text-xl font-bold text-primary">
                      ₹{applicationData?.benefitAmount?.toLocaleString()}
                    </div>
                  </div>
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <div className="text-sm text-muted-foreground">Current Stage</div>
                    <div className="text-lg font-semibold text-foreground">
                      {applicationData?.stages?.[applicationData?.currentStage - 1]?.name}
                    </div>
                  </div>
                </div>
              </div>

              {/* Progress Timeline */}
              <div className="bg-card border border-border rounded-lg p-6">
                <h4 className="font-semibold text-foreground mb-4">Application Progress</h4>
                <div className="space-y-4">
                  {applicationData?.stages?.map((stage, index) => (
                    <div key={stage?.id} className="flex items-start space-x-4">
                      <div className="flex flex-col items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          stage?.status === 'completed' 
                            ? 'bg-success text-success-foreground' 
                            : stage?.status === 'in_progress' ?'bg-accent text-accent-foreground' :'bg-muted text-muted-foreground'
                        }`}>
                          <Icon 
                            name={getStatusIcon(stage?.status)} 
                            size={16}
                          />
                        </div>
                        {index < applicationData?.stages?.length - 1 && (
                          <div className={`w-0.5 h-8 mt-2 ${
                            stage?.status === 'completed' ? 'bg-success' : 'bg-muted'
                          }`}></div>
                        )}
                      </div>
                      <div className="flex-1 pb-4">
                        <div className="flex items-center justify-between mb-1">
                          <h5 className={`font-medium ${getStatusColor(stage?.status)}`}>
                            {stage?.name}
                          </h5>
                          <span className="text-sm text-muted-foreground">
                            {stage?.date}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {stage?.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Next Action */}
              <div className="bg-accent/10 border border-accent rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <Icon name="Info" size={16} className="text-accent mt-1" />
                  <div>
                    <h4 className="font-medium text-foreground mb-1">Next Action Required</h4>
                    <p className="text-sm text-muted-foreground">
                      {applicationData?.nextAction}
                    </p>
                  </div>
                </div>
              </div>

              {/* Officer Contact */}
              <div className="bg-card border border-border rounded-lg p-6">
                <h4 className="font-semibold text-foreground mb-4">Contact Officer</h4>
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <Icon name="User" size={20} className="text-primary" />
                  </div>
                  <div className="flex-1">
                    <h5 className="font-medium text-foreground">
                      {applicationData?.officerContact?.name}
                    </h5>
                    <p className="text-sm text-muted-foreground mb-2">
                      {applicationData?.officerContact?.designation}
                    </p>
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2 text-sm">
                        <Icon name="Phone" size={14} className="text-primary" />
                        <span className="text-muted-foreground">
                          {applicationData?.officerContact?.phone}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Icon name="Mail" size={14} className="text-primary" />
                        <span className="text-muted-foreground">
                          {applicationData?.officerContact?.email}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Phone"
                      iconPosition="left"
                    >
                      Call
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Mail"
                      iconPosition="left"
                    >
                      Email
                    </Button>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  iconName="Download"
                  iconPosition="left"
                >
                  Download Status Report
                </Button>
                <Button
                  variant="outline"
                  iconName="Bell"
                  iconPosition="left"
                >
                  Enable SMS Updates
                </Button>
                <Button
                  variant="default"
                  iconName="MessageCircle"
                  iconPosition="left"
                >
                  Contact Support
                </Button>
              </div>
            </div>
          ) : trackingId && !isLoading ? (
            <div className="text-center py-8">
              <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                Application Not Found
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                No application found with ID: {trackingId}
              </p>
              <p className="text-sm text-muted-foreground">
                Please check your application ID and try again, or contact support for assistance.
              </p>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default ApplicationTracker;