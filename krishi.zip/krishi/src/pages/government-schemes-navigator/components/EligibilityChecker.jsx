import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const EligibilityChecker = ({ scheme, onClose, onCheckEligibility }) => {
  const [formData, setFormData] = useState({
    age: '',
    state: '',
    cropType: '',
    landSize: '',
    annualIncome: '',
    hasAadhar: false,
    hasBankAccount: false,
    hasLandDocuments: false,
    isFirstTime: false,
    caste: '',
    gender: ''
  });

  const [result, setResult] = useState(null);
  const [isChecking, setIsChecking] = useState(false);

  const stateOptions = [
    { value: '', label: 'Select State' },
    { value: 'maharashtra', label: 'Maharashtra' },
    { value: 'punjab', label: 'Punjab' },
    { value: 'haryana', label: 'Haryana' },
    { value: 'uttar-pradesh', label: 'Uttar Pradesh' },
    { value: 'madhya-pradesh', label: 'Madhya Pradesh' },
    { value: 'rajasthan', label: 'Rajasthan' },
    { value: 'gujarat', label: 'Gujarat' },
    { value: 'karnataka', label: 'Karnataka' }
  ];

  const cropOptions = [
    { value: '', label: 'Select Primary Crop' },
    { value: 'rice', label: 'Rice' },
    { value: 'wheat', label: 'Wheat' },
    { value: 'sugarcane', label: 'Sugarcane' },
    { value: 'cotton', label: 'Cotton' },
    { value: 'maize', label: 'Maize' },
    { value: 'pulses', label: 'Pulses' },
    { value: 'oilseeds', label: 'Oilseeds' },
    { value: 'vegetables', label: 'Vegetables' },
    { value: 'fruits', label: 'Fruits' }
  ];

  const landSizeOptions = [
    { value: '', label: 'Select Land Size' },
    { value: 'marginal', label: 'Marginal (< 1 hectare)' },
    { value: 'small', label: 'Small (1-2 hectares)' },
    { value: 'semi-medium', label: 'Semi-Medium (2-4 hectares)' },
    { value: 'medium', label: 'Medium (4-10 hectares)' },
    { value: 'large', label: 'Large (> 10 hectares)' }
  ];

  const casteOptions = [
    { value: '', label: 'Select Category' },
    { value: 'general', label: 'General' },
    { value: 'obc', label: 'OBC' },
    { value: 'sc', label: 'SC' },
    { value: 'st', label: 'ST' }
  ];

  const genderOptions = [
    { value: '', label: 'Select Gender' },
    { value: 'male', label: 'Male' },
    { value: 'female', label: 'Female' },
    { value: 'other', label: 'Other' }
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCheckEligibility = async () => {
    setIsChecking(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock eligibility logic
    const eligible = checkEligibilityLogic();
    setResult(eligible);
    setIsChecking(false);
  };

  const checkEligibilityLogic = () => {
    const issues = [];
    const requirements = [];

    // Age check
    if (formData?.age && (parseInt(formData?.age) < 18 || parseInt(formData?.age) > 60)) {
      issues?.push("Age must be between 18-60 years");
    }

    // Income check
    if (formData?.annualIncome && parseInt(formData?.annualIncome) > 200000) {
      issues?.push("Annual income exceeds the limit of ₹2,00,000");
    }

    // Document requirements
    if (!formData?.hasAadhar) {
      requirements?.push("Aadhar Card is mandatory");
    }
    if (!formData?.hasBankAccount) {
      requirements?.push("Bank Account is required for benefit transfer");
    }
    if (!formData?.hasLandDocuments) {
      requirements?.push("Land ownership documents are required");
    }

    const isEligible = issues?.length === 0 && requirements?.length === 0;
    const estimatedBenefit = isEligible ? Math.floor(Math.random() * 50000) + 25000 : 0;

    return {
      eligible: isEligible,
      issues,
      requirements,
      estimatedBenefit,
      confidence: isEligible ? 95 : 0,
      nextSteps: isEligible ? [
        "Gather required documents",
        "Visit nearest Common Service Center",
        "Submit online application",
        "Track application status"
      ] : [
        "Address eligibility issues",
        "Consult with agricultural officer",
        "Check alternative schemes"
      ]
    };
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-poppins font-semibold text-foreground">
              Eligibility Checker
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              {scheme?.name}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Form */}
        <div className="p-6">
          {!result ? (
            <div className="space-y-6">
              {/* Personal Information */}
              <div>
                <h3 className="text-lg font-medium text-foreground mb-4">
                  Personal Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Age"
                    type="number"
                    placeholder="Enter your age"
                    value={formData?.age}
                    onChange={(e) => handleInputChange('age', e?.target?.value)}
                    required
                  />
                  <Select
                    label="Gender"
                    options={genderOptions}
                    value={formData?.gender}
                    onChange={(value) => handleInputChange('gender', value)}
                    required
                  />
                  <Select
                    label="State"
                    options={stateOptions}
                    value={formData?.state}
                    onChange={(value) => handleInputChange('state', value)}
                    required
                  />
                  <Select
                    label="Category"
                    options={casteOptions}
                    value={formData?.caste}
                    onChange={(value) => handleInputChange('caste', value)}
                    required
                  />
                </div>
              </div>

              {/* Farming Information */}
              <div>
                <h3 className="text-lg font-medium text-foreground mb-4">
                  Farming Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select
                    label="Primary Crop"
                    options={cropOptions}
                    value={formData?.cropType}
                    onChange={(value) => handleInputChange('cropType', value)}
                    required
                  />
                  <Select
                    label="Land Size"
                    options={landSizeOptions}
                    value={formData?.landSize}
                    onChange={(value) => handleInputChange('landSize', value)}
                    required
                  />
                  <Input
                    label="Annual Income (₹)"
                    type="number"
                    placeholder="Enter annual income"
                    value={formData?.annualIncome}
                    onChange={(e) => handleInputChange('annualIncome', e?.target?.value)}
                    required
                  />
                </div>
              </div>

              {/* Document Checklist */}
              <div>
                <h3 className="text-lg font-medium text-foreground mb-4">
                  Document Checklist
                </h3>
                <div className="space-y-3">
                  <Checkbox
                    label="I have Aadhar Card"
                    checked={formData?.hasAadhar}
                    onChange={(e) => handleInputChange('hasAadhar', e?.target?.checked)}
                  />
                  <Checkbox
                    label="I have Bank Account"
                    checked={formData?.hasBankAccount}
                    onChange={(e) => handleInputChange('hasBankAccount', e?.target?.checked)}
                  />
                  <Checkbox
                    label="I have Land Ownership Documents"
                    checked={formData?.hasLandDocuments}
                    onChange={(e) => handleInputChange('hasLandDocuments', e?.target?.checked)}
                  />
                  <Checkbox
                    label="This is my first time applying for this scheme"
                    checked={formData?.isFirstTime}
                    onChange={(e) => handleInputChange('isFirstTime', e?.target?.checked)}
                  />
                </div>
              </div>

              {/* Check Button */}
              <Button
                variant="default"
                fullWidth
                onClick={handleCheckEligibility}
                loading={isChecking}
                iconName="CheckCircle"
                iconPosition="left"
              >
                {isChecking ? 'Checking Eligibility...' : 'Check Eligibility'}
              </Button>
            </div>
          ) : (
            /* Results */
            (<div className="space-y-6">
              {/* Result Header */}
              <div className={`p-4 rounded-lg border-2 ${
                result?.eligible 
                  ? 'bg-success/10 border-success text-success-foreground' 
                  : 'bg-error/10 border-error text-error-foreground'
              }`}>
                <div className="flex items-center space-x-3">
                  <Icon 
                    name={result?.eligible ? "CheckCircle" : "XCircle"} 
                    size={24}
                    className={result?.eligible ? 'text-success' : 'text-error'}
                  />
                  <div>
                    <h3 className="text-lg font-semibold">
                      {result?.eligible ? 'You are Eligible!' : 'Not Eligible'}
                    </h3>
                    <p className="text-sm opacity-80">
                      Confidence: {result?.confidence}%
                    </p>
                  </div>
                </div>
              </div>
              {/* Estimated Benefit */}
              {result?.eligible && (
                <div className="p-4 bg-accent/10 rounded-lg border border-accent">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">Estimated Benefit</h4>
                      <p className="text-sm text-muted-foreground">Based on your profile</p>
                    </div>
                    <div className="text-2xl font-bold text-accent">
                      ₹{result?.estimatedBenefit?.toLocaleString()}
                    </div>
                  </div>
                </div>
              )}
              {/* Issues */}
              {result?.issues?.length > 0 && (
                <div>
                  <h4 className="font-medium text-error mb-3">Issues Found</h4>
                  <div className="space-y-2">
                    {result?.issues?.map((issue, index) => (
                      <div key={index} className="flex items-start space-x-2 text-sm">
                        <Icon name="AlertTriangle" size={16} className="text-error mt-0.5" />
                        <span className="text-muted-foreground">{issue}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {/* Requirements */}
              {result?.requirements?.length > 0 && (
                <div>
                  <h4 className="font-medium text-warning mb-3">Missing Requirements</h4>
                  <div className="space-y-2">
                    {result?.requirements?.map((requirement, index) => (
                      <div key={index} className="flex items-start space-x-2 text-sm">
                        <Icon name="AlertCircle" size={16} className="text-warning mt-0.5" />
                        <span className="text-muted-foreground">{requirement}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {/* Next Steps */}
              <div>
                <h4 className="font-medium text-foreground mb-3">Next Steps</h4>
                <div className="space-y-2">
                  {result?.nextSteps?.map((step, index) => (
                    <div key={index} className="flex items-start space-x-2 text-sm">
                      <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-medium mt-0.5">
                        {index + 1}
                      </div>
                      <span className="text-muted-foreground">{step}</span>
                    </div>
                  ))}
                </div>
              </div>
              {/* Action Buttons */}
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setResult(null)}
                  iconName="ArrowLeft"
                  iconPosition="left"
                >
                  Check Again
                </Button>
                {result?.eligible && (
                  <Button
                    variant="default"
                    onClick={() => onCheckEligibility(scheme, result)}
                    iconName="ExternalLink"
                    iconPosition="left"
                  >
                    Proceed to Apply
                  </Button>
                )}
              </div>
            </div>)
          )}
        </div>
      </div>
    </div>
  );
};

export default EligibilityChecker;