import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SchemeDetails = ({ scheme, onClose, onApply, onCheckEligibility }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'Info' },
    { id: 'eligibility', label: 'Eligibility', icon: 'CheckCircle' },
    { id: 'documents', label: 'Documents', icon: 'FileText' },
    { id: 'process', label: 'Process', icon: 'GitBranch' },
    { id: 'benefits', label: 'Benefits', icon: 'Gift' }
  ];

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Scheme Summary */}
      <div className="bg-muted/50 p-4 rounded-lg">
        <h3 className="font-medium text-foreground mb-2">Scheme Summary</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {scheme?.fullDescription}
        </p>
      </div>

      {/* Key Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center p-4 bg-primary/10 rounded-lg">
          <div className="text-2xl font-bold text-primary">₹{(scheme?.maxBenefit / 1000)?.toFixed(0)}K</div>
          <div className="text-xs text-muted-foreground">Max Benefit</div>
        </div>
        <div className="text-center p-4 bg-success/10 rounded-lg">
          <div className="text-2xl font-bold text-success">{scheme?.successRate}%</div>
          <div className="text-xs text-muted-foreground">Success Rate</div>
        </div>
        <div className="text-center p-4 bg-accent/10 rounded-lg">
          <div className="text-2xl font-bold text-accent">{scheme?.beneficiaries}</div>
          <div className="text-xs text-muted-foreground">Beneficiaries</div>
        </div>
        <div className="text-center p-4 bg-warning/10 rounded-lg">
          <div className="text-2xl font-bold text-warning">{scheme?.daysLeft}</div>
          <div className="text-xs text-muted-foreground">Days Left</div>
        </div>
      </div>

      {/* Implementing Agency */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Implementing Agency</h3>
        <div className="flex items-center space-x-3 p-3 bg-card border border-border rounded-lg">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Building" size={24} className="text-primary" />
          </div>
          <div>
            <div className="font-medium text-foreground">{scheme?.agency}</div>
            <div className="text-sm text-muted-foreground">{scheme?.department}</div>
          </div>
        </div>
      </div>

      {/* Contact Information */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Contact Information</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Phone" size={16} className="text-primary" />
            <span className="text-muted-foreground">Helpline: {scheme?.helpline}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Mail" size={16} className="text-primary" />
            <span className="text-muted-foreground">Email: {scheme?.email}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Globe" size={16} className="text-primary" />
            <span className="text-muted-foreground">Website: {scheme?.website}</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderEligibility = () => (
    <div className="space-y-6">
      {/* Basic Eligibility */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Basic Eligibility Criteria</h3>
        <div className="space-y-3">
          {scheme?.eligibilityDetails?.basic?.map((criteria, index) => (
            <div key={index} className="flex items-start space-x-2">
              <Icon name="Check" size={16} className="text-success mt-1" />
              <span className="text-sm text-muted-foreground">{criteria}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Specific Requirements */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Specific Requirements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="User" size={16} className="text-primary" />
              <span className="font-medium text-sm">Age Limit</span>
            </div>
            <span className="text-sm text-muted-foreground">{scheme?.eligibilityDetails?.age}</span>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="IndianRupee" size={16} className="text-primary" />
              <span className="font-medium text-sm">Income Limit</span>
            </div>
            <span className="text-sm text-muted-foreground">{scheme?.eligibilityDetails?.income}</span>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Ruler" size={16} className="text-primary" />
              <span className="font-medium text-sm">Land Size</span>
            </div>
            <span className="text-sm text-muted-foreground">{scheme?.eligibilityDetails?.landSize}</span>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Crop" size={16} className="text-primary" />
              <span className="font-medium text-sm">Crop Type</span>
            </div>
            <span className="text-sm text-muted-foreground">{scheme?.eligibilityDetails?.cropType}</span>
          </div>
        </div>
      </div>

      {/* Exclusions */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Exclusions</h3>
        <div className="space-y-2">
          {scheme?.eligibilityDetails?.exclusions?.map((exclusion, index) => (
            <div key={index} className="flex items-start space-x-2">
              <Icon name="X" size={16} className="text-error mt-1" />
              <span className="text-sm text-muted-foreground">{exclusion}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderDocuments = () => (
    <div className="space-y-6">
      {/* Required Documents */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Required Documents</h3>
        <div className="space-y-3">
          {scheme?.documents?.required?.map((doc, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Icon name="FileText" size={16} className="text-primary" />
                <span className="text-sm font-medium text-foreground">{doc?.name}</span>
              </div>
              <span className="text-xs text-error font-medium">Required</span>
            </div>
          ))}
        </div>
      </div>

      {/* Optional Documents */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Optional Documents</h3>
        <div className="space-y-3">
          {scheme?.documents?.optional?.map((doc, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Icon name="FileText" size={16} className="text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">{doc?.name}</span>
              </div>
              <span className="text-xs text-muted-foreground font-medium">Optional</span>
            </div>
          ))}
        </div>
      </div>

      {/* Document Tips */}
      <div className="p-4 bg-accent/10 border border-accent rounded-lg">
        <div className="flex items-start space-x-2">
          <Icon name="Lightbulb" size={16} className="text-accent mt-1" />
          <div>
            <h4 className="font-medium text-foreground mb-2">Document Tips</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Ensure all documents are self-attested</li>
              <li>• Keep both original and photocopies ready</li>
              <li>• Documents should be clear and readable</li>
              <li>• Check validity dates before submission</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderProcess = () => (
    <div className="space-y-6">
      {/* Application Steps */}
      <div>
        <h3 className="font-medium text-foreground mb-4">Application Process</h3>
        <div className="space-y-4">
          {scheme?.applicationProcess?.map((step, index) => (
            <div key={index} className="flex items-start space-x-4">
              <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0">
                {index + 1}
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-foreground mb-1">{step?.title}</h4>
                <p className="text-sm text-muted-foreground mb-2">{step?.description}</p>
                {step?.duration && (
                  <span className="text-xs text-accent bg-accent/10 px-2 py-1 rounded">
                    {step?.duration}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div className="p-4 bg-muted/50 rounded-lg">
        <h4 className="font-medium text-foreground mb-3">Expected Timeline</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-bold text-primary">7-15 days</div>
            <div className="text-xs text-muted-foreground">Application Review</div>
          </div>
          <div>
            <div className="text-lg font-bold text-accent">15-30 days</div>
            <div className="text-xs text-muted-foreground">Verification</div>
          </div>
          <div>
            <div className="text-lg font-bold text-success">30-45 days</div>
            <div className="text-xs text-muted-foreground">Benefit Disbursal</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderBenefits = () => (
    <div className="space-y-6">
      {/* Financial Benefits */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Financial Benefits</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {scheme?.benefits?.financial?.map((benefit, index) => (
            <div key={index} className="p-4 bg-success/10 border border-success rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-foreground">{benefit?.type}</span>
                <span className="text-lg font-bold text-success">₹{benefit?.amount?.toLocaleString()}</span>
              </div>
              <p className="text-sm text-muted-foreground">{benefit?.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Non-Financial Benefits */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Additional Benefits</h3>
        <div className="space-y-3">
          {scheme?.benefits?.nonFinancial?.map((benefit, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg">
              <Icon name="Gift" size={16} className="text-primary mt-1" />
              <div>
                <div className="font-medium text-foreground">{benefit?.type}</div>
                <div className="text-sm text-muted-foreground">{benefit?.description}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Success Stories */}
      <div>
        <h3 className="font-medium text-foreground mb-3">Success Stories</h3>
        <div className="space-y-4">
          {scheme?.successStories?.map((story, index) => (
            <div key={index} className="p-4 bg-card border border-border rounded-lg">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} className="text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-foreground">{story?.name}</span>
                    <span className="text-sm text-muted-foreground">{story?.location}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{story?.story}</p>
                  <div className="text-sm font-medium text-success">
                    Benefit Received: ₹{story?.benefitReceived?.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview': return renderOverview();
      case 'eligibility': return renderEligibility();
      case 'documents': return renderDocuments();
      case 'process': return renderProcess();
      case 'benefits': return renderBenefits();
      default: return renderOverview();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-poppins font-semibold text-foreground">
              {scheme?.name}
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              {scheme?.agency} • {scheme?.coverage}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        {/* Tabs */}
        <div className="border-b border-border">
          <div className="flex overflow-x-auto">
            {tabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors ${
                  activeTab === tab?.id
                    ? 'text-primary border-b-2 border-primary bg-primary/5' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon name={tab?.icon} size={16} />
                <span>{tab?.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {renderTabContent()}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between p-6 border-t border-border bg-muted/20">
          <div className="flex items-center space-x-4">
            <div className="text-sm text-muted-foreground">
              Deadline: <span className="font-medium text-foreground">{scheme?.deadline}</span>
            </div>
            <div className="text-sm text-muted-foreground">
              Days Left: <span className="font-medium text-warning">{scheme?.daysLeft}</span>
            </div>
          </div>
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={() => onCheckEligibility(scheme)}
              iconName="CheckCircle"
              iconPosition="left"
            >
              Check Eligibility
            </Button>
            <Button
              variant="default"
              onClick={() => onApply(scheme)}
              disabled={scheme?.daysLeft <= 0}
              iconName="ExternalLink"
              iconPosition="left"
            >
              Apply Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SchemeDetails;