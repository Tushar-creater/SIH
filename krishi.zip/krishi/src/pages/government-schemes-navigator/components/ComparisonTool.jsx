import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ComparisonTool = ({ schemes, onClose, onSelectScheme }) => {
  const [selectedSchemes, setSelectedSchemes] = useState([]);

  const handleSchemeToggle = (scheme) => {
    setSelectedSchemes(prev => {
      const isSelected = prev?.find(s => s?.id === scheme?.id);
      if (isSelected) {
        return prev?.filter(s => s?.id !== scheme?.id);
      } else if (prev?.length < 3) {
        return [...prev, scheme];
      }
      return prev;
    });
  };

  const comparisonCriteria = [
    { key: 'maxBenefit', label: 'Maximum Benefit', format: (value) => `₹${(value / 1000)?.toFixed(0)}K` },
    { key: 'eligibility.age', label: 'Age Requirement', format: (value) => value },
    { key: 'eligibility.landSize', label: 'Land Size', format: (value) => value },
    { key: 'eligibility.income', label: 'Income Limit', format: (value) => value },
    { key: 'successRate', label: 'Success Rate', format: (value) => `${value}%` },
    { key: 'daysLeft', label: 'Days Left', format: (value) => `${value} days` },
    { key: 'coverage', label: 'Coverage', format: (value) => value },
    { key: 'agency', label: 'Implementing Agency', format: (value) => value }
  ];

  const getNestedValue = (obj, path) => {
    return path?.split('.')?.reduce((current, key) => current?.[key], obj);
  };

  const getBestValue = (criteria, schemes) => {
    const values = schemes?.map(scheme => {
      const value = getNestedValue(scheme, criteria?.key);
      if (criteria?.key === 'maxBenefit' || criteria?.key === 'successRate') {
        return typeof value === 'number' ? value : 0;
      }
      return value;
    });

    if (criteria?.key === 'maxBenefit' || criteria?.key === 'successRate') {
      return Math.max(...values);
    }
    return null;
  };

  const isHighlighted = (criteria, scheme, bestValue) => {
    if (bestValue === null) return false;
    const value = getNestedValue(scheme, criteria?.key);
    return value === bestValue;
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-xl font-poppins font-semibold text-foreground">
              Scheme Comparison Tool
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Compare up to 3 schemes side by side
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
          >
            <Icon name="X" size={20} />
          </Button>
        </div>

        <div className="p-6">
          {/* Scheme Selection */}
          <div className="mb-6">
            <h3 className="font-medium text-foreground mb-4">
              Select Schemes to Compare ({selectedSchemes?.length}/3)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {schemes?.slice(0, 6)?.map((scheme) => {
                const isSelected = selectedSchemes?.find(s => s?.id === scheme?.id);
                return (
                  <div
                    key={scheme?.id}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      isSelected
                        ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                    }`}
                    onClick={() => handleSchemeToggle(scheme)}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-foreground text-sm">
                        {scheme?.name}
                      </h4>
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                        isSelected
                          ? 'border-primary bg-primary' :'border-muted-foreground'
                      }`}>
                        {isSelected && (
                          <Icon name="Check" size={12} color="white" />
                        )}
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mb-2">
                      {scheme?.agency}
                    </div>
                    <div className="text-lg font-bold text-primary">
                      ₹{(scheme?.maxBenefit / 1000)?.toFixed(0)}K
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Comparison Table */}
          {selectedSchemes?.length > 0 && (
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="text-left p-4 font-medium text-foreground">
                        Criteria
                      </th>
                      {selectedSchemes?.map((scheme) => (
                        <th key={scheme?.id} className="text-left p-4 font-medium text-foreground min-w-48">
                          <div className="space-y-1">
                            <div className="font-semibold">{scheme?.name}</div>
                            <div className="text-xs text-muted-foreground font-normal">
                              {scheme?.agency}
                            </div>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonCriteria?.map((criteria, index) => {
                      const bestValue = getBestValue(criteria, selectedSchemes);
                      return (
                        <tr key={criteria?.key} className={index % 2 === 0 ? 'bg-muted/20' : ''}>
                          <td className="p-4 font-medium text-foreground">
                            {criteria?.label}
                          </td>
                          {selectedSchemes?.map((scheme) => {
                            const value = getNestedValue(scheme, criteria?.key);
                            const highlighted = isHighlighted(criteria, scheme, bestValue);
                            return (
                              <td key={scheme?.id} className="p-4">
                                <span className={`${
                                  highlighted 
                                    ? 'font-semibold text-success bg-success/10 px-2 py-1 rounded' :'text-muted-foreground'
                                }`}>
                                  {criteria?.format(value)}
                                  {highlighted && (
                                    <Icon name="Crown" size={14} className="inline ml-1 text-success" />
                                  )}
                                </span>
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Key Features Comparison */}
          {selectedSchemes?.length > 0 && (
            <div className="mt-6">
              <h3 className="font-medium text-foreground mb-4">Key Features</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {selectedSchemes?.map((scheme) => (
                  <div key={scheme?.id} className="bg-card border border-border rounded-lg p-4">
                    <h4 className="font-medium text-foreground mb-3">{scheme?.name}</h4>
                    <div className="space-y-2">
                      {scheme?.keyFeatures?.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Icon name="Check" size={14} className="text-success" />
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recommendation */}
          {selectedSchemes?.length > 1 && (
            <div className="mt-6 p-4 bg-primary/10 border border-primary rounded-lg">
              <div className="flex items-start space-x-2">
                <Icon name="Lightbulb" size={16} className="text-primary mt-1" />
                <div>
                  <h4 className="font-medium text-foreground mb-2">Recommendation</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Based on the comparison, here's our recommendation for your situation:
                  </p>
                  <div className="space-y-2">
                    <div className="text-sm">
                      <span className="font-medium text-foreground">Best Overall Value:</span>
                      <span className="text-muted-foreground ml-2">
                        {selectedSchemes?.reduce((best, current) => 
                          current?.maxBenefit > best?.maxBenefit ? current : best
                        )?.name}
                      </span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium text-foreground">Highest Success Rate:</span>
                      <span className="text-muted-foreground ml-2">
                        {selectedSchemes?.reduce((best, current) => 
                          current?.successRate > best?.successRate ? current : best
                        )?.name}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          {selectedSchemes?.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-3">
              {selectedSchemes?.map((scheme) => (
                <Button
                  key={scheme?.id}
                  variant="outline"
                  onClick={() => onSelectScheme(scheme)}
                  iconName="ExternalLink"
                  iconPosition="left"
                >
                  Apply to {scheme?.name}
                </Button>
              ))}
            </div>
          )}

          {/* Empty State */}
          {selectedSchemes?.length === 0 && (
            <div className="text-center py-8">
              <Icon name="GitCompare" size={48} className="text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                Select Schemes to Compare
              </h3>
              <p className="text-sm text-muted-foreground">
                Choose up to 3 schemes from the list above to see a detailed comparison
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ComparisonTool;