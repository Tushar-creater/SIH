import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const FilterPanel = ({ 
  filters, 
  onFilterChange, 
  onClearFilters, 
  isCollapsed, 
  onToggleCollapse 
}) => {
  const stateOptions = [
    { value: 'all', label: 'All States' },
    { value: 'maharashtra', label: 'Maharashtra' },
    { value: 'punjab', label: 'Punjab' },
    { value: 'haryana', label: 'Haryana' },
    { value: 'uttar-pradesh', label: 'Uttar Pradesh' },
    { value: 'madhya-pradesh', label: 'Madhya Pradesh' },
    { value: 'rajasthan', label: 'Rajasthan' },
    { value: 'gujarat', label: 'Gujarat' },
    { value: 'karnataka', label: 'Karnataka' },
    { value: 'andhra-pradesh', label: 'Andhra Pradesh' },
    { value: 'telangana', label: 'Telangana' }
  ];

  const cropOptions = [
    { value: 'all', label: 'All Crops' },
    { value: 'rice', label: 'Rice' },
    { value: 'wheat', label: 'Wheat' },
    { value: 'sugarcane', label: 'Sugarcane' },
    { value: 'cotton', label: 'Cotton' },
    { value: 'maize', label: 'Maize' },
    { value: 'pulses', label: 'Pulses' },
    { value: 'oilseeds', label: 'Oilseeds' },
    { value: 'vegetables', label: 'Vegetables' },
    { value: 'fruits', label: 'Fruits' },
    { value: 'spices', label: 'Spices' }
  ];

  const landSizeOptions = [
    { value: 'all', label: 'All Land Sizes' },
    { value: 'marginal', label: 'Marginal (< 1 hectare)' },
    { value: 'small', label: 'Small (1-2 hectares)' },
    { value: 'semi-medium', label: 'Semi-Medium (2-4 hectares)' },
    { value: 'medium', label: 'Medium (4-10 hectares)' },
    { value: 'large', label: 'Large (> 10 hectares)' }
  ];

  const benefitRangeOptions = [
    { value: 'all', label: 'All Amounts' },
    { value: '0-25000', label: 'Up to ₹25,000' },
    { value: '25000-50000', label: '₹25,000 - ₹50,000' },
    { value: '50000-100000', label: '₹50,000 - ₹1,00,000' },
    { value: '100000-500000', label: '₹1,00,000 - ₹5,00,000' },
    { value: '500000+', label: 'Above ₹5,00,000' }
  ];

  const schemeTypeOptions = [
    { value: 'subsidy', label: 'Subsidies' },
    { value: 'loan', label: 'Loans' },
    { value: 'insurance', label: 'Insurance' },
    { value: 'training', label: 'Training' },
    { value: 'equipment', label: 'Equipment' },
    { value: 'seeds', label: 'Seeds & Fertilizers' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Filter Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-primary" />
          <h3 className="font-poppins font-semibold text-foreground">Filter Schemes</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearFilters}
            iconName="X"
            iconPosition="left"
            iconSize={14}
          >
            Clear All
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="lg:hidden"
          >
            <Icon name={isCollapsed ? "ChevronDown" : "ChevronUp"} size={16} />
          </Button>
        </div>
      </div>
      {/* Filter Content */}
      <div className={`transition-all duration-300 ${isCollapsed ? 'hidden lg:block' : 'block'}`}>
        <div className="p-4 space-y-6">
          {/* Search */}
          <div>
            <Input
              label="Search Schemes"
              type="search"
              placeholder="Search by scheme name or keyword..."
              value={filters?.search}
              onChange={(e) => onFilterChange('search', e?.target?.value)}
              className="w-full"
            />
          </div>

          {/* State Selection */}
          <div>
            <Select
              label="State/Region"
              options={stateOptions}
              value={filters?.state}
              onChange={(value) => onFilterChange('state', value)}
              searchable
            />
          </div>

          {/* Crop Type */}
          <div>
            <Select
              label="Crop Type"
              options={cropOptions}
              value={filters?.cropType}
              onChange={(value) => onFilterChange('cropType', value)}
              searchable
            />
          </div>

          {/* Land Size */}
          <div>
            <Select
              label="Land Size"
              options={landSizeOptions}
              value={filters?.landSize}
              onChange={(value) => onFilterChange('landSize', value)}
            />
          </div>

          {/* Benefit Amount Range */}
          <div>
            <Select
              label="Benefit Amount"
              options={benefitRangeOptions}
              value={filters?.benefitRange}
              onChange={(value) => onFilterChange('benefitRange', value)}
            />
          </div>

          {/* Scheme Types */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">
              Scheme Types
            </label>
            <div className="space-y-2">
              {schemeTypeOptions?.map((option) => (
                <Checkbox
                  key={option?.value}
                  label={option?.label}
                  checked={filters?.schemeTypes?.includes(option?.value)}
                  onChange={(e) => {
                    const newTypes = e?.target?.checked
                      ? [...filters?.schemeTypes, option?.value]
                      : filters?.schemeTypes?.filter(type => type !== option?.value);
                    onFilterChange('schemeTypes', newTypes);
                  }}
                />
              ))}
            </div>
          </div>

          {/* Application Status */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">
              Application Status
            </label>
            <div className="space-y-2">
              <Checkbox
                label="Currently Open"
                checked={filters?.onlyOpen}
                onChange={(e) => onFilterChange('onlyOpen', e?.target?.checked)}
              />
              <Checkbox
                label="New Schemes"
                checked={filters?.onlyNew}
                onChange={(e) => onFilterChange('onlyNew', e?.target?.checked)}
              />
              <Checkbox
                label="High Success Rate (>80%)"
                checked={filters?.highSuccessRate}
                onChange={(e) => onFilterChange('highSuccessRate', e?.target?.checked)}
              />
            </div>
          </div>

          {/* Age Range */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">
              Age Range
            </label>
            <div className="grid grid-cols-2 gap-3">
              <Input
                type="number"
                placeholder="Min Age"
                value={filters?.minAge}
                onChange={(e) => onFilterChange('minAge', e?.target?.value)}
              />
              <Input
                type="number"
                placeholder="Max Age"
                value={filters?.maxAge}
                onChange={(e) => onFilterChange('maxAge', e?.target?.value)}
              />
            </div>
          </div>

          {/* Annual Income */}
          <div>
            <Input
              label="Maximum Annual Income (₹)"
              type="number"
              placeholder="Enter maximum income"
              value={filters?.maxIncome}
              onChange={(e) => onFilterChange('maxIncome', e?.target?.value)}
              description="Leave blank if no income limit"
            />
          </div>
        </div>

        {/* Apply Filters Button */}
        <div className="p-4 border-t border-border">
          <Button
            variant="default"
            fullWidth
            iconName="Search"
            iconPosition="left"
          >
            Apply Filters
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;