import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Select from '../../components/ui/Select';
import PriceCard from './components/PriceCard';
import PriceChart from './components/PriceChart';
import MarketComparison from './components/MarketComparison';
import PriceAlerts from './components/PriceAlerts';
import MarketNews from './components/MarketNews';
import TransportCalculator from './components/TransportCalculator';
import BestTimeToSell from './components/BestTimeToSell';

const MarketIntelligenceCenter = () => {
  const [selectedState, setSelectedState] = useState('all');
  const [selectedCrop, setSelectedCrop] = useState('wheat');
  const [timeRange, setTimeRange] = useState('1m');
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const stateOptions = [
    { value: 'all', label: 'All States' },
    { value: 'punjab', label: 'Punjab' },
    { value: 'haryana', label: 'Haryana' },
    { value: 'uttar-pradesh', label: 'Uttar Pradesh' },
    { value: 'maharashtra', label: 'Maharashtra' },
    { value: 'karnataka', label: 'Karnataka' }
  ];

  const cropOptions = [
    { value: 'wheat', label: 'Wheat' },
    { value: 'rice', label: 'Rice' },
    { value: 'onion', label: 'Onion' },
    { value: 'potato', label: 'Potato' },
    { value: 'tomato', label: 'Tomato' },
    { value: 'cotton', label: 'Cotton' }
  ];

  // Mock price data
  const priceData = [
    {
      crop: 'Wheat',
      currentPrice: 2850,
      previousPrice: 2650,
      change: 200,
      changePercent: 7.5,
      market: 'Delhi APMC',
      lastUpdated: '2 hours ago',
      trend: 'up'
    },
    {
      crop: 'Rice',
      currentPrice: 3200,
      previousPrice: 3350,
      change: -150,
      changePercent: -4.5,
      market: 'Mumbai APMC',
      lastUpdated: '1 hour ago',
      trend: 'down'
    },
    {
      crop: 'Onion',
      currentPrice: 1200,
      previousPrice: 1180,
      change: 20,
      changePercent: 1.7,
      market: 'Kolkata Market',
      lastUpdated: '3 hours ago',
      trend: 'stable'
    },
    {
      crop: 'Potato',
      currentPrice: 1800,
      previousPrice: 1650,
      change: 150,
      changePercent: 9.1,
      market: 'Bangalore APMC',
      lastUpdated: '1 hour ago',
      trend: 'up'
    },
    {
      crop: 'Tomato',
      currentPrice: 2500,
      previousPrice: 2800,
      change: -300,
      changePercent: -10.7,
      market: 'Hyderabad Market',
      lastUpdated: '4 hours ago',
      trend: 'down'
    },
    {
      crop: 'Cotton',
      currentPrice: 5800,
      previousPrice: 5650,
      change: 150,
      changePercent: 2.7,
      market: 'Ahmedabad APMC',
      lastUpdated: '2 hours ago',
      trend: 'up'
    }
  ];

  // Mock chart data
  const chartData = [
    { date: '2025-01-01', price: 2400 },
    { date: '2025-01-05', price: 2450 },
    { date: '2025-01-10', price: 2380 },
    { date: '2025-01-15', price: 2520 },
    { date: '2025-01-20', price: 2650 },
    { date: '2025-01-25', price: 2580 },
    { date: '2025-01-30', price: 2720 },
    { date: '2025-02-05', price: 2850 },
    { date: '2025-02-10', price: 2780 },
    { date: '2025-02-15', price: 2920 },
    { date: '2025-02-20', price: 2850 }
  ];

  const marketStats = {
    totalMarkets: 6847,
    activeTraders: 12543,
    dailyVolume: '2.8M',
    avgPriceChange: '+3.2%'
  };

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Update timestamp every minute
    const interval = setInterval(() => {
      setLastUpdated(new Date());
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  const handleRefreshData = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setLastUpdated(new Date());
    }, 1000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-16">
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading market intelligence...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Market Intelligence Center - KrishiMitra</title>
        <meta name="description" content="Real-time agricultural market prices, trends, and intelligence for informed farming decisions" />
      </Helmet>
      <Header />
      <div className="pt-16">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary/10 via-accent/5 to-primary/10 border-b border-border">
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-6 lg:space-y-0">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                    <Icon name="TrendingUp" size={24} color="white" />
                  </div>
                  <div>
                    <h1 className="text-3xl font-poppins font-bold text-foreground">Market Intelligence Center</h1>
                    <p className="text-muted-foreground">Real-time market data and intelligent insights for better farming decisions</p>
                  </div>
                </div>
                
                <div className="flex flex-wrap items-center gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                    <span className="text-muted-foreground">Live Data</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="Clock" size={14} className="text-muted-foreground" />
                    <span className="text-muted-foreground">
                      Last updated: {lastUpdated?.toLocaleTimeString('en-IN', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Icon name="Database" size={14} className="text-muted-foreground" />
                    <span className="text-muted-foreground">{marketStats?.totalMarkets}+ Markets</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex gap-2">
                  <Select
                    options={stateOptions}
                    value={selectedState}
                    onChange={setSelectedState}
                    className="w-32"
                  />
                  <Select
                    options={cropOptions}
                    value={selectedCrop}
                    onChange={setSelectedCrop}
                    className="w-32"
                  />
                </div>
                <Button
                  variant="outline"
                  onClick={handleRefreshData}
                  iconName="RefreshCw"
                  iconPosition="left"
                  className="border-primary/20 hover:border-primary hover:bg-primary/5"
                >
                  Refresh
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Market Stats */}
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-lg border border-border p-4 text-center">
              <div className="text-2xl font-bold text-primary">{marketStats?.totalMarkets}</div>
              <div className="text-sm text-muted-foreground">Active Markets</div>
            </div>
            <div className="bg-white rounded-lg border border-border p-4 text-center">
              <div className="text-2xl font-bold text-primary">{marketStats?.activeTraders}</div>
              <div className="text-sm text-muted-foreground">Active Traders</div>
            </div>
            <div className="bg-white rounded-lg border border-border p-4 text-center">
              <div className="text-2xl font-bold text-primary">{marketStats?.dailyVolume}</div>
              <div className="text-sm text-muted-foreground">Daily Volume (₹)</div>
            </div>
            <div className="bg-white rounded-lg border border-border p-4 text-center">
              <div className="text-2xl font-bold text-success">{marketStats?.avgPriceChange}</div>
              <div className="text-sm text-muted-foreground">Avg Price Change</div>
            </div>
          </div>

          {/* Price Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {priceData?.map((price, index) => (
              <PriceCard key={index} {...price} />
            ))}
          </div>

          {/* Price Chart */}
          <div className="mb-8">
            <PriceChart 
              data={chartData}
              crop={selectedCrop}
              timeRange={timeRange}
              onTimeRangeChange={setTimeRange}
            />
          </div>

          {/* Market Comparison */}
          <div className="mb-8">
            <MarketComparison 
              selectedCrop={selectedCrop}
              onCropChange={setSelectedCrop}
              markets={priceData}
            />
          </div>

          {/* Best Time to Sell */}
          <div className="mb-8">
            <BestTimeToSell />
          </div>

          {/* Price Alerts */}
          <div className="mb-8">
            <PriceAlerts />
          </div>

          {/* Transport Calculator */}
          <div className="mb-8">
            <TransportCalculator />
          </div>

          {/* Market News */}
          <div className="mb-8">
            <MarketNews />
          </div>
        </div>

        {/* Footer CTA */}
        <div className="bg-gradient-to-r from-primary to-accent text-white">
          <div className="max-w-7xl mx-auto px-4 py-12">
            <div className="text-center">
              <h2 className="text-2xl font-poppins font-bold mb-4">
                Stay Ahead of Market Trends
              </h2>
              <p className="text-white/90 mb-6 max-w-2xl mx-auto">
                Get personalized market alerts, price predictions, and selling recommendations 
                delivered directly to your phone. Never miss the best selling opportunity again.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  variant="secondary" 
                  size="lg"
                  iconName="Bell"
                  iconPosition="left"
                  className="bg-white text-primary hover:bg-white/90"
                >
                  Enable Price Alerts
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  iconName="Smartphone"
                  iconPosition="left"
                  className="border-white text-white hover:bg-white/10"
                >
                  Download Mobile App
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketIntelligenceCenter;