import React from 'react';
import Icon from '../../../components/AppIcon';

const PriceCard = ({ crop, currentPrice, previousPrice, change, changePercent, market, lastUpdated, trend }) => {
  const isPositive = change >= 0;
  const trendIcon = trend === 'up' ? 'TrendingUp' : trend === 'down' ? 'TrendingDown' : 'Minus';
  const trendColor = trend === 'up' ? 'text-success' : trend === 'down' ? 'text-error' : 'text-muted-foreground';

  return (
    <div className="bg-white rounded-lg border border-border p-4 hover:shadow-md transition-all duration-300">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="font-poppins font-semibold text-foreground text-lg">{crop}</h3>
          <p className="text-sm text-muted-foreground">{market}</p>
        </div>
        <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${
          isPositive ? 'bg-success/10 text-success' : 'bg-error/10 text-error'
        }`}>
          <Icon name={isPositive ? 'ArrowUp' : 'ArrowDown'} size={12} />
          <span>{Math.abs(changePercent)}%</span>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-bold text-foreground">₹{currentPrice}</span>
          <span className="text-sm text-muted-foreground">per quintal</span>
        </div>
        
        <div className="flex items-center space-x-2 text-sm">
          <span className="text-muted-foreground">Previous:</span>
          <span className="font-medium">₹{previousPrice}</span>
          <span className={`flex items-center space-x-1 ${isPositive ? 'text-success' : 'text-error'}`}>
            <Icon name={isPositive ? 'Plus' : 'Minus'} size={12} />
            <span>₹{Math.abs(change)}</span>
          </span>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border">
          <div className="flex items-center space-x-2">
            <Icon name={trendIcon} size={14} className={trendColor} />
            <span className={`text-xs font-medium ${trendColor}`}>
              {trend === 'up' ? 'Rising' : trend === 'down' ? 'Falling' : 'Stable'}
            </span>
          </div>
          <span className="text-xs text-muted-foreground">{lastUpdated}</span>
        </div>
      </div>
    </div>
  );
};

export default PriceCard;