import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const MarketComparison = ({ markets, selectedCrop, onCropChange }) => {
  const [selectedMarkets, setSelectedMarkets] = useState(['Delhi', 'Mumbai', 'Kolkata']);
  const [sortBy, setSortBy] = useState('price');

  const cropOptions = [
    { value: 'wheat', label: 'Wheat' },
    { value: 'rice', label: 'Rice' },
    { value: 'onion', label: 'Onion' },
    { value: 'potato', label: 'Potato' },
    { value: 'tomato', label: 'Tomato' },
    { value: 'cotton', label: 'Cotton' }
  ];

  const sortOptions = [
    { value: 'price', label: 'Price (High to Low)' },
    { value: 'price_asc', label: 'Price (Low to High)' },
    { value: 'distance', label: 'Distance' },
    { value: 'profit', label: 'Net Profit' }
  ];

  const marketData = [
    {
      name: 'Delhi APMC',
      location: 'Delhi',
      price: 2850,
      distance: 45,
      transportCost: 150,
      netPrice: 2700,
      trend: 'up',
      quality: 'Premium',
      demandLevel: 'High'
    },
    {
      name: 'Azadpur Mandi',
      location: 'Delhi',
      price: 2780,
      distance: 52,
      transportCost: 180,
      netPrice: 2600,
      trend: 'stable',
      quality: 'Standard',
      demandLevel: 'Medium'
    },
    {
      name: 'Mumbai APMC',
      location: 'Mumbai',
      price: 3100,
      distance: 320,
      transportCost: 450,
      netPrice: 2650,
      trend: 'up',
      quality: 'Premium',
      demandLevel: 'Very High'
    },
    {
      name: 'Kolkata Market',
      location: 'Kolkata',
      price: 2650,
      distance: 180,
      transportCost: 250,
      netPrice: 2400,
      trend: 'down',
      quality: 'Standard',
      demandLevel: 'Low'
    }
  ];

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'up': return 'TrendingUp';
      case 'down': return 'TrendingDown';
      default: return 'Minus';
    }
  };

  const getTrendColor = (trend) => {
    switch (trend) {
      case 'up': return 'text-success';
      case 'down': return 'text-error';
      default: return 'text-muted-foreground';
    }
  };

  const getDemandColor = (level) => {
    switch (level) {
      case 'Very High': return 'bg-success text-success-foreground';
      case 'High': return 'bg-accent text-accent-foreground';
      case 'Medium': return 'bg-warning text-warning-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
        <div>
          <h3 className="font-poppins font-semibold text-lg text-foreground">Market Comparison</h3>
          <p className="text-sm text-muted-foreground">Compare prices across different markets</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Select
            options={cropOptions}
            value={selectedCrop}
            onChange={onCropChange}
            placeholder="Select crop"
            className="w-full sm:w-40"
          />
          <Select
            options={sortOptions}
            value={sortBy}
            onChange={setSortBy}
            placeholder="Sort by"
            className="w-full sm:w-40"
          />
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-3 px-2 text-sm font-medium text-muted-foreground">Market</th>
              <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Price/Quintal</th>
              <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Distance</th>
              <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Transport Cost</th>
              <th className="text-right py-3 px-2 text-sm font-medium text-muted-foreground">Net Price</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-muted-foreground">Trend</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-muted-foreground">Demand</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-muted-foreground">Action</th>
            </tr>
          </thead>
          <tbody>
            {marketData?.map((market, index) => (
              <tr key={index} className="border-b border-border hover:bg-muted/30 transition-colors">
                <td className="py-4 px-2">
                  <div>
                    <div className="font-medium text-foreground">{market?.name}</div>
                    <div className="text-sm text-muted-foreground flex items-center">
                      <Icon name="MapPin" size={12} className="mr-1" />
                      {market?.location}
                    </div>
                  </div>
                </td>
                <td className="py-4 px-2 text-right">
                  <div className="font-semibold text-foreground">₹{market?.price}</div>
                  <div className="text-xs text-muted-foreground">{market?.quality}</div>
                </td>
                <td className="py-4 px-2 text-right text-sm text-foreground">{market?.distance} km</td>
                <td className="py-4 px-2 text-right text-sm text-foreground">₹{market?.transportCost}</td>
                <td className="py-4 px-2 text-right">
                  <div className="font-semibold text-primary">₹{market?.netPrice}</div>
                </td>
                <td className="py-4 px-2 text-center">
                  <div className={`flex items-center justify-center ${getTrendColor(market?.trend)}`}>
                    <Icon name={getTrendIcon(market?.trend)} size={16} />
                  </div>
                </td>
                <td className="py-4 px-2 text-center">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDemandColor(market?.demandLevel)}`}>
                    {market?.demandLevel}
                  </span>
                </td>
                <td className="py-4 px-2 text-center">
                  <Button variant="outline" size="sm" iconName="Phone">
                    Contact
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mt-6 pt-4 border-t border-border space-y-3 sm:space-y-0">
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <Icon name="Calculator" size={14} className="text-primary" />
            <span className="text-muted-foreground">Best Net Price:</span>
            <span className="font-semibold text-primary">₹2,700 (Delhi APMC)</span>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" iconName="Bell" iconPosition="left">
            Set Price Alert
          </Button>
          <Button variant="default" size="sm" iconName="Route" iconPosition="left">
            Plan Route
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MarketComparison;