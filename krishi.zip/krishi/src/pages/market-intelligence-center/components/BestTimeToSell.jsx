import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const BestTimeToSell = () => {
  const [selectedCrop, setSelectedCrop] = useState('wheat');
  const [selectedRegion, setSelectedRegion] = useState('north');

  const cropOptions = [
    { value: 'wheat', label: 'Wheat' },
    { value: 'rice', label: 'Rice' },
    { value: 'onion', label: 'Onion' },
    { value: 'potato', label: 'Potato' },
    { value: 'tomato', label: 'Tomato' },
    { value: 'cotton', label: 'Cotton' }
  ];

  const regionOptions = [
    { value: 'north', label: 'North India' },
    { value: 'south', label: 'South India' },
    { value: 'west', label: 'West India' },
    { value: 'east', label: 'East India' },
    { value: 'central', label: 'Central India' }
  ];

  const recommendations = {
    wheat: {
      currentStatus: 'Hold',
      recommendation: 'Wait 2-3 weeks',
      confidence: 85,
      expectedIncrease: 12,
      reasoning: 'Government procurement is about to begin, prices typically rise 10-15% during this period. Export demand is also increasing.',
      bestMonths: ['March', 'April', 'May'],
      worstMonths: ['June', 'July'],
      historicalPattern: 'Prices peak during March-April due to government procurement and export demand',
      riskFactors: ['Weather uncertainty', 'Policy changes'],
      opportunities: ['Export opportunities', 'Government procurement']
    },
    rice: {
      currentStatus: 'Sell Now',
      recommendation: 'Sell immediately',
      confidence: 92,
      expectedIncrease: -5,
      reasoning: 'New harvest season approaching, prices likely to decline. Current prices are at seasonal high.',
      bestMonths: ['September', 'October'],
      worstMonths: ['December', 'January'],
      historicalPattern: 'Prices decline post-harvest in November-December',
      riskFactors: ['New harvest pressure', 'Storage costs'],
      opportunities: ['Premium for quality rice', 'Direct buyer contracts']
    }
  };

  const currentRec = recommendations?.[selectedCrop] || recommendations?.wheat;

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'sell now': return 'bg-error text-error-foreground';
      case 'hold': return 'bg-warning text-warning-foreground';
      case 'buy': return 'bg-success text-success-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getConfidenceColor = (confidence) => {
    if (confidence >= 80) return 'text-success';
    if (confidence >= 60) return 'text-warning';
    return 'text-error';
  };

  const monthlyData = [
    { month: 'Jan', price: 2400, trend: 'down' },
    { month: 'Feb', price: 2350, trend: 'down' },
    { month: 'Mar', price: 2600, trend: 'up' },
    { month: 'Apr', price: 2850, trend: 'up' },
    { month: 'May', price: 2750, trend: 'down' },
    { month: 'Jun', price: 2500, trend: 'down' },
    { month: 'Jul', price: 2450, trend: 'stable' },
    { month: 'Aug', price: 2480, trend: 'up' },
    { month: 'Sep', price: 2520, trend: 'up' },
    { month: 'Oct', price: 2650, trend: 'up' },
    { month: 'Nov', price: 2580, trend: 'down' },
    { month: 'Dec', price: 2420, trend: 'down' }
  ];

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
        <div>
          <h3 className="font-poppins font-semibold text-lg text-foreground">Best Time to Sell</h3>
          <p className="text-sm text-muted-foreground">AI-powered selling recommendations based on market analysis</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <Select
            options={cropOptions}
            value={selectedCrop}
            onChange={setSelectedCrop}
            className="w-full sm:w-32"
          />
          <Select
            options={regionOptions}
            value={selectedRegion}
            onChange={setSelectedRegion}
            className="w-full sm:w-32"
          />
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Current Recommendation */}
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-primary/5 to-accent/5 border border-primary/20 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <span className={`px-3 py-1 rounded-full text-sm font-bold ${getStatusColor(currentRec?.currentStatus)}`}>
                {currentRec?.currentStatus?.toUpperCase()}
              </span>
              <div className="text-right">
                <div className={`text-lg font-bold ${getConfidenceColor(currentRec?.confidence)}`}>
                  {currentRec?.confidence}%
                </div>
                <div className="text-xs text-muted-foreground">Confidence</div>
              </div>
            </div>
            
            <h4 className="font-semibold text-foreground mb-2">{currentRec?.recommendation}</h4>
            <p className="text-sm text-muted-foreground mb-3">{currentRec?.reasoning}</p>
            
            {currentRec?.expectedIncrease !== 0 && (
              <div className="flex items-center space-x-2">
                <Icon 
                  name={currentRec?.expectedIncrease > 0 ? 'TrendingUp' : 'TrendingDown'} 
                  size={16} 
                  className={currentRec?.expectedIncrease > 0 ? 'text-success' : 'text-error'}
                />
                <span className={`text-sm font-medium ${
                  currentRec?.expectedIncrease > 0 ? 'text-success' : 'text-error'
                }`}>
                  Expected {currentRec?.expectedIncrease > 0 ? 'increase' : 'decrease'}: {Math.abs(currentRec?.expectedIncrease)}%
                </span>
              </div>
            )}
          </div>

          <div className="bg-white border border-border rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-3">Seasonal Pattern</h4>
            <p className="text-sm text-muted-foreground mb-3">{currentRec?.historicalPattern}</p>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Best Months:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {currentRec?.bestMonths?.map((month) => (
                    <span key={month} className="px-2 py-1 bg-success/10 text-success text-xs rounded">
                      {month}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-muted-foreground">Avoid Months:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {currentRec?.worstMonths?.map((month) => (
                    <span key={month} className="px-2 py-1 bg-error/10 text-error text-xs rounded">
                      {month}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-error/5 border border-error/20 rounded-lg p-3">
              <h5 className="font-medium text-error mb-2 flex items-center">
                <Icon name="AlertTriangle" size={14} className="mr-1" />
                Risk Factors
              </h5>
              <ul className="text-xs text-muted-foreground space-y-1">
                {currentRec?.riskFactors?.map((risk, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-1 h-1 bg-error rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    {risk}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-success/5 border border-success/20 rounded-lg p-3">
              <h5 className="font-medium text-success mb-2 flex items-center">
                <Icon name="Target" size={14} className="mr-1" />
                Opportunities
              </h5>
              <ul className="text-xs text-muted-foreground space-y-1">
                {currentRec?.opportunities?.map((opportunity, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-1 h-1 bg-success rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    {opportunity}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Monthly Price Trends */}
        <div className="space-y-4">
          <div className="bg-white border border-border rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-4">Monthly Price Trends (₹/Quintal)</h4>
            
            <div className="space-y-2">
              {monthlyData?.map((data, index) => {
                const isCurrentMonth = index === 3; // April as current month
                const isBestMonth = currentRec?.bestMonths?.includes(data?.month);
                const isWorstMonth = currentRec?.worstMonths?.includes(data?.month);
                
                return (
                  <div key={data?.month} className={`flex items-center justify-between p-2 rounded ${
                    isCurrentMonth ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/30'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <span className={`text-sm font-medium ${isCurrentMonth ? 'text-primary' : 'text-foreground'}`}>
                        {data?.month}
                      </span>
                      {isCurrentMonth && (
                        <span className="px-2 py-0.5 bg-primary text-primary-foreground text-xs rounded">
                          Current
                        </span>
                      )}
                      {isBestMonth && (
                        <Icon name="Star" size={12} className="text-success" />
                      )}
                      {isWorstMonth && (
                        <Icon name="AlertCircle" size={12} className="text-error" />
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold text-foreground">₹{data?.price}</span>
                      <Icon 
                        name={
                          data?.trend === 'up' ? 'TrendingUp' : 
                          data?.trend === 'down' ? 'TrendingDown' : 'Minus'
                        } 
                        size={14} 
                        className={
                          data?.trend === 'up' ? 'text-success' : 
                          data?.trend === 'down' ? 'text-error' : 'text-muted-foreground'
                        }
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-accent/5 border border-accent/20 rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-3 flex items-center">
              <Icon name="Lightbulb" size={16} className="mr-2 text-accent" />
              Smart Recommendations
            </h4>
            
            <div className="space-y-3 text-sm">
              <div className="flex items-start space-x-2">
                <Icon name="Clock" size={14} className="text-accent mt-0.5" />
                <div>
                  <span className="font-medium">Timing Strategy:</span>
                  <p className="text-muted-foreground">Monitor daily prices and sell when prices cross ₹2,800 threshold</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-2">
                <Icon name="Package" size={14} className="text-accent mt-0.5" />
                <div>
                  <span className="font-medium">Quality Premium:</span>
                  <p className="text-muted-foreground">Grade A quality can fetch 8-12% premium over current market rates</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-2">
                <Icon name="Handshake" size={14} className="text-accent mt-0.5" />
                <div>
                  <span className="font-medium">Direct Sales:</span>
                  <p className="text-muted-foreground">Consider direct buyer contracts to avoid middleman margins</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col sm:flex-row gap-3 mt-6 pt-4 border-t border-border">
        <Button variant="default" iconName="Bell" iconPosition="left">
          Set Price Alert
        </Button>
        <Button variant="outline" iconName="Calendar" iconPosition="left">
          Schedule Reminder
        </Button>
        <Button variant="outline" iconName="Share2" iconPosition="left">
          Share Analysis
        </Button>
      </div>
    </div>
  );
};

export default BestTimeToSell;