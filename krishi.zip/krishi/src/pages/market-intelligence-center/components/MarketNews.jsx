import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const MarketNews = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { value: 'all', label: 'All News', icon: 'Newspaper' },
    { value: 'prices', label: 'Price Updates', icon: 'TrendingUp' },
    { value: 'policy', label: 'Policy Changes', icon: 'FileText' },
    { value: 'weather', label: 'Weather Impact', icon: 'Cloud' },
    { value: 'export', label: 'Export News', icon: 'Plane' }
  ];

  const newsData = [
    {
      id: 1,
      title: "Wheat Prices Surge 15% Following Export Ban Announcement",
      summary: "Government\'s decision to restrict wheat exports has led to immediate price increases across major APMC markets. Delhi and Mumbai markets show strongest gains.",
      category: 'policy',
      source: 'Agricultural Ministry',
      timestamp: '2 hours ago',
      impact: 'high',
      relevantCrops: ['Wheat', 'Rice'],
      isBreaking: true
    },
    {
      id: 2,
      title: "Monsoon Forecast Revised: 5% Above Normal Rainfall Expected",
      summary: "IMD updates monsoon prediction, indicating favorable conditions for Kharif crops. Cotton and sugarcane farmers likely to benefit most from increased precipitation.",
      category: 'weather',
      source: 'IMD Weather',
      timestamp: '4 hours ago',
      impact: 'medium',
      relevantCrops: ['Cotton', 'Sugarcane', 'Rice'],
      isBreaking: false
    },
    {
      id: 3,
      title: "Onion Export Prices Hit Record High at ₹45,000 per Tonne",
      summary: "International demand surge and reduced supply from competing countries drive onion export prices to unprecedented levels. Domestic prices expected to follow suit.",
      category: 'export',
      source: 'APEDA',
      timestamp: '6 hours ago',
      impact: 'high',
      relevantCrops: ['Onion'],
      isBreaking: false
    },
    {
      id: 4,
      title: "New MSP Rates Announced for Rabi Crops 2025-26",
      summary: "Government increases minimum support prices for wheat by 8% and mustard by 12%. Farmers advised to plan sowing accordingly for maximum benefit.",
      category: 'policy',
      source: 'CACP',
      timestamp: '1 day ago',
      impact: 'high',
      relevantCrops: ['Wheat', 'Mustard', 'Barley'],
      isBreaking: false
    },
    {
      id: 5,
      title: "Technology Integration: AI-Based Crop Advisory Services Expand",
      summary: "Digital agriculture platforms report 300% increase in farmer adoption. Voice-based advisory services particularly popular in rural areas.",
      category: 'technology',
      source: 'AgTech India',
      timestamp: '2 days ago',
      impact: 'medium',
      relevantCrops: ['All Crops'],
      isBreaking: false
    }
  ];

  const getImpactColor = (impact) => {
    switch (impact) {
      case 'high': return 'bg-error/10 text-error border-error/20';
      case 'medium': return 'bg-warning/10 text-warning border-warning/20';
      default: return 'bg-success/10 text-success border-success/20';
    }
  };

  const getCategoryIcon = (category) => {
    const cat = categories?.find(c => c?.value === category);
    return cat ? cat?.icon : 'Newspaper';
  };

  const filteredNews = selectedCategory === 'all' 
    ? newsData 
    : newsData?.filter(news => news?.category === selectedCategory);

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
        <div>
          <h3 className="font-poppins font-semibold text-lg text-foreground">Market News & Updates</h3>
          <p className="text-sm text-muted-foreground">Latest developments affecting agricultural markets</p>
        </div>
        
        <Button variant="outline" size="sm" iconName="RefreshCw" iconPosition="left">
          Refresh
        </Button>
      </div>
      {/* Category Filter */}
      <div className="flex flex-wrap gap-2 mb-6 pb-4 border-b border-border">
        {categories?.map((category) => (
          <button
            key={category?.value}
            onClick={() => setSelectedCategory(category?.value)}
            className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedCategory === category?.value
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground'
            }`}
          >
            <Icon name={category?.icon} size={14} />
            <span>{category?.label}</span>
          </button>
        ))}
      </div>
      {/* News List */}
      <div className="space-y-4">
        {filteredNews?.map((news) => (
          <div key={news?.id} className="border border-border rounded-lg p-4 hover:border-primary/30 transition-all">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                {news?.isBreaking && (
                  <span className="px-2 py-1 bg-error text-error-foreground text-xs font-bold rounded animate-pulse">
                    BREAKING
                  </span>
                )}
                <span className={`px-2 py-1 text-xs font-medium rounded border ${getImpactColor(news?.impact)}`}>
                  {news?.impact?.toUpperCase()} IMPACT
                </span>
                <div className="flex items-center space-x-1 text-muted-foreground">
                  <Icon name={getCategoryIcon(news?.category)} size={12} />
                  <span className="text-xs">{news?.source}</span>
                </div>
              </div>
              <span className="text-xs text-muted-foreground">{news?.timestamp}</span>
            </div>

            <h4 className="font-semibold text-foreground mb-2 hover:text-primary cursor-pointer transition-colors">
              {news?.title}
            </h4>
            
            <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
              {news?.summary}
            </p>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-xs text-muted-foreground">Relevant crops:</span>
                <div className="flex flex-wrap gap-1">
                  {news?.relevantCrops?.slice(0, 3)?.map((crop, index) => (
                    <span key={index} className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded">
                      {crop}
                    </span>
                  ))}
                  {news?.relevantCrops?.length > 3 && (
                    <span className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded">
                      +{news?.relevantCrops?.length - 3} more
                    </span>
                  )}
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" iconName="Share2">
                  Share
                </Button>
                <Button variant="outline" size="sm" iconName="ExternalLink">
                  Read More
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Load More */}
      <div className="text-center mt-6 pt-4 border-t border-border">
        <Button variant="outline" iconName="ChevronDown" iconPosition="right">
          Load More News
        </Button>
      </div>
      {/* News Summary */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-lg font-bold text-foreground">24</div>
            <div className="text-xs text-muted-foreground">Today's Updates</div>
          </div>
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-lg font-bold text-error">8</div>
            <div className="text-xs text-muted-foreground">High Impact News</div>
          </div>
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-lg font-bold text-primary">156</div>
            <div className="text-xs text-muted-foreground">This Week</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketNews;