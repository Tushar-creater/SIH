import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const TransportCalculator = () => {
  const [calculation, setCalculation] = useState({
    fromLocation: '',
    toLocation: '',
    crop: '',
    quantity: '',
    vehicleType: 'truck',
    distance: 0,
    fuelPrice: 95,
    laborCost: 500,
    tollCharges: 200,
    otherExpenses: 300
  });

  const [results, setResults] = useState(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const cropOptions = [
    { value: 'wheat', label: 'Wheat' },
    { value: 'rice', label: 'Rice' },
    { value: 'onion', label: 'Onion' },
    { value: 'potato', label: 'Potato' },
    { value: 'tomato', label: 'Tomato' },
    { value: 'cotton', label: 'Cotton' }
  ];

  const vehicleOptions = [
    { value: 'truck', label: 'Truck (10-12 MT)', description: 'Standard goods carrier' },
    { value: 'mini-truck', label: 'Mini Truck (3-5 MT)', description: 'For smaller loads' },
    { value: 'tractor-trolley', label: 'Tractor Trolley (5-7 MT)', description: 'Farm to market' },
    { value: 'tempo', label: 'Tempo (1-2 MT)', description: 'Local transport' }
  ];

  const locationOptions = [
    { value: 'delhi', label: 'Delhi' },
    { value: 'mumbai', label: 'Mumbai' },
    { value: 'kolkata', label: 'Kolkata' },
    { value: 'bangalore', label: 'Bangalore' },
    { value: 'hyderabad', label: 'Hyderabad' },
    { value: 'pune', label: 'Pune' }
  ];

  const calculateTransportCost = () => {
    setIsCalculating(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const distance = Math.floor(Math.random() * 500) + 50; // Mock distance
      const fuelConsumption = getVehicleFuelConsumption(calculation?.vehicleType);
      const fuelCost = (distance / fuelConsumption) * calculation?.fuelPrice;
      
      const totalCost = fuelCost + 
                       parseInt(calculation?.laborCost) + 
                       parseInt(calculation?.tollCharges) + 
                       parseInt(calculation?.otherExpenses);
      
      const costPerQuintal = totalCost / parseInt(calculation?.quantity);
      const costPerKm = totalCost / distance;
      
      setResults({
        distance,
        fuelCost: Math.round(fuelCost),
        totalCost: Math.round(totalCost),
        costPerQuintal: Math.round(costPerQuintal),
        costPerKm: Math.round(costPerKm),
        estimatedTime: Math.round(distance / 50), // Assuming 50 km/hr average
        breakdown: {
          fuel: Math.round(fuelCost),
          labor: parseInt(calculation?.laborCost),
          toll: parseInt(calculation?.tollCharges),
          other: parseInt(calculation?.otherExpenses)
        }
      });
      
      setCalculation(prev => ({ ...prev, distance }));
      setIsCalculating(false);
    }, 1500);
  };

  const getVehicleFuelConsumption = (vehicleType) => {
    const consumption = {
      'truck': 6, // km per liter
      'mini-truck': 8,
      'tractor-trolley': 10,
      'tempo': 12
    };
    return consumption?.[vehicleType] || 6;
  };

  const handleInputChange = (field, value) => {
    setCalculation(prev => ({ ...prev, [field]: value }));
    if (results) setResults(null); // Clear results when inputs change
  };

  const isFormValid = calculation?.fromLocation && 
                     calculation?.toLocation && 
                     calculation?.crop && 
                     calculation?.quantity;

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-poppins font-semibold text-lg text-foreground">Transport Cost Calculator</h3>
          <p className="text-sm text-muted-foreground">Calculate transportation costs to different markets</p>
        </div>
        <Icon name="Calculator" size={24} className="text-primary" />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select
              label="From Location"
              options={locationOptions}
              value={calculation?.fromLocation}
              onChange={(value) => handleInputChange('fromLocation', value)}
              placeholder="Select origin"
              required
            />
            <Select
              label="To Location"
              options={locationOptions}
              value={calculation?.toLocation}
              onChange={(value) => handleInputChange('toLocation', value)}
              placeholder="Select destination"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select
              label="Crop Type"
              options={cropOptions}
              value={calculation?.crop}
              onChange={(value) => handleInputChange('crop', value)}
              placeholder="Select crop"
              required
            />
            <Input
              label="Quantity (Quintals)"
              type="number"
              placeholder="Enter quantity"
              value={calculation?.quantity}
              onChange={(e) => handleInputChange('quantity', e?.target?.value)}
              required
            />
          </div>

          <Select
            label="Vehicle Type"
            options={vehicleOptions}
            value={calculation?.vehicleType}
            onChange={(value) => handleInputChange('vehicleType', value)}
          />

          <div className="bg-muted/30 rounded-lg p-4">
            <h4 className="font-medium text-foreground mb-3">Cost Parameters</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Fuel Price (₹/L)"
                type="number"
                value={calculation?.fuelPrice}
                onChange={(e) => handleInputChange('fuelPrice', e?.target?.value)}
              />
              <Input
                label="Labor Cost (₹)"
                type="number"
                value={calculation?.laborCost}
                onChange={(e) => handleInputChange('laborCost', e?.target?.value)}
              />
              <Input
                label="Toll Charges (₹)"
                type="number"
                value={calculation?.tollCharges}
                onChange={(e) => handleInputChange('tollCharges', e?.target?.value)}
              />
              <Input
                label="Other Expenses (₹)"
                type="number"
                value={calculation?.otherExpenses}
                onChange={(e) => handleInputChange('otherExpenses', e?.target?.value)}
              />
            </div>
          </div>

          <Button
            variant="default"
            fullWidth
            onClick={calculateTransportCost}
            disabled={!isFormValid || isCalculating}
            loading={isCalculating}
            iconName="Calculator"
            iconPosition="left"
          >
            {isCalculating ? 'Calculating...' : 'Calculate Transport Cost'}
          </Button>
        </div>

        {/* Results */}
        <div className="space-y-4">
          {results ? (
            <>
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <h4 className="font-semibold text-primary mb-3 flex items-center">
                  <Icon name="CheckCircle" size={16} className="mr-2" />
                  Calculation Results
                </h4>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">₹{results?.totalCost}</div>
                    <div className="text-xs text-muted-foreground">Total Cost</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">₹{results?.costPerQuintal}</div>
                    <div className="text-xs text-muted-foreground">Per Quintal</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Distance:</span>
                    <div className="font-medium">{results?.distance} km</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Est. Time:</span>
                    <div className="font-medium">{results?.estimatedTime} hours</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Cost per KM:</span>
                    <div className="font-medium">₹{results?.costPerKm}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Vehicle:</span>
                    <div className="font-medium capitalize">{calculation?.vehicleType?.replace('-', ' ')}</div>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-border rounded-lg p-4">
                <h4 className="font-medium text-foreground mb-3">Cost Breakdown</h4>
                <div className="space-y-2">
                  {Object.entries(results?.breakdown)?.map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center py-1">
                      <span className="text-sm text-muted-foreground capitalize">
                        {key === 'fuel' ? 'Fuel Cost' : 
                         key === 'labor' ? 'Labor Cost' :
                         key === 'toll' ? 'Toll Charges' : 'Other Expenses'}:
                      </span>
                      <span className="font-medium">₹{value}</span>
                    </div>
                  ))}
                  <div className="border-t border-border pt-2 mt-2">
                    <div className="flex justify-between items-center font-semibold">
                      <span>Total:</span>
                      <span className="text-primary">₹{results?.totalCost}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button variant="outline" size="sm" iconName="Download" iconPosition="left" fullWidth>
                  Save Report
                </Button>
                <Button variant="outline" size="sm" iconName="Share2" iconPosition="left" fullWidth>
                  Share
                </Button>
              </div>
            </>
          ) : (
            <div className="bg-muted/30 rounded-lg p-8 text-center">
              <Icon name="Calculator" size={48} className="text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-2">Enter transport details to calculate costs</p>
              <p className="text-sm text-muted-foreground">Get accurate cost estimates for transporting your crops to different markets</p>
            </div>
          )}
        </div>
      </div>
      {/* Quick Tips */}
      <div className="mt-6 pt-4 border-t border-border">
        <h4 className="font-medium text-foreground mb-3">💡 Cost Optimization Tips</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="flex items-start space-x-2">
            <Icon name="Truck" size={16} className="text-primary mt-0.5" />
            <div>
              <span className="font-medium">Choose Right Vehicle:</span>
              <p className="text-muted-foreground">Match vehicle capacity with your load for better cost efficiency</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <Icon name="Users" size={16} className="text-primary mt-0.5" />
            <div>
              <span className="font-medium">Group Transportation:</span>
              <p className="text-muted-foreground">Share transport costs with other farmers going to same market</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransportCalculator;