import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const PriceAlerts = () => {
  const [alerts, setAlerts] = useState([
    {
      id: 1,
      crop: 'Wheat',
      targetPrice: 2800,
      currentPrice: 2650,
      condition: 'above',
      market: 'Delhi APMC',
      isActive: true,
      createdDate: '2025-01-10'
    },
    {
      id: 2,
      crop: 'Rice',
      targetPrice: 3200,
      currentPrice: 3350,
      condition: 'below',
      market: 'Mumbai APMC',
      isActive: true,
      createdDate: '2025-01-08'
    },
    {
      id: 3,
      crop: 'Onion',
      targetPrice: 1500,
      currentPrice: 1200,
      condition: 'above',
      market: 'Kolkata Market',
      isActive: false,
      createdDate: '2025-01-05'
    }
  ]);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newAlert, setNewAlert] = useState({
    crop: '',
    targetPrice: '',
    condition: 'above',
    market: ''
  });

  const cropOptions = [
    { value: 'wheat', label: 'Wheat' },
    { value: 'rice', label: 'Rice' },
    { value: 'onion', label: 'Onion' },
    { value: 'potato', label: 'Potato' },
    { value: 'tomato', label: 'Tomato' },
    { value: 'cotton', label: 'Cotton' }
  ];

  const conditionOptions = [
    { value: 'above', label: 'Above Target Price' },
    { value: 'below', label: 'Below Target Price' }
  ];

  const marketOptions = [
    { value: 'delhi-apmc', label: 'Delhi APMC' },
    { value: 'mumbai-apmc', label: 'Mumbai APMC' },
    { value: 'kolkata-market', label: 'Kolkata Market' },
    { value: 'bangalore-apmc', label: 'Bangalore APMC' }
  ];

  const handleCreateAlert = () => {
    if (newAlert?.crop && newAlert?.targetPrice && newAlert?.market) {
      const alert = {
        id: alerts?.length + 1,
        crop: newAlert?.crop,
        targetPrice: parseInt(newAlert?.targetPrice),
        currentPrice: Math.floor(Math.random() * 1000) + 2000,
        condition: newAlert?.condition,
        market: newAlert?.market,
        isActive: true,
        createdDate: new Date()?.toISOString()?.split('T')?.[0]
      };
      setAlerts([...alerts, alert]);
      setNewAlert({ crop: '', targetPrice: '', condition: 'above', market: '' });
      setShowCreateForm(false);
    }
  };

  const toggleAlert = (id) => {
    setAlerts(alerts?.map(alert => 
      alert?.id === id ? { ...alert, isActive: !alert?.isActive } : alert
    ));
  };

  const deleteAlert = (id) => {
    setAlerts(alerts?.filter(alert => alert?.id !== id));
  };

  const getAlertStatus = (alert) => {
    const { condition, targetPrice, currentPrice } = alert;
    const isTriggered = condition === 'above' 
      ? currentPrice >= targetPrice 
      : currentPrice <= targetPrice;
    
    return {
      isTriggered,
      message: isTriggered 
        ? `Alert triggered! Price is ${condition} ₹${targetPrice}`
        : `Waiting for price to go ${condition} ₹${targetPrice}`
    };
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
        <div>
          <h3 className="font-poppins font-semibold text-lg text-foreground">Price Alerts</h3>
          <p className="text-sm text-muted-foreground">Get notified when prices reach your target</p>
        </div>
        
        <Button 
          variant="default" 
          onClick={() => setShowCreateForm(!showCreateForm)}
          iconName="Plus"
          iconPosition="left"
        >
          Create Alert
        </Button>
      </div>
      {showCreateForm && (
        <div className="bg-muted/30 rounded-lg p-4 mb-6">
          <h4 className="font-medium text-foreground mb-4">Create New Price Alert</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Select
              label="Crop"
              options={cropOptions}
              value={newAlert?.crop}
              onChange={(value) => setNewAlert({...newAlert, crop: value})}
              placeholder="Select crop"
            />
            <Input
              label="Target Price (₹)"
              type="number"
              placeholder="Enter price"
              value={newAlert?.targetPrice}
              onChange={(e) => setNewAlert({...newAlert, targetPrice: e?.target?.value})}
            />
            <Select
              label="Condition"
              options={conditionOptions}
              value={newAlert?.condition}
              onChange={(value) => setNewAlert({...newAlert, condition: value})}
            />
            <Select
              label="Market"
              options={marketOptions}
              value={newAlert?.market}
              onChange={(value) => setNewAlert({...newAlert, market: value})}
              placeholder="Select market"
            />
          </div>
          <div className="flex justify-end space-x-2 mt-4">
            <Button 
              variant="outline" 
              onClick={() => setShowCreateForm(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="default" 
              onClick={handleCreateAlert}
            >
              Create Alert
            </Button>
          </div>
        </div>
      )}
      <div className="space-y-4">
        {alerts?.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Bell" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No price alerts set up yet</p>
            <p className="text-sm text-muted-foreground">Create your first alert to get notified about price changes</p>
          </div>
        ) : (
          alerts?.map((alert) => {
            const status = getAlertStatus(alert);
            return (
              <div key={alert?.id} className={`border rounded-lg p-4 transition-all ${
                status?.isTriggered 
                  ? 'border-success bg-success/5' :'border-border hover:border-primary/30'
              }`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="font-medium text-foreground">{alert?.crop}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        alert?.isActive 
                          ? 'bg-success/10 text-success' :'bg-muted text-muted-foreground'
                      }`}>
                        {alert?.isActive ? 'Active' : 'Inactive'}
                      </span>
                      {status?.isTriggered && (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-accent/10 text-accent animate-pulse">
                          Triggered
                        </span>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Target Price:</span>
                        <div className="font-semibold text-foreground">₹{alert?.targetPrice}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Current Price:</span>
                        <div className="font-semibold text-foreground">₹{alert?.currentPrice}</div>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Market:</span>
                        <div className="font-medium text-foreground">{alert?.market}</div>
                      </div>
                    </div>
                    
                    <div className="mt-3">
                      <p className={`text-sm ${
                        status?.isTriggered ? 'text-success font-medium' : 'text-muted-foreground'
                      }`}>
                        {status?.message}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => toggleAlert(alert?.id)}
                      className="hover:bg-muted"
                    >
                      <Icon name={alert?.isActive ? 'BellOff' : 'Bell'} size={16} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteAlert(alert?.id)}
                      className="hover:bg-error/10 hover:text-error"
                    >
                      <Icon name="Trash2" size={16} />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
      {alerts?.length > 0 && (
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-success rounded-full"></div>
              <span className="text-muted-foreground">Active Alerts:</span>
              <span className="font-medium text-foreground">
                {alerts?.filter(a => a?.isActive)?.length}
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
              <span className="text-muted-foreground">Triggered:</span>
              <span className="font-medium text-accent">
                {alerts?.filter(a => getAlertStatus(a)?.isTriggered)?.length}
              </span>
            </div>
          </div>
          
          <Button variant="outline" size="sm" iconName="Settings" iconPosition="left">
            Manage Notifications
          </Button>
        </div>
      )}
    </div>
  );
};

export default PriceAlerts;