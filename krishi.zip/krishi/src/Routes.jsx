import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "./components/ScrollToTop";
import ErrorBoundary from "./components/ErrorBoundary";
import NotFound from "./pages/NotFound";

import MarketIntelligenceCenter from "./pages/market-intelligence-center";
import WeatherIntelligenceHub from "./pages/weather-intelligence-hub";
import OfficerConnectPortal from "./pages/officer-connect-portal";
import AIAssistantInterface from "./pages/ai-assistant-interface";
import GovernmentSchemesNavigator from "./pages/government-schemes-navigator";
import Homepage from "./pages/homepage";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <ScrollToTop />
        <RouterRoutes>
          <Route path="/" element={<AIAssistantInterface />} />
          <Route path="/market-intelligence-center" element={<MarketIntelligenceCenter />} />
          <Route path="/weather-intelligence-hub" element={<WeatherIntelligenceHub />} />
          <Route path="/officer-connect-portal" element={<OfficerConnectPortal />} />
          <Route path="/ai-assistant-interface" element={<AIAssistantInterface />} />
          <Route path="/government-schemes-navigator" element={<GovernmentSchemesNavigator />} />
          <Route path="/homepage" element={<Homepage />} />
          <Route path="*" element={<NotFound />} />
        </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
